
/* Embeddable real Aura Crono: original clocks + their original render engines. */
(() => {
 const embedding = window.__AURA_PORTAL_EMBED__;
 if (!embedding) return;
 document.body.classList.add('aura-portal-embed');
 function apply(choice){
  if(typeof choice!=='string'||!/^([a-z0-9]+):([a-z0-9]+)$/.test(choice))return;
  const [type,style]=choice.split(':');
  if(typeof CLOCK_STYLES==='undefined'||!CLOCK_STYLES[type])return;
  const button=document.querySelector('#clockTypeSelector button[data-clock="'+type+'"]');
  button?.click();
  const styles=CLOCK_STYLES[type]; const idx=styles.findIndex(s=>s[0]===style);
  const option=document.querySelectorAll('#styleSelector button')[idx];
  if(idx>=0 && option)option.click();
 }
 window.addEventListener('message',e=>{
  if(e.origin!==location.origin||e.source!==window.parent)return;
  if(e.data?.type==='portal-aura-set-clock')apply(e.data.choice);
  if(e.data?.type==='portal-aura-format'){
   const button=document.getElementById('hourFormatButton');
   if(button && ((e.data.format===12&&button.textContent!=='12 H')||(e.data.format===24&&button.textContent!=='24 H')))button.click();
  }
 });
 const ready=()=>{window.parent?.postMessage({type:'portal-aura-ready'},location.origin)};
 if(document.readyState==='complete')ready();else window.addEventListener('load',ready,{once:true});
})();
