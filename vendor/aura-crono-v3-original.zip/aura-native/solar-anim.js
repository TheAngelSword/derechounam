/* Aura Crono · Minimapa solar animado: órbitas 3D, vórtice helicoidal (el Sol viaja y los planetas
   lo siguen en espiral) y vista geocéntrica (los bucles retrógrados vistos desde la Tierra).
   Parte de las posiciones reales de hoy y avanza en cámara rápida. */
'use strict';
const SolarAnim = (() => {
  const TAU = Math.PI * 2, RAD = Math.PI / 180;
  const BODIES = [
    { id: 'mercury', name: 'Mercurio', color: '#c9c2b5', size: .16 },
    { id: 'venus', name: 'Venus', color: '#f2cf8a', size: .24 },
    { id: 'earth', name: 'Tierra', color: '#5aa9ff', size: .26 },
    { id: 'mars', name: 'Marte', color: '#f07a52', size: .2 },
    { id: 'jupiter', name: 'Júpiter', color: '#e8b27c', size: .45 },
    { id: 'saturn', name: 'Saturno', color: '#f3dc9a', size: .38, ring: true }
  ];
  const disp = a => 1.25 * Math.pow(a, .62) + .55; // radio de dibujo comprimido (no a escala)
  let canvas, g, mode = 'classic', playing = true, speed = 20, simDays = 0, last = 0, raf = 0, visible = true, motionOK = true;
  let trails = {}, onDate = null, W = 0, H = 0, dpr = 1;

  function fit() {
    if (!canvas) return;
    dpr = Math.min(2, window.devicePixelRatio || 1); W = canvas.clientWidth || 400; H = canvas.clientHeight || W;
    canvas.width = Math.round(W * dpr); canvas.height = Math.round(H * dpr); g.setTransform(dpr, 0, 0, dpr, 0, 0);
  }
  function helio(id, date) { const p = Astro.planet(id, date); return [p.x, p.y, p.r, p.a] }
  // Posición de dibujo (plano eclíptico) comprimiendo la distancia al Sol.
  function eclXY(id, date) { const [x, y, r, a] = helio(id, date), k = disp(a) * (r / a) / r; return [x * k, y * k] }
  function resetTrails() { trails = {}; for (const b of BODIES) trails[b.id] = []; trails.sun = []; trails.moon = [] }
  function push(id, pt, max) { const tr = trails[id]; tr.push(pt); if (tr.length > max) tr.splice(0, tr.length - max) }
  function drawTrail(pts, color, width, glow = true) {
    if (pts.length < 2) return;
    const n = pts.length, chunks = 12, per = Math.ceil(n / chunks);
    g.lineCap = 'round'; g.lineJoin = 'round';
    for (let c = 0; c < chunks; c++) {
      const a = c * per, b = Math.min(n - 1, (c + 1) * per); if (b <= a) continue;
      const alpha = (c + 1) / chunks;
      g.beginPath(); g.moveTo(pts[a].x, pts[a].y); for (let i = a + 1; i <= b; i++) g.lineTo(pts[i].x, pts[i].y);
      if (glow) { g.strokeStyle = color + Math.round(alpha * 60).toString(16).padStart(2, '0'); g.lineWidth = width * 4; g.stroke() }
      g.strokeStyle = color + Math.round(alpha * 230).toString(16).padStart(2, '0'); g.lineWidth = width; g.stroke();
    }
  }
  function body(x, y, r, color, ring) {
    const gr = g.createRadialGradient(x - r * .35, y - r * .35, r * .1, x, y, r);
    gr.addColorStop(0, '#ffffff'); gr.addColorStop(.35, color); gr.addColorStop(1, '#00000088');
    g.shadowColor = color; g.shadowBlur = 10; g.fillStyle = gr; g.beginPath(); g.arc(x, y, Math.max(1.5, r), 0, TAU); g.fill(); g.shadowBlur = 0;
    if (ring) { g.strokeStyle = 'rgba(243,220,154,.8)'; g.lineWidth = Math.max(1, r * .25); g.beginPath(); g.ellipse(x, y, r * 2, r * .6, -.4, 0, TAU); g.stroke() }
  }
  function sun(x, y, r) {
    const gl = g.createRadialGradient(x, y, r * .2, x, y, r * 4); gl.addColorStop(0, 'rgba(255,220,120,.85)'); gl.addColorStop(.35, 'rgba(255,170,40,.25)'); gl.addColorStop(1, 'rgba(255,140,20,0)');
    g.fillStyle = gl; g.beginPath(); g.arc(x, y, r * 4, 0, TAU); g.fill();
    const c = g.createRadialGradient(x - r * .3, y - r * .3, r * .1, x, y, r); c.addColorStop(0, '#fffbe0'); c.addColorStop(.5, '#ffd23f'); c.addColorStop(1, '#f09a1c');
    g.fillStyle = c; g.beginPath(); g.arc(x, y, r, 0, TAU); g.fill();
    g.fillStyle = 'rgba(200,120,20,.35)'; for (let i = 0; i < 6; i++) { const a = i * 2.1 + simDays * .02; g.beginPath(); g.arc(x + Math.cos(a) * r * .5, y + Math.sin(a) * r * .45, r * .14, 0, TAU); g.fill() }
  }
  function background() {
    g.fillStyle = '#04050c'; g.fillRect(0, 0, W, H);
    for (let i = 0; i < 90; i++) { const x = (i * 97.3) % W, y = (i * 57.7 + (i % 7) * 13) % H; g.fillStyle = `rgba(255,255,255,${.15 + (i % 5) * .1})`; g.fillRect(x, y, 1.2, 1.2) }
  }
  function label(text, x, y) { g.fillStyle = 'rgba(230,236,255,.75)'; g.font = '600 10px "DM Sans", sans-serif'; g.textAlign = 'center'; g.fillText(text, x, y) }

  function legend(geo) {
    const items = [['Sol', '#ffc84a'], ...BODIES.filter(b => !(geo && b.id === 'earth')).map(b => [b.name, b.color])];
    if (geo) items.push(['Tierra (centro)', '#5aa9ff']);
    g.font = '600 10px "DM Sans", sans-serif'; g.textAlign = 'left'; let x = 10, y = H - 12;
    for (const [n, c] of items) { const w = g.measureText(n).width + 22; if (x + w > W - 6) { x = 10; y -= 16 } g.fillStyle = c; g.beginPath(); g.arc(x + 5, y - 3, 4, 0, TAU); g.fill(); g.fillStyle = 'rgba(230,236,255,.8)'; g.fillText(n, x + 13, y); x += w }
  }
  function frameOrbits(date, t) {
    const cam = Mini3D.camera({ yaw: t * .05, pitch: .6, dist: 16, fov: 16, cx: W / 2, cy: H * .47, scale: Math.min(W, H) * .15 });
    for (const b of BODIES) {
      const R = disp(Astro.planet(b.id, date).a), pts = [];
      for (let i = 0; i <= 96; i++) { const a = i / 96 * TAU; pts.push(cam.project([R * Math.cos(a), 0, R * Math.sin(a)])) }
      g.strokeStyle = 'rgba(160,190,255,.16)'; g.lineWidth = 1; g.beginPath(); pts.forEach((q, i) => i ? g.lineTo(q.x, q.y) : g.moveTo(q.x, q.y)); g.stroke();
    }
    const items = [];
    for (const b of BODIES) {
      const [x, y] = eclXY(b.id, date), w = [x, 0, y], q = cam.project(w);
      items.push({ z: q.z, draw() {
        drawTrail(trails[b.id].map(cam.project), b.color, 1.6);
        body(q.x, q.y, b.size * q.f, b.color, b.ring); if (b.id === 'earth') label('TIERRA', q.x, q.y - b.size * q.f - 6);
        if (b.id === 'earth') { const m = Astro.moon(date), mr = .55, mq = cam.project([x + mr * Math.cos(m.lon * RAD), 0, y + mr * Math.sin(m.lon * RAD)]); body(mq.x, mq.y, .08 * mq.f, '#e8e4d0') }
      } });
    }
    const s = cam.project([0, 0, 0]); items.push({ z: s.z, draw() { sun(s.x, s.y, .55 * s.f) } });
    items.sort((a, b) => b.z - a.z).forEach(i => i.draw());
    legend();
  }
  // Vórtice: el Sol avanza por la galaxia y los planetas trazan hélices a su alrededor.
  function frameVortex(date, t) {
    const sx = simDays * VORTEX_V;
    const cam = Mini3D.camera({ yaw: -.15 + Math.sin(t * .1) * .12, pitch: .22, dist: 14, fov: 16, cx: W * .66, cy: H * .5, scale: Math.min(W, H) * .075, target: [sx, 0, 0] });
    const sw = [sx, 0, 0];
    g.globalCompositeOperation = 'lighter';
    drawTrail(trails.sun.map(cam.project), '#ffc84a', 4);
    for (const b of BODIES) drawTrail(trails[b.id].map(cam.project), b.color, 1.8);
    g.globalCompositeOperation = 'source-over';
    const s = cam.project(sw); sun(s.x, s.y, .6 * s.f);
    for (const b of BODIES) { const pt = trails[b.id][trails[b.id].length - 1], q = cam.project(pt); body(q.x, q.y, b.size * q.f, b.color, b.ring) }
    legend();
  }
  // Geocéntrico: todo visto desde la Tierra; aparecen los bucles retrógrados.
  function frameGeo(date) {
    const cx = W / 2, cy = H / 2, sc = Math.min(W, H) * .07;
    const toScreen = pt => ({ x: cx + pt[0] * sc, y: cy - pt[1] * sc });
    g.globalCompositeOperation = 'lighter';
    drawTrail(trails.sun.map(toScreen), '#ffc84a', 2.2);
    for (const b of BODIES) { if (b.id === 'earth') continue; drawTrail(trails[b.id].map(toScreen), b.color, 1.5) }
    g.globalCompositeOperation = 'source-over';
    const sp = toScreen(trails.sun[trails.sun.length - 1]);
    sun(sp.x, sp.y, sc * .45);
    for (const b of BODIES) { if (b.id === 'earth') continue; const q = toScreen(trails[b.id][trails[b.id].length - 1]); body(q.x, q.y, sc * b.size * .7, b.color, b.ring) }
    body(cx, cy, sc * .22, '#5aa9ff');
    legend(true);
    const m = Astro.moon(date); body(cx + Math.cos(m.lon * RAD) * sc * .7, cy - Math.sin(m.lon * RAD) * sc * .7, sc * .1, '#e8e4d0');
  }

  const VORTEX_V = .03, TILT = 60 * RAD;
  const MAXLEN = { orbits: 140, vortex: 900, geo: 1600 }, STEP = { orbits: 2, vortex: 1.6, geo: 2.5 };
  let lastSample = 0;
  // Guarda la posición de cada cuerpo para la fecha dada según el modo (coordenadas de mundo).
  function sample(date, days) {
    const max = MAXLEN[mode];
    if (mode === 'orbits') { for (const b of BODIES) { const [x, y] = eclXY(b.id, date); push(b.id, [x, 0, y], max) } return }
    if (mode === 'vortex') {
      const sx = days * VORTEX_V; push('sun', [sx, 0, 0], max);
      for (const b of BODIES) { const [x, y] = eclXY(b.id, date); push(b.id, [sx + x * Math.cos(TILT), y, x * Math.sin(TILT)], max) }
      return;
    }
    const [ex, ey] = helio('earth', date), comp = (dx, dy) => { const r = Math.hypot(dx, dy) || 1, k = 1.7 * Math.pow(r, .55) / r; return [dx * k, dy * k] };
    push('sun', comp(-ex, -ey), 400);
    for (const b of BODIES) { if (b.id === 'earth') continue; const [x, y] = helio(b.id, date); push(b.id, comp(x - ex, y - ey), max) }
  }
  // Rellena la estela hacia atrás para que el dibujo se vea completo aunque esté en pausa.
  function prefill() {
    resetTrails();
    const n = mode === 'orbits' ? 60 : mode === 'vortex' ? 700 : 1200, step = STEP[mode];
    for (let k = n; k >= 0; k--) { const d = simDays - k * step; sample(new Date(Date.now() + d * 86400000), d) }
    lastSample = simDays;
  }

  function frame(now) {
    raf = 0;
    if (mode === 'classic' || !canvas) return;
    const dt = Math.min(.1, (now - (last || now)) / 1000); last = now;
    if (playing && motionOK) simDays += dt * speed;
    const date = new Date(Date.now() + simDays * 86400000), t = now / 1000, step = STEP[mode];
    let guard = 0;
    while (simDays - lastSample >= step && guard++ < 400) { lastSample += step; sample(new Date(Date.now() + lastSample * 86400000), lastSample) }
    if (canvas.clientWidth !== W) fit();
    background();
    if (mode === 'orbits') frameOrbits(date, motionOK ? t : 0);
    else if (mode === 'vortex') frameVortex(date, motionOK ? t : 0);
    else frameGeo(date);
    onDate?.(date, simDays);
    if (visible && playing && motionOK) raf = requestAnimationFrame(frame);
  }
  function kick() { if (!raf && mode !== 'classic') { last = 0; raf = requestAnimationFrame(frame) } }
  return {
    BODIES,
    init(cv, cb) {
      canvas = cv; g = cv.getContext('2d'); onDate = cb; fit(); resetTrails();
      new ResizeObserver(() => { fit(); kick() }).observe(cv);
      new IntersectionObserver(es => { visible = es[0].isIntersecting; if (visible) kick() }).observe(cv);
    },
    setMode(m) { mode = m; simDays = 0; if (m !== 'classic') { prefill(); fit(); kick() } },
    setPlaying(p) { playing = p; kick() },
    setSpeed(s) { speed = s; kick() },
    setMotion(ok) { motionOK = ok; kick() },
    reset() { simDays = 0; if (mode !== 'classic') prefill(); kick() },
    get mode() { return mode }, get playing() { return playing }
  };
})();
