/* Aura Crono · Relojes 3D: Sistema solar, Lluvia de código, Mundo de bloques, Pasillo retro (raycaster) y Pista de baile.
   Todo se dibuja en canvas 2D con Mini3D; la pista de baile y otros efectos reaccionan a la música de la radio. */
'use strict';
(() => {
  const { makeCanvas, pad, hourText, TAU } = FunClocks.util;
  const css = name => getComputedStyle(document.body).getPropertyValue(name);
  const FONT3 = {
    0: ['111', '101', '101', '101', '111'], 1: ['010', '110', '010', '010', '111'], 2: ['111', '001', '111', '100', '111'], 3: ['111', '001', '111', '001', '111'],
    4: ['101', '101', '111', '001', '001'], 5: ['111', '100', '111', '001', '111'], 6: ['111', '100', '111', '101', '111'], 7: ['111', '001', '010', '010', '010'],
    8: ['111', '101', '111', '101', '111'], 9: ['111', '101', '111', '001', '111'], ':': ['0', '1', '0', '1', '0']
  };
  // Devuelve las celdas encendidas de un texto con la fuente 3x5: [{x, y, ch, idx}]
  function glyphCells(text) {
    const cells = []; let x = 0;
    [...text].forEach((ch, idx) => {
      const g = FONT3[ch]; if (!g) { x += 2; return }
      g.forEach((row, y) => [...row].forEach((v, k) => { if (v === '1') cells.push({ x: x + k, y, ch, idx }) }));
      x += g[0].length + 1;
    });
    return { cells, width: x - 1 };
  }
  const timeText = (p, ctx) => `${hourText(p, ctx)}:${pad(p.minute)}`;
  const audioOf = ctx => ctx.audio || { bass: 0, mid: 0, treble: 0, energy: 0, beat: false, spectrum: new Float32Array(64), playing: false, sinceBeat: 9 };
  function roundedBg(g, W, H, top, bottom) {
    const gr = g.createLinearGradient(0, 0, 0, H); gr.addColorStop(0, top); gr.addColorStop(1, bottom);
    g.fillStyle = gr; g.beginPath(); g.roundRect(0, 0, W, H, 16); g.fill();
  }

  /* ── Avatar de bloques (genérico, original) ── */
  const OUTFITS = [
    { skin: '#f4c58a', shirt: '#e5484d', pants: '#2b4c8c', hair: '#4a2b16' },
    { skin: '#8d5a3b', shirt: '#2ec27e', pants: '#2d2d3a', hair: '#1b1b1b' },
    { skin: '#ffd9b3', shirt: '#3b82f6', pants: '#3a2a1a', hair: '#f2c94c' },
    { skin: '#c68863', shirt: '#a855f7', pants: '#1f6f78', hair: '#7a2e1a' },
    { skin: '#f0b98c', shirt: '#f59e0b', pants: '#334155', hair: '#111827' }
  ];
  function avatar(sc, pos, yaw, o, pose = {}) {
    const { armL = 0, armR = 0, legL = 0, legR = 0, bob = 0, spinHead = 0 } = pose;
    const cy = Math.cos(yaw), sy = Math.sin(yaw);
    const place = ([x, y, z]) => [pos[0] + x * cy - z * sy, pos[1] + y + bob, pos[2] + x * sy + z * cy];
    const limb = (pivot, ang) => q => { const dy = q[1] - pivot[1], dz = q[2] - pivot[2], c = Math.cos(ang), s = Math.sin(ang); return place([q[0], pivot[1] + dy * c - dz * s, pivot[2] + dy * s + dz * c]) };
    sc.box([-.24, .5, 0], [.42, 1, .44], o.pants, { map: limb([0, 1, 0], legL), stroke: 'rgba(0,0,0,.2)' });
    sc.box([.24, .5, 0], [.42, 1, .44], o.pants, { map: limb([0, 1, 0], legR), stroke: 'rgba(0,0,0,.2)' });
    sc.box([0, 1.6, 0], [1, 1.2, .5], o.shirt, { map: place, stroke: 'rgba(0,0,0,.2)' });
    sc.box([-.72, 1.65, 0], [.4, 1.1, .4], o.skin, { map: limb([0, 2.15, 0], armL), stroke: 'rgba(0,0,0,.2)' });
    sc.box([.72, 1.65, 0], [.4, 1.1, .4], o.skin, { map: limb([0, 2.15, 0], armR), stroke: 'rgba(0,0,0,.2)' });
    const head = q => { const c = Math.cos(spinHead), s = Math.sin(spinHead); return place([q[0] * c - q[2] * s, q[1], q[0] * s + q[2] * c]) };
    sc.box([0, 2.62, 0], [.82, .82, .82], o.skin, { map: head, faceColors: [o.skin, o.hair, o.hair, o.hair, o.hair, o.skin], stroke: 'rgba(0,0,0,.25)' });
    // Ojos y sonrisa en la cara frontal (-z local).
    const f = q => head(q);
    sc.poly([[-.25, 2.72, -.42], [-.25, 2.58, -.42], [-.12, 2.58, -.42], [-.12, 2.72, -.42]].map(f), '#1b1b1b', { light: false, cull: true });
    sc.poly([[.12, 2.72, -.42], [.12, 2.58, -.42], [.25, 2.58, -.42], [.25, 2.72, -.42]].map(f), '#1b1b1b', { light: false, cull: true });
    sc.poly([[-.18, 2.44, -.42], [-.12, 2.38, -.42], [.12, 2.38, -.42], [.18, 2.44, -.42]].map(f), '#5a2b1a', { light: false, cull: false });
  }

  /* ── 1. Sistema solar 3D: las manecillas son planetas ── */
  function solarClock() {
    let view, stars = null;
    return {
      mount(host) { view = makeCanvas(host, 1.15, 'Sistema solar 3D: el planeta exterior marca la hora, el azul los minutos y el rojo los segundos'); },
      render(p, ctx) {
        const g = view.g, W = view.w, H = view.h, t = performance.now() / 1000, sec = p.second + p.millis / 1000, au = audioOf(ctx);
        if (!stars || stars.w !== W) stars = { w: W, list: Array.from({ length: 120 }, () => [Math.random() * W, Math.random() * H, Math.random() * 1.4 + .2, Math.random() * TAU]) };
        roundedBg(g, W, H, '#05060f', '#0c1030');
        for (const [x, y, r, ph] of stars.list) { g.globalAlpha = .4 + .4 * Math.sin(t * 1.5 + ph); g.fillStyle = '#fff'; g.beginPath(); g.arc(x, y, r, 0, TAU); g.fill() }
        g.globalAlpha = 1;
        const yaw = ctx.reduced ? .25 : t * .04, pitch = .62;
        const cam = Mini3D.camera({ yaw, pitch, dist: 14, fov: 11, cx: W / 2, cy: H * .5, scale: W * .1 });
        const sc = Mini3D.scene(cam);
        const pos = (r, a, y = 0) => [r * Math.sin(a), y, r * Math.cos(a)];
        // Anillo de horas con números flotando.
        const ringPts = Mini3D.ring(sc, 0, 0, 0, 6.6, '', 1, 120);
        g.strokeStyle = 'rgba(160,190,255,.25)'; g.lineWidth = 1.2; g.beginPath(); ringPts.forEach((q, i) => i ? g.lineTo(q.x, q.y) : g.moveTo(q.x, q.y)); g.stroke();
        for (let i = 0; i < 60; i++) { const q = cam.project(pos(6.6, i / 60 * TAU)); g.fillStyle = i % 5 ? 'rgba(200,220,255,.35)' : 'rgba(255,230,170,.9)'; g.beginPath(); g.arc(q.x, q.y, (i % 5 ? .04 : .09) * q.f, 0, TAU); g.fill() }
        for (let i = 1; i <= 12; i++) {
          const q = cam.project(pos(7.4, i / 12 * TAU, .2));
          sc.custom(q.z, gg => { gg.fillStyle = 'rgba(230,236,255,.85)'; gg.font = `600 ${Math.round(q.f * .55)}px Manrope, sans-serif`; gg.textAlign = 'center'; gg.textBaseline = 'middle'; gg.fillText(i, q.x, q.y) });
        }
        const hA = ((p.hour % 12) + p.minute / 60 + sec / 3600) / 12 * TAU, mA = (p.minute + sec / 60) / 60 * TAU, sA = sec / 60 * TAU;
        const orbits = [[5.4, hA, ['#ffe9b8', '#e0a85a', '#5a3510'], .55, 'rgba(255,200,120,', 'rgba(230,200,150,.8)'], [3.8, mA, ['#bfe4ff', '#2f7ad9', '#0a2350'], .42, 'rgba(110,180,255,', null], [2.4, sA, ['#ffc2a8', '#e0572e', '#4a1205'], .26, 'rgba(255,120,90,', null]];
        for (const [r, a, cols, size, trail, ringCol] of orbits) {
          const pts = Mini3D.ring(sc, 0, 0, 0, r, '', 1, 100);
          g.strokeStyle = 'rgba(255,255,255,.08)'; g.lineWidth = 1; g.beginPath(); pts.forEach((q, i) => i ? g.lineTo(q.x, q.y) : g.moveTo(q.x, q.y)); g.stroke();
          // Estela luminosa detrás del planeta.
          for (let k = 0; k < 24; k++) {
            const a0 = a - k * .035, a1 = a - (k + 1) * .035, q0 = cam.project(pos(r, a0)), q1 = cam.project(pos(r, a1));
            g.strokeStyle = trail + (1 - k / 24) * .6 + ')'; g.lineWidth = size * q0.f * .5 * (1 - k / 24); g.lineCap = 'round';
            g.beginPath(); g.moveTo(q0.x, q0.y); g.lineTo(q1.x, q1.y); g.stroke();
          }
          const pp = pos(r, a);
          sc.line([0, 0, 0], pp, 'rgba(255,255,255,.12)', 1);
          sc.sphere(pp, size, cols, { glow: 14, ring: ringCol });
          if (r === 3.8) { const ma = t * 2; sc.sphere([pp[0] + .8 * Math.cos(ma), .1, pp[2] + .8 * Math.sin(ma)], .1, ['#fff', '#bbb', '#444']) }
        }
        const pulse = 1 + au.bass * .25;
        const sp = cam.project([0, 0, 0]);
        sc.custom(sp.z, gg => {
          const r = sp.f * 1.1 * pulse, gl = gg.createRadialGradient(sp.x, sp.y, r * .2, sp.x, sp.y, r * 3.2);
          gl.addColorStop(0, 'rgba(255,230,140,.9)'); gl.addColorStop(.3, 'rgba(255,170,60,.35)'); gl.addColorStop(1, 'rgba(255,120,30,0)');
          gg.fillStyle = gl; gg.beginPath(); gg.arc(sp.x, sp.y, r * 3.2, 0, TAU); gg.fill();
          const core = gg.createRadialGradient(sp.x - r * .3, sp.y - r * .3, r * .1, sp.x, sp.y, r);
          core.addColorStop(0, '#fffbe0'); core.addColorStop(.5, '#ffcf4a'); core.addColorStop(1, '#f08a1c');
          gg.fillStyle = core; gg.beginPath(); gg.arc(sp.x, sp.y, r, 0, TAU); gg.fill();
        });
        sc.render(g);
        g.fillStyle = '#e8eeff'; g.textAlign = 'center'; g.font = `700 ${Math.round(W * .07)}px Manrope, sans-serif`; g.shadowColor = 'rgba(120,160,255,.6)'; g.shadowBlur = 16;
        g.fillText(`${timeText(p, ctx)}:${pad(p.second)}`, W / 2, H * .94); g.shadowBlur = 0;
        g.font = `600 ${Math.round(W * .022)}px "DM Sans"`; g.fillStyle = 'rgba(220,230,255,.6)';
        g.fillText('● HORA   ● MINUTOS   ● SEGUNDOS', W / 2, H * .06);
      },
      unmount() { view?.ro.disconnect(); view?.c.remove(); }
    };
  }

  /* ── 2. Lluvia de código: la hora brilla dentro de la lluvia, con tres capas de profundidad ── */
  const GLYPHS = 'ｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾅﾆﾇﾈﾉﾊﾋﾌﾍﾎﾏﾐﾑﾒﾓﾔﾕﾖﾗﾘﾙﾚﾛﾜﾝ0123456789:=+*<>';
  const rndGlyph = () => GLYPHS[Math.floor(Math.random() * GLYPHS.length)];
  function codeRain() {
    let view, layers = null, mask = null, maskKey = '', last = 0;
    function setup(W, H) {
      layers = [[W / 48, .35, .4, 2], [W / 32, .6, .7, 0], [W / 21, 1, 1.05, 0]].map(([cell, alpha, speed, blur]) => {
        const cols = Math.ceil(W / cell), rows = Math.ceil(H / cell);
        return { cell, alpha, speed, blur, cols, rows, drops: Array.from({ length: cols }, () => ({ y: Math.random() * rows * 2 - rows, v: (.25 + Math.random() * .5) * speed, len: 6 + Math.random() * 18 })), chars: Array.from({ length: cols * rows }, rndGlyph) };
      });
      layers.W = W;
    }
    function buildMask(text, sec, L) {
      const key = text + '|' + sec + '|' + L.cols; if (key === maskKey) return; maskKey = key;
      mask = new Uint8Array(L.cols * L.rows);
      const put = (str, row0) => { const { cells, width } = glyphCells(str), x0 = Math.floor((L.cols - width) / 2); for (const c of cells) { const x = x0 + c.x, y = row0 + c.y; if (x >= 0 && x < L.cols && y >= 0 && y < L.rows) mask[y * L.cols + x] = 1 } };
      const top = Math.max(0, Math.floor(L.rows / 2) - 6);
      put(text, top); put(sec, top + 7);
    }
    return {
      mount(host) { view = makeCanvas(host, 1.3, 'Lluvia de código: la hora aparece formada por caracteres brillantes'); },
      render(p, ctx) {
        const g = view.g, W = view.w, H = view.h, now = performance.now(), au = audioOf(ctx);
        if (!layers || layers.W !== W) setup(W, H);
        const dt = Math.min(.05, (now - (last || now)) / 1000); last = now;
        roundedBg(g, W, H, '#010702', '#020d05');
        const front = layers[2];
        buildMask(timeText(p, ctx), pad(p.second), front);
        layers.forEach((L, li) => {
          g.font = `${Math.round(L.cell * .9)}px "DM Mono", monospace`; g.textAlign = 'center'; g.textBaseline = 'top';
          for (let c = 0; c < L.cols; c++) {
            const d = L.drops[c];
            if (!ctx.reduced) { d.y += d.v * (1 + au.energy * 1.5) * dt * 30; if (d.y - d.len > L.rows) { d.y = -Math.random() * 10; d.v = (.25 + Math.random() * .5) * L.speed; d.len = 6 + Math.random() * 18 } }
            const head = Math.floor(d.y);
            for (let k = 0; k < d.len; k++) {
              const r = head - k; if (r < 0 || r >= L.rows) continue;
              if (li === 2 && mask[r * L.cols + c]) continue;
              if (Math.random() < .02) L.chars[r * L.cols + c] = rndGlyph();
              const a = (1 - k / d.len) * L.alpha;
              g.fillStyle = k === 0 ? `rgba(220,255,225,${L.alpha})` : `rgba(40,255,110,${a})`;
              g.fillText(L.chars[r * L.cols + c], c * L.cell + L.cell / 2, r * L.cell);
            }
          }
        });
        // Hora: celdas de la capa frontal dentro de la máscara, siempre encendidas.
        const L = front; g.font = `700 ${Math.round(L.cell * .9)}px "DM Mono", monospace`;
        g.shadowColor = '#3dff88'; g.shadowBlur = 10 + au.bass * 14;
        for (let r = 0; r < L.rows; r++) for (let c = 0; c < L.cols; c++) {
          if (!mask[r * L.cols + c]) continue;
          if (Math.random() < .03) L.chars[r * L.cols + c] = rndGlyph();
          g.shadowBlur = 0; g.fillStyle = 'rgba(30,255,110,.42)'; g.fillRect(c * L.cell + 1, r * L.cell + 1, L.cell - 2, L.cell - 2); g.shadowBlur = 10 + au.bass * 14;
          const lit = Math.abs(Math.floor(L.drops[c].y) - r) < 2;
          g.fillStyle = lit ? '#ffffff' : '#eafff0';
          g.fillText(L.chars[r * L.cols + c], c * L.cell + L.cell / 2, r * L.cell);
        }
        g.shadowBlur = 0;
      },
      unmount() { view?.ro.disconnect(); view?.c.remove(); }
    };
  }

  /* ── 3. Mundo de bloques: dígitos de cubos y personajes que caminan y saltan ── */
  const BLOCK_COLORS = ['#e5484d', '#3b82f6', '#f5c518', '#2ec27e', '#a855f7', '#f97316'];
  function blockWorld() {
    let view, lastText = '', dropStart = new Map();
    return {
      mount(host) { view = makeCanvas(host, 1.25, 'Mundo de bloques: la hora construida con cubos y personajes jugando alrededor'); },
      render(p, ctx) {
        const g = view.g, W = view.w, H = view.h, t = performance.now() / 1000, sec = p.second + p.millis / 1000;
        const text = timeText(p, ctx);
        if (text !== lastText) { [...text].forEach((ch, i) => { if (lastText[i] !== ch) dropStart.set(i, ctx.reduced ? -9 : t) }); lastText = text }
        roundedBg(g, W, H, '#7cc8ff', '#d6f0ff');
        g.fillStyle = 'rgba(255,255,255,.9)';
        for (const [x, y, s] of [[.15, .12, 1], [.7, .08, 1.3], [.45, .2, .8]]) { const cx = ((x * W + t * 8 * s) % (W + 120)) - 60; for (const [dx, w] of [[0, 50], [30, 70], [70, 45]]) g.fillRect(cx + dx * s, y * H + (dx === 30 ? -10 : 0) * s, w * s, 22 * s) }
        const yaw = ctx.reduced ? -.35 : -.35 + Math.sin(t * .2) * .35;
        const cam = Mini3D.camera({ yaw, pitch: .38, dist: 16, fov: 14, cx: W / 2, cy: H * .55, scale: W * .072, target: [0, 2.2, 0] });
        const sc = Mini3D.scene(cam);
        // Suelo de pasto.
        sc.box([0, -.5, .5], [21, 1, 10], '#5fbf3c', { faceColors: [null, null, '#8a5a32', '#8a5a32', '#5fbf3c', '#6b4424'].map(c => c || '#8a5a32'), stroke: 'rgba(0,0,0,.15)' });
        // Dígitos de cubos (solo caras expuestas).
        const { cells, width } = glyphCells(text), occ = new Set(cells.map(c => c.x + ',' + c.y));
        for (const c of cells) {
          const ds = dropStart.get(c.idx) ?? -9, k = Math.min(1, (t - ds) / .7 + (4 - c.y) * -.08), fall = k < 1 ? (1 - Math.max(0, k)) ** 2 * 14 : 0;
          const x = c.x - width / 2 + .5, y = (4 - c.y) + .5 + fall;
          const has = (dx, dy) => occ.has((c.x + dx) + ',' + (c.y + dy)) && !fall;
          sc.box([x, y, 0], [1, 1, 1], BLOCK_COLORS[c.idx % BLOCK_COLORS.length], { skip: [false, false, has(-1, 0), has(1, 0), has(0, -1), has(0, 1)], stroke: 'rgba(0,0,0,.25)' });
        }
        // Barra de segundos: 12 losetas que se iluminan cada 5 s.
        for (let i = 0; i < 12; i++) { const on = i < Math.floor(sec / 5) + 1; sc.box([-6.6 + i * 1.2, .05, -3], [1, .1, 1], on ? '#ffd23f' : '#3f8f2c', { stroke: 'rgba(0,0,0,.2)' }) }
        // Moneda giratoria encima.
        const coin = [-6.6 + Math.floor(sec / 5) * 1.2, 1.2 + Math.sin(t * 3) * .2, -3];
        sc.box(coin, [.7, .7, .12], '#ffd23f', { yaw: t * 4, glow: 8 });
        // Personajes: uno camina, otro salta sobre los dígitos y otro saluda.
        const walkA = ctx.reduced ? 0 : t * .5, sw = ctx.reduced ? 0 : Math.sin(t * 8) * .7;
        const wx = Math.cos(walkA) * 8, wz = 1.5 + Math.sin(walkA) * 3;
        avatar(sc, [wx, 0, wz], -walkA - Math.PI, OUTFITS[0], { armL: sw, armR: -sw, legL: -sw, legR: sw });
        const hop = ctx.reduced ? 0 : Math.abs(Math.sin(t * 2.4)) * 1.6, jx = ctx.reduced ? 0 : ((t * .9) % (width + 2)) - width / 2 - 1;
        avatar(sc, [jx, 5, 0], -Math.PI / 2, OUTFITS[1], { armL: -1.5, armR: -1.5, bob: hop, legL: .4, legR: -.4 });
        const wave = ctx.reduced ? -2.5 : -2.4 + Math.sin(t * 6) * .5;
        avatar(sc, [6.5, 0, -1.5], .4, OUTFITS[2], { armR: wave, armL: .1 });
        sc.render(g);
        g.fillStyle = '#123'; g.textAlign = 'left'; g.font = `800 ${Math.round(W * .035)}px Manrope, sans-serif`;
        g.fillText(`⏱ ${pad(p.second)}s`, W * .04, H * .08);
      },
      unmount() { view?.ro.disconnect(); view?.c.remove(); }
    };
  }

  /* ── 4. Pasillo retro (raycaster pseudo-3D con HUD) ── */
  const MAP = [
    '1311111111111111',
    '1000000000000003',
    '1011113333111101',
    '1010000000000101',
    '1010222002220101',
    '1000200000020001',
    '1010200110020101',
    '3000000110000003',
    '3000000110000003',
    '1010200110020101',
    '1000200000020001',
    '1010222002220101',
    '1010000000000101',
    '1011113333111101',
    '3000000000000001',
    '1111111111111131'
  ];
  // Recorrido en circuito por el pasillo exterior (todas las celdas libres).
  const PATH = [[1.5, 1.5], [8, 1.5], [14.5, 1.5], [14.5, 8], [14.5, 14.5], [8, 14.5], [1.5, 14.5], [1.5, 8], [1.5, 1.5]];
  const CREATURE = [
    '...r....r...', '..rr....rr..', '..rrrrrrrr..', '.rrrrrrrrrr.', '.rryyrryyrr.', '.rrrrrrrrrr.',
    '.rrwdwdwdwr.', '..rrrrrrrr..', '.rr.rrrr.rr.', 'rd..rrrr..dr', 'r...rd.dr..r', '....rr..rr..'
  ];
  function makeTextures() {
    const T = 32, mk = fn => { const a = new Uint32Array(T * T); for (let y = 0; y < T; y++) for (let x = 0; x < T; x++) a[y * T + x] = fn(x, y); return a };
    const col = (r, g, b) => (255 << 24) | (b << 16) | (g << 8) | r, noise = (x, y) => ((x * 73856093) ^ (y * 19349663)) % 23 / 23;
    const brick = mk((x, y) => { const row = Math.floor(y / 8), off = row % 2 ? 8 : 0, mortar = y % 8 === 0 || (x + off) % 16 === 0, n = noise(x, y) * 30; return mortar ? col(60, 50, 45) : col(130 + n, 52 + n * .5, 38) });
    const tech = mk((x, y) => { const edge = x < 2 || y < 2 || x > 29 || y > 29, light = y > 12 && y < 16 && x > 6 && x < 26, n = noise(x, y) * 20; return edge ? col(60, 66, 74) : light ? col(80, 200 + n, 255) : col(108 + n, 112 + n, 120 + n) });
    return { T, brick, tech, col };
  }
  function retroFPS() {
    let view, buf, bctx, img, px, tex, clockTex = null, clockKey = '', zbuf, flash = 0, lastSec = -1;
    const BW = 240, BH = 140;
    function updateClockTexture(text) {
      if (text === clockKey) return; clockKey = text;
      const T = tex.T, c = document.createElement('canvas'); c.width = T; c.height = T; const g = c.getContext('2d');
      g.fillStyle = '#1a0b0b'; g.fillRect(0, 0, T, T); g.strokeStyle = '#555'; g.strokeRect(1, 1, T - 2, T - 2);
      g.fillStyle = '#ff3b2f'; g.font = 'bold 11px monospace'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(text, T / 2, T / 2 + 1);
      const d = g.getImageData(0, 0, T, T).data; clockTex = new Uint32Array(T * T);
      for (let i = 0; i < T * T; i++) clockTex[i] = (255 << 24) | (d[i * 4 + 2] << 16) | (d[i * 4 + 1] << 8) | d[i * 4];
    }
    function pathPos(u) {
      const n = PATH.length - 1, seg = u * n, i = Math.floor(seg) % n, f = seg - Math.floor(seg);
      const a = PATH[i], b = PATH[i + 1], ease = f * f * (3 - 2 * f);
      return [a[0] + (b[0] - a[0]) * ease, a[1] + (b[1] - a[1]) * ease, Math.atan2(b[1] - a[1], b[0] - a[0])];
    }
    return {
      mount(host) {
        view = makeCanvas(host, 1.3, 'Pasillo retro en primera persona: la hora aparece en los muros y en el panel inferior');
        buf = document.createElement('canvas'); buf.width = BW; buf.height = BH; bctx = buf.getContext('2d');
        img = bctx.createImageData(BW, BH); px = new Uint32Array(img.data.buffer); tex = makeTextures(); zbuf = new Float32Array(BW);
      },
      render(p, ctx) {
        const g = view.g, W = view.w, H = view.h, t = performance.now() / 1000, sec = p.second + p.millis / 1000, au = audioOf(ctx);
        updateClockTexture(timeText(p, ctx));
        if (p.second !== lastSec) { if (p.second % 5 === 0 && !ctx.reduced) flash = 1; lastSec = p.second }
        flash *= .85;
        // Cámara: recorre el laberinto suavizando el giro.
        const u = ctx.reduced ? 0 : (t / 70) % 1, [px0, py0] = pathPos(u), ahead = pathPos((u + .012) % 1);
        const dir = Math.atan2(ahead[1] - py0, ahead[0] - px0), bob = ctx.reduced ? 0 : Math.sin(t * 9) * 2;
        const dx = Math.cos(dir), dy = Math.sin(dir), plx = dy * .66, ply = -dx * .66, T = tex.T, half = BH / 2 + bob;
        for (let y = 0; y < BH; y++) {
          const fog = Math.min(1, Math.abs(y - half) / (BH / 2));
          const c = y < half ? tex.col(20 + 40 * fog, 20 + 30 * fog, 30 + 30 * fog) : tex.col(40 + 60 * fog, 30 + 40 * fog, 25 + 25 * fog);
          px.fill(c, y * BW, (y + 1) * BW);
        }
        for (let x = 0; x < BW; x++) {
          const cam = 2 * x / BW - 1, rdx = dx + plx * cam, rdy = dy + ply * cam;
          let mx = Math.floor(px0), my = Math.floor(py0);
          const ddx = Math.abs(1 / rdx), ddy = Math.abs(1 / rdy), sx = rdx < 0 ? -1 : 1, sy = rdy < 0 ? -1 : 1;
          let sdx = (rdx < 0 ? px0 - mx : mx + 1 - px0) * ddx, sdy = (rdy < 0 ? py0 - my : my + 1 - py0) * ddy, side = 0, cell = '0';
          for (let k = 0; k < 64; k++) { if (sdx < sdy) { sdx += ddx; mx += sx; side = 0 } else { sdy += ddy; my += sy; side = 1 } cell = MAP[my]?.[mx] || '1'; if (cell !== '0') break }
          const dist = side ? sdy - ddy : sdx - ddx; zbuf[x] = dist;
          const lh = Math.floor(BH / Math.max(.05, dist)), y0 = Math.floor(half - lh / 2), y1 = y0 + lh;
          let wx = side ? px0 + dist * rdx : py0 + dist * rdy; wx -= Math.floor(wx);
          let tx = Math.floor(wx * T); if ((!side && rdx > 0) || (side && rdy < 0)) tx = T - 1 - tx;
          const src = cell === '3' ? clockTex : cell === '2' ? tex.tech : tex.brick;
          const shadeK = Math.max(.25, 1 - dist / 12) * (side ? .75 : 1), lit = 1 + flash * .6;
          for (let y = Math.max(0, y0); y < Math.min(BH, y1); y++) {
            const ty = Math.floor((y - y0) / lh * T), c = src[ty * T + tx];
            const r = Math.min(255, (c & 255) * shadeK * lit), gg = Math.min(255, (c >> 8 & 255) * shadeK * lit), b = Math.min(255, (c >> 16 & 255) * shadeK * lit);
            px[y * BW + x] = (255 << 24) | (b << 16) | (gg << 8) | r;
          }
        }
        bctx.putImageData(img, 0, 0);
        // Criaturas (sprites) ordenadas por distancia y recortadas con el z-buffer.
        // Dos criaturas huyen por el pasillo delante de la cámara.
        const sprites = [1, 2].map(i => { const [ax, ay, ad] = pathPos((u + .035 * i + 1) % 1), side = i === 1 ? .22 : -.22; return { mx: ax - Math.sin(ad) * side, my: ay + Math.cos(ad) * side, i } })
          .map(s => ({ ...s, d: (s.mx - px0) ** 2 + (s.my - py0) ** 2 })).sort((a, b) => b.d - a.d);
        for (const s of sprites) {
          const rx = s.mx - px0, ry = s.my - py0, inv = 1 / (plx * dy - dx * ply);
          const tX = inv * (dy * rx - dx * ry), tY = inv * (-ply * rx + plx * ry);
          if (tY <= .2) continue;
          const sxc = Math.floor(BW / 2 * (1 + tX / tY)), sh = Math.abs(Math.floor(BH / tY)) * .5, hop = Math.abs(Math.sin(t * 4 + s.i)) * sh * .1 * (1 + au.bass);
          const top = half + BH / tY / 2 - sh - hop;
          const shadeK = Math.max(.3, 1 - tY / 10), pal = { r: `rgb(${Math.round(200 * shadeK)},${Math.round(40 * shadeK)},${Math.round(36 * shadeK)})`, d: `rgb(${Math.round(120 * shadeK)},20,20)`, y: '#ffe14a', w: '#f4ead2' };
          const px = sh / 12;
          for (let col = Math.floor(sxc - sh / 2); col < sxc + sh / 2; col++) {
            if (col < 0 || col >= BW || zbuf[col] < tY) continue;
            const bx = Math.min(11, Math.floor((col - (sxc - sh / 2)) / px));
            for (let by = 0; by < 12; by++) { const ch = CREATURE[by][bx]; if (ch === '.') continue; bctx.fillStyle = pal[ch]; bctx.fillRect(col, top + by * px, 1, px + .5) }
          }
        }
        g.imageSmoothingEnabled = false;
        const hudH = H * .2, viewH = H - hudH;
        g.save(); g.beginPath(); g.roundRect(0, 0, W, H, 14); g.clip();
        g.drawImage(buf, 0, 0, W, viewH);
        // Arma genérica con bamboleo y fogonazo cada 5 s.
        const gx = W / 2 + Math.sin(t * 4.5) * W * .015 * (ctx.reduced ? 0 : 1), gy = viewH - H * .02 + Math.abs(Math.cos(t * 4.5)) * 6 * (ctx.reduced ? 0 : 1);
        if (flash > .3) { g.fillStyle = `rgba(255,220,120,${flash})`; g.beginPath(); g.arc(gx, gy - H * .2, W * .05 * flash + 10, 0, TAU); g.fill() }
        g.fillStyle = '#3a3a40'; g.fillRect(gx - W * .035, gy - H * .2, W * .07, H * .2);
        g.fillStyle = '#5b5b66'; g.fillRect(gx - W * .05, gy - H * .08, W * .1, H * .08);
        g.fillStyle = '#7a4a2a'; g.fillRect(gx - W * .06, gy - H * .03, W * .12, H * .05);
        // HUD inferior.
        const hy = viewH; g.fillStyle = '#3b3530'; g.fillRect(0, hy, W, hudH);
        g.fillStyle = '#5a5249'; for (let i = 0; i < W; i += 6) g.fillRect(i, hy + (i % 12 ? 2 : 4), 3, 2);
        const panels = [['HORA', timeText(p, ctx), .3], ['SEG', pad(p.second), .14], ['NIVEL', String(p.hour), .14], ['ENERGÍA', Math.round(100 - sec / 60 * 100) + '%', .2]];
        let x = W * .03;
        for (const [label, val, w] of panels) {
          const pw = W * w; g.fillStyle = '#26211d'; g.fillRect(x, hy + hudH * .12, pw, hudH * .76);
          g.fillStyle = '#e8352a'; g.font = `900 ${Math.round(hudH * .44)}px "DM Mono", monospace`; g.textAlign = 'center'; g.textBaseline = 'middle';
          g.shadowColor = '#ff3b2f'; g.shadowBlur = 6; g.fillText(val, x + pw / 2, hy + hudH * .45); g.shadowBlur = 0;
          g.fillStyle = '#c8b9a6'; g.font = `700 ${Math.round(hudH * .14)}px "DM Sans"`; g.fillText(label, x + pw / 2, hy + hudH * .78);
          x += pw + W * .02;
        }
        g.restore();
      },
      unmount() { view?.ro.disconnect(); view?.c.remove(); }
    };
  }

  /* ── 5. Pista de baile: la hora se ilumina en el piso y los personajes bailan con la música ── */
  function danceFloor() {
    let view, beatFlash = 0, moveSet = 0, lastBeat = 0;
    const COLS = 21, ROWS = 11;
    const NEON = ['#ff2e88', '#00e5ff', '#ffe600', '#7c4dff', '#00ff95', '#ff7a00'];
    return {
      mount(host) { view = makeCanvas(host, 1.25, 'Pista de baile: la hora se dibuja con las losetas iluminadas y los personajes bailan al ritmo de la radio'); },
      render(p, ctx) {
        const g = view.g, W = view.w, H = view.h, t = performance.now() / 1000, au = audioOf(ctx), sec = p.second + p.millis / 1000;
        if (au.beat) { beatFlash = 1; lastBeat = t; if (Math.random() < .25) moveSet = (moveSet + 1) % 4 }
        beatFlash *= .9;
        roundedBg(g, W, H, '#0a0016', '#16002e');
        const cam = Mini3D.camera({ yaw: ctx.reduced ? 0 : Math.sin(t * .25) * .25, pitch: .62, dist: 16, fov: 13, cx: W / 2, cy: H * .6, scale: W * .055, target: [0, 1, 0] });
        const sc = Mini3D.scene(cam);
        // Haces de luz desde la bola disco.
        const ball = [0, 8.2, 2];
        const bp = cam.project(ball);
        g.globalCompositeOperation = 'lighter';
        for (let i = 0; i < 6; i++) {
          const a = t * .7 + i * TAU / 6, end = cam.project([Math.cos(a) * 9, 0, Math.sin(a) * 5]), col = NEON[i];
          const gr = g.createLinearGradient(bp.x, bp.y, end.x, end.y); gr.addColorStop(0, col + 'aa'); gr.addColorStop(1, col + '00');
          g.fillStyle = gr; g.beginPath(); g.moveTo(bp.x, bp.y); g.lineTo(end.x - 30, end.y); g.lineTo(end.x + 30, end.y); g.closePath(); g.globalAlpha = .25 + au.energy * .4; g.fill();
        }
        g.globalAlpha = 1; g.globalCompositeOperation = 'source-over';
        // Piso: losetas; la hora en blanco.
        const { cells, width } = glyphCells(timeText(p, ctx)), lit = new Set(cells.map(c => (c.x + Math.floor((COLS - width) / 2)) + ',' + (c.y + 3)));
        for (let r = 0; r < ROWS; r++) for (let c = 0; c < COLS; c++) {
          const x = c - COLS / 2, z = (ROWS / 2 - r) * 1;
          const isTime = lit.has(c + ',' + r), band = au.spectrum[(c * 3) % 64] || 0;
          let color;
          if (isTime) color = '#ffffff';
          else { const k = (Math.sin(t * 3 + c * .7 + r * 1.3) + 1) / 2, on = ctx.reduced ? .3 : band * .9 + beatFlash * .3 + k * .15; color = Mini3D.shade(NEON[(c + r + Math.floor(t * 2)) % NEON.length], .25 + on * .9) }
          sc.poly([[x, 0, z], [x + .94, 0, z], [x + .94, 0, z - .94], [x, 0, z - .94]], color, { light: false, cull: false });
        }
        // Barra de segundos al frente de la pista.
        for (let i = 0; i < 60; i++) { const on = i <= p.second, x = -COLS / 2 + i * COLS / 60; sc.poly([[x, .01, -ROWS / 2 - .3], [x + COLS / 60 * .8, .01, -ROWS / 2 - .3], [x + COLS / 60 * .8, .01, -ROWS / 2 - .7], [x, .01, -ROWS / 2 - .7]], on ? '#ffffff' : '#2a1846', { light: false, cull: false }) }
        // Bailarines.
        const playing = au.playing, bpmT = t * (playing ? 2.1 : 1.2), kick = Math.max(0, 1 - (t - lastBeat) * 3);
        const spots = [[-7.5, 2.6], [-3.5, -3.8], [3.5, -3.8], [7.5, 2.6], [0, 4.4]];
        spots.forEach(([x, z], i) => {
          const ph = bpmT * Math.PI + i * .8, bounce = Math.abs(Math.sin(ph)) * (.35 + au.bass * .5), mv = (moveSet + i) % 4;
          let pose;
          if (ctx.reduced) pose = {};
          else if (mv === 0) pose = { armL: -2.8 + Math.sin(ph) * .4, armR: -2.8 - Math.sin(ph) * .4, legL: Math.sin(ph) * .3, legR: -Math.sin(ph) * .3, bob: bounce };
          else if (mv === 1) pose = { armL: Math.sin(ph) * 1.4, armR: -Math.sin(ph) * 1.4, legL: -Math.sin(ph) * .6, legR: Math.sin(ph) * .6, bob: bounce * .6 };
          else if (mv === 2) pose = { armL: -1.6, armR: -1.6 + Math.sin(ph * 2) * .8, bob: bounce + kick * .8, legL: .4 * kick, legR: -.4 * kick };
          else pose = { armL: -3, armR: .3, bob: bounce * .5, spinHead: Math.sin(ph) * .5 };
          const yaw = ctx.reduced ? 0 : (mv === 3 ? t * 3 : Math.sin(ph * .5) * .5);
          avatar(sc, [x, 0, z], yaw, OUTFITS[i % OUTFITS.length], pose);
        });
        sc.render(g);
        // Bola disco.
        const br = bp.f * 1.1;
        const disco = g.createRadialGradient(bp.x - br * .3, bp.y - br * .3, 2, bp.x, bp.y, br); disco.addColorStop(0, '#ffffff'); disco.addColorStop(.6, '#9aa4c4'); disco.addColorStop(1, '#3a3f5c');
        g.fillStyle = disco; g.beginPath(); g.arc(bp.x, bp.y, br, 0, TAU); g.fill();
        g.save(); g.beginPath(); g.arc(bp.x, bp.y, br, 0, TAU); g.clip();
        for (let i = 0; i < 40; i++) { const a = i * 2.4 + t, rr = br * ((i * 37) % 100) / 100; const s = (Math.sin(t * 6 + i) + 1) / 2; g.fillStyle = `rgba(255,255,255,${s * .9})`; g.fillRect(bp.x + Math.cos(a) * rr - 2, bp.y + Math.sin(a) * rr - 2, 4, 4) }
        g.restore();
        g.strokeStyle = 'rgba(200,200,220,.5)'; g.beginPath(); g.moveTo(bp.x, 0); g.lineTo(bp.x, bp.y - br); g.stroke();
        g.fillStyle = '#fff'; g.textAlign = 'center'; g.font = `800 ${Math.round(W * .032)}px Manrope`;
        g.fillText(playing ? (au.real ? '♫ BAILANDO CON LA RADIO' : '♫ BAILANDO AL RITMO') : '▶ Pon la radio para que bailen', W / 2, H * .965);
        void sec;
      },
      unmount() { view?.ro.disconnect(); view?.c.remove(); }
    };
  }

  FunClocks.register('3d', [['solar', 'Sistema solar'], ['codigo', 'Lluvia de código'], ['bloques', 'Mundo de bloques'], ['retro', 'Pasillo retro FPS'], ['baile', 'Pista de baile']],
    style => ({ solar: solarClock, codigo: codeRain, bloques: blockWorld, retro: retroFPS, baile: danceFloor }[style] || solarClock)());
})();
