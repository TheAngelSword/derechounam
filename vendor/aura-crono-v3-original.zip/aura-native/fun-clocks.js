/* Aura Crono · Núcleo de relojes divertidos + Tetris (canvas) y Creativos (palabras, arena, paisaje).
   Cada reloj expone mount(host) / render(p, ctx) / unmount(); solo se dibuja el que está visible. */
'use strict';
const FunClocks = (() => {
  const pad = n => String(n).padStart(2, '0');
  const TAU = Math.PI * 2;
  const reduced = () => window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
  const hourText = (p, ctx) => pad(ctx.format === 24 ? p.hour : (p.hour % 12 || 12));
  const angles = p => {
    const s = p.second + p.millis / 1000;
    return { h: ((p.hour % 12) + p.minute / 60 + s / 3600) * 30, m: (p.minute + s / 60) * 6, s: s * 6, sec: s };
  };

  /* Canvas con escalado por densidad de píxeles y redimensionado automático. */
  function makeCanvas(host, ratio, label) {
    const c = document.createElement('canvas');
    c.className = 'fun-canvas';
    c.setAttribute('role', 'img');
    c.setAttribute('aria-label', label);
    c.style.aspectRatio = String(ratio);
    host.appendChild(c);
    const g = c.getContext('2d');
    const view = { c, g, w: 0, h: 0 };
    const fit = () => {
      const dpr = Math.min(2, window.devicePixelRatio || 1), w = c.clientWidth || 400, h = w / ratio;
      c.width = Math.round(w * dpr); c.height = Math.round(h * dpr);
      g.setTransform(dpr, 0, 0, dpr, 0, 0); view.w = w; view.h = h;
    };
    fit();
    view.ro = new ResizeObserver(fit); view.ro.observe(c);
    return view;
  }

  /* ───────────────────────── TETRIS ───────────────────────── */
  const GLYPHS = {
    0: ['#####', '#...#', '#...#', '#...#', '#...#', '#...#', '#####'],
    1: ['..#..', '.##..', '..#..', '..#..', '..#..', '..#..', '.###.'],
    2: ['#####', '....#', '....#', '#####', '#....', '#....', '#####'],
    3: ['#####', '....#', '....#', '.####', '....#', '....#', '#####'],
    4: ['#...#', '#...#', '#...#', '#####', '....#', '....#', '....#'],
    5: ['#####', '#....', '#....', '#####', '....#', '....#', '#####'],
    6: ['#####', '#....', '#....', '#####', '#...#', '#...#', '#####'],
    7: ['#####', '....#', '...#.', '..#..', '..#..', '..#..', '..#..'],
    8: ['#####', '#...#', '#...#', '#####', '#...#', '#...#', '#####'],
    9: ['#####', '#...#', '#...#', '#####', '....#', '....#', '#####'],
    ':': ['.', '.', '#', '.', '#', '.', '.']
  };
  const TETRIS_PALETTES = {
    clasico: { bg: '#0a1020', grid: 'rgba(120,150,200,.08)', frame: '#2a3a5c', text: '#cfe3ff', colors: ['#22d3ee', '#facc15', '#a855f7', '#4ade80', '#f87171', '#60a5fa', '#fb923c'] },
    turbo: { bg: '#120818', grid: 'rgba(255,120,220,.07)', frame: '#4a2160', text: '#ffd6f5', colors: ['#ff4fd8', '#00f0ff', '#fff04f', '#7cff6b', '#ff7a45', '#a78bfa', '#ff4f6d'] },
    gameboy: { bg: '#9bbc0f', grid: 'rgba(15,56,15,.1)', frame: '#306230', text: '#0f380f', colors: ['#0f380f', '#306230', '#0f380f', '#306230', '#0f380f', '#306230', '#0f380f'] }
  };
  const TOP = 6, DIGIT_ROWS = 7;

  function chunkGlyph(char, col0) {
    const g = GLYPHS[char], cells = new Set(), key = (r, c) => r * 100 + c;
    g.forEach((row, r) => [...row].forEach((ch, c) => { if (ch === '#') cells.add(key(r + TOP, c + col0)); }));
    const order = [...cells].sort((a, b) => (Math.floor(b / 100) - Math.floor(a / 100)) || (a % 100 - b % 100));
    const taken = new Set(), pieces = [];
    for (const start of order) {
      if (taken.has(start)) continue;
      const piece = [start]; taken.add(start);
      for (let i = 0; i < piece.length && piece.length < 4; i++) {
        const r = Math.floor(piece[i] / 100), c = piece[i] % 100;
        for (const n of [key(r, c - 1), key(r, c + 1), key(r - 1, c), key(r + 1, c)]) {
          if (piece.length < 4 && cells.has(n) && !taken.has(n)) { piece.push(n); taken.add(n); }
        }
      }
      pieces.push(piece.map(k => [Math.floor(k / 100), k % 100]));
    }
    pieces.sort((a, b) => Math.max(...b.map(x => x[0])) - Math.max(...a.map(x => x[0])));
    return pieces;
  }

  function tetrisClock(style) {
    const pal = TETRIS_PALETTES[style] || TETRIS_PALETTES.clasico, turbo = style === 'turbo';
    const layout = turbo ? ['d', 'd', ':', 'd', 'd', ':', 'd', 'd'] : ['d', 'd', ':', 'd', 'd'];
    const slots = []; let col = 1;
    for (const t of layout) { slots.push({ t, col, char: null, pieces: [], dying: [] }); col += (t === 'd' ? 5 : 1) + 1; }
    const COLS = col, ROWS = TOP + DIGIT_ROWS + (turbo ? 1 : 3);
    let view, stats, score = 0, lines = 0;
    const timing = turbo ? { stagger: 45, dur: 330, delay: 160 } : { stagger: 110, dur: 560, delay: 220 };
    function setSlot(slot, char, now, instant) {
      if (slot.char === char) return;
      if (slot.char !== null) { slot.dying = slot.pieces.map(pc => ({ ...pc, die: now })); lines++; }
      slot.char = char;
      const pieces = chunkGlyph(char, slot.col), seed = char.charCodeAt(0) * 7 + slot.col;
      slot.pieces = pieces.map((cells, i) => ({
        cells, color: pal.colors[(seed + i * 3) % pal.colors.length],
        start: instant ? -1e9 : now + (slot.dying.length ? timing.delay : 0) + i * timing.stagger,
        dx: ((seed + i * 5) % 7) - 3
      }));
      score += pieces.length * 10;
    }
    function cell(g, x, y, s, color) {
      g.fillStyle = color; g.fillRect(x + .5, y + .5, s - 1, s - 1);
      if (style === 'gameboy') { g.fillStyle = pal.bg; g.fillRect(x + s * .3, y + s * .3, s * .4, s * .4); return; }
      g.fillStyle = 'rgba(255,255,255,.35)'; g.fillRect(x + .5, y + .5, s - 1, Math.max(1.5, s * .16)); g.fillRect(x + .5, y + .5, Math.max(1.5, s * .16), s - 1);
      g.fillStyle = 'rgba(0,0,0,.28)'; g.fillRect(x + .5, y + s - .5 - s * .16, s - 1, s * .16); g.fillRect(x + s - .5 - s * .16, y + .5, s * .16, s - 1);
    }
    return {
      mount(host) {
        const wrap = document.createElement('div'); wrap.className = `tetris-wrap tetris-${style}`;
        host.appendChild(wrap);
        view = makeCanvas(wrap, COLS / ROWS, 'Reloj Tetris: piezas que caen formando la hora');
        stats = document.createElement('div'); stats.className = 'tetris-stats';
        stats.innerHTML = '<span>NIVEL <b data-k="lvl">0</b></span><span>LÍNEAS <b data-k="lines">0</b></span><span>PUNTOS <b data-k="score">0</b></span>';
        wrap.appendChild(stats); view.wrap = wrap;
      },
      render(p, ctx) {
        const now = performance.now(), instant = ctx.reduced, g = view.g, W = view.w, H = view.h, s = W / COLS;
        const hh = hourText(p, ctx), mm = pad(p.minute), ss = pad(p.second);
        const chars = turbo ? [hh[0], hh[1], ':', mm[0], mm[1], ':', ss[0], ss[1]] : [hh[0], hh[1], ':', mm[0], mm[1]];
        slots.forEach((slot, i) => setSlot(slot, chars[i], now, instant || slot.char === null && now < 50));
        g.fillStyle = pal.bg; g.fillRect(0, 0, W, H);
        g.strokeStyle = pal.grid; g.lineWidth = 1; g.beginPath();
        for (let c = 0; c <= COLS; c++) { g.moveTo(c * s, 0); g.lineTo(c * s, H); }
        for (let r = 0; r <= ROWS; r++) { g.moveTo(0, r * s); g.lineTo(W, r * s); }
        g.stroke();
        for (const slot of slots) {
          slot.dying = slot.dying.filter(pc => now - pc.die < 200);
          for (const pc of slot.dying) {
            const flash = Math.floor((now - pc.die) / 50) % 2 === 0;
            for (const [r, c] of pc.cells) cell(g, c * s, r * s, s, flash ? '#ffffff' : pc.color);
          }
          for (const pc of slot.pieces) {
            const t = Math.max(0, Math.min(1, (now - pc.start) / timing.dur));
            if (t <= 0) continue;
            const minRow = Math.min(...pc.cells.map(x => x[0])), fall = minRow + 3;
            const yOff = Math.round(fall * (1 - t * t) * 2) / 2, xOff = Math.round(pc.dx * Math.max(0, 1 - t / .55));
            for (const [r, c] of pc.cells) { const y = (r - yOff) * s; if (y > -s) cell(g, (c + xOff) * s, y, s, pc.color); }
          }
        }
        if (!turbo) {
          const row = TOP + DIGIT_ROWS + 1, inner = COLS - 2, filled = Math.floor((p.second + p.millis / 1000) / 60 * inner);
          for (let c = 0; c < inner; c++) {
            if (c < filled) cell(g, (c + 1) * s, row * s, s, pal.colors[c % pal.colors.length]);
            else { g.strokeStyle = pal.frame; g.strokeRect((c + 1) * s + 1.5, row * s + 1.5, s - 3, s - 3); }
          }
        }
        g.strokeStyle = pal.frame; g.lineWidth = 3; g.strokeRect(1.5, 1.5, W - 3, H - 3);
        if (p.millis < 120) {
          stats.querySelector('[data-k="lvl"]').textContent = p.hour;
          stats.querySelector('[data-k="lines"]').textContent = lines;
          stats.querySelector('[data-k="score"]').textContent = String(score).padStart(6, '0');
        }
      },
      unmount() { view?.ro.disconnect(); view?.wrap.remove(); }
    };
  }

  /* ───────────────────────── PALABRAS (word clock en español) ───────────────────────── */
  const WORD_ROWS = ['ESONELASUNA', 'DOSITRESORE', 'CUATROCINCO', 'SEISASIETEN', 'OCHONUEVEYO', 'LADIEZSONCE', 'DOCELYMENOS', 'OVEINTEDIEZ', 'VEINTICINCO', 'MEDIACUARTO'];
  const W = (r, c, len) => Array.from({ length: len }, (_, i) => [r, c + i]);
  const WORDS = {
    ES: W(0, 0, 2), SON: W(0, 1, 3), LA: W(0, 5, 2), LAS: W(0, 5, 3), Y: W(6, 5, 1), MENOS: W(6, 6, 5),
    h1: W(0, 8, 3), h2: W(1, 0, 3), h3: W(1, 4, 4), h4: W(2, 0, 6), h5: W(2, 6, 5), h6: W(3, 0, 4), h7: W(3, 5, 5), h8: W(4, 0, 4), h9: W(4, 4, 5), h10: W(5, 2, 4), h11: W(5, 7, 4), h12: W(6, 0, 4),
    m5: W(8, 6, 5), m10: W(7, 7, 4), m15: W(9, 5, 6), m20: W(7, 1, 6), m25: W(8, 0, 11), m30: W(9, 0, 5)
  };
  function wordClock() {
    let el, cells = [], dots = [], last = '';
    return {
      mount(host) {
        el = document.createElement('div'); el.className = 'word-clock';
        const grid = document.createElement('div'); grid.className = 'word-grid'; grid.setAttribute('aria-live', 'off');
        WORD_ROWS.forEach((row, r) => { cells[r] = []; [...row].forEach(ch => { const s = document.createElement('span'); s.textContent = ch; grid.appendChild(s); cells[r].push(s); }); });
        el.appendChild(grid);
        for (let i = 0; i < 4; i++) { const d = document.createElement('i'); d.className = `word-dot dot-${i}`; el.appendChild(d); dots.push(d); }
        const cap = document.createElement('p'); cap.className = 'word-caption'; el.appendChild(cap); el.cap = cap;
        host.appendChild(el);
      },
      render(p) {
        const key = `${p.hour}:${p.minute}`;
        if (key === last) return; last = key;
        const m5 = Math.floor(p.minute / 5) * 5;
        let h = p.hour % 12, words = [];
        if (m5 > 30) h = (h + 1) % 12;
        const hh = h === 0 ? 12 : h;
        words.push(...(hh === 1 ? ['ES', 'LA'] : ['SON', 'LAS']), 'h' + hh);
        if (m5 > 0 && m5 <= 30) words.push('Y', 'm' + m5);
        if (m5 > 30) words.push('MENOS', 'm' + (60 - m5));
        cells.flat().forEach(c => c.classList.remove('on'));
        const phrase = [];
        for (const w of words) { const txt = WORDS[w].map(([r, c]) => { cells[r][c].classList.add('on'); return WORD_ROWS[r][c]; }).join(''); phrase.push(txt); }
        dots.forEach((d, i) => d.classList.toggle('on', i < p.minute % 5));
        const extra = p.minute % 5 ? ` (+${p.minute % 5} min)` : '';
        el.cap.textContent = phrase.join(' ').toLowerCase() + extra;
        el.setAttribute('aria-label', el.cap.textContent);
      },
      unmount() { el?.remove(); }
    };
  }

  /* ───────────────────────── RELOJ DE ARENA ───────────────────────── */
  function sandClock() {
    let view, grains = [], lastMinute = -1, flipStart = -1e9;
    return {
      mount(host) { view = makeCanvas(host, 0.82, 'Reloj de arena: la arena cae durante cada minuto'); },
      render(p, ctx) {
        const g = view.g, w = view.w, h = view.h, now = performance.now(), dark = document.body.dataset.theme !== 'light';
        if (lastMinute !== -1 && p.minute !== lastMinute && !ctx.reduced) flipStart = now;
        lastMinute = p.minute;
        const sec = p.second + p.millis / 1000, f = sec / 60;
        g.clearRect(0, 0, w, h);
        const cx = w / 2, top = h * .07, bottom = h * .74, mid = (top + bottom) / 2, bw = w * .32, neck = Math.max(3, w * .014);
        const flipT = Math.min(1, (now - flipStart) / 700);
        g.save(); g.translate(cx, mid);
        if (flipT < 1) g.rotate(Math.PI * (1 - (1 - Math.pow(1 - flipT, 3))));
        g.translate(-cx, -mid);
        const glass = new Path2D();
        glass.moveTo(cx - bw, top); glass.lineTo(cx + bw, top);
        glass.bezierCurveTo(cx + bw, mid - (mid - top) * .35, cx + neck * 2, mid - 12, cx + neck, mid);
        glass.bezierCurveTo(cx + neck * 2, mid + 12, cx + bw, mid + (bottom - mid) * .35, cx + bw, bottom);
        glass.lineTo(cx - bw, bottom);
        glass.bezierCurveTo(cx - bw, mid + (bottom - mid) * .35, cx - neck * 2, mid + 12, cx - neck, mid);
        glass.bezierCurveTo(cx - neck * 2, mid - 12, cx - bw, mid - (mid - top) * .35, cx - bw, top);
        g.fillStyle = dark ? 'rgba(200,230,240,.08)' : 'rgba(255,255,255,.4)'; g.fill(glass);
        const sand = g.createLinearGradient(0, top, 0, bottom); sand.addColorStop(0, '#f6d38b'); sand.addColorStop(1, '#d9a24f');
        g.save(); g.clip(glass); g.fillStyle = sand;
        const H = mid - top, topLevel = mid - H * .92 * Math.pow(Math.max(0, 1 - f), .75);
        if (f < 1) g.fillRect(cx - bw, topLevel, bw * 2, mid - topLevel);
        const pile = (bottom - mid) * .62 * Math.pow(f, .8);
        g.beginPath(); g.moveTo(cx - bw, bottom); g.lineTo(cx - bw, bottom - pile * .6);
        g.quadraticCurveTo(cx, bottom - pile * 1.35, cx + bw, bottom - pile * .6); g.lineTo(cx + bw, bottom); g.fill();
        if (flipT >= 1 && f < .995) {
          g.fillStyle = '#f0c47a'; g.fillRect(cx - 1, mid, 2, bottom - pile - mid);
          if (!ctx.reduced) {
            if (grains.length < 40) grains.push({ x: cx + (Math.random() - .5) * 4, y: mid, v: 1 + Math.random() });
            grains.forEach(gr => { gr.v += .35; gr.y += gr.v; gr.x += (Math.random() - .5) * .6; });
            grains = grains.filter(gr => gr.y < bottom - pile * 1.1);
            grains.forEach(gr => g.fillRect(gr.x, gr.y, 1.6, 1.6));
          }
        }
        g.restore();
        g.lineWidth = 3; g.strokeStyle = dark ? 'rgba(220,240,245,.55)' : 'rgba(30,60,75,.5)'; g.stroke(glass);
        g.fillStyle = dark ? '#6b4a2e' : '#8a5f3a';
        g.fillRect(cx - bw - 18, top - 14, bw * 2 + 36, 14); g.fillRect(cx - bw - 18, bottom, bw * 2 + 36, 14);
        g.restore();
        const css = getComputedStyle(document.body);
        g.textAlign = 'center'; g.fillStyle = css.getPropertyValue('--text');
        g.font = `600 ${Math.round(w * .13)}px Manrope, sans-serif`;
        g.fillText(`${hourText(p, ctx)}:${pad(p.minute)}`, cx, h * .9);
        g.font = `600 ${Math.round(w * .035)}px "DM Mono", monospace`; g.fillStyle = css.getPropertyValue('--muted');
        g.fillText(`${pad(p.second)} SEGUNDOS DE ARENA`, cx, h * .975);
      },
      unmount() { view?.ro.disconnect(); view?.c.remove(); }
    };
  }

  /* ───────────────────────── PAISAJE (sol y luna reales) ───────────────────────── */
  function landscapeClock() {
    let view, scene = null, shooting = null;
    function build(w, h) {
      let seed = 7; const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
      const stars = Array.from({ length: 90 }, () => ({ x: rnd() * w, y: rnd() * h * .62, r: rnd() * 1.3 + .3, p: rnd() * TAU }));
      const hills = [0, 1].map(k => Array.from({ length: 9 }, (_, i) => [i / 8 * w, h * (.66 + k * .07) - rnd() * h * .12]));
      const buildings = []; let x = 0;
      while (x < w) { const bw = 18 + rnd() * 30, bh = h * (.08 + rnd() * .16); buildings.push({ x, bw, bh, win: Array.from({ length: 40 }, () => rnd()) }); x += bw + 2; }
      const clouds = Array.from({ length: 4 }, () => ({ x: rnd() * w, y: h * (.12 + rnd() * .25), s: .6 + rnd() * .8, v: 4 + rnd() * 8 }));
      return { w, h, stars, hills, buildings, clouds };
    }
    const mix = (a, b, t) => a.map((v, i) => Math.round(v + (b[i] - v) * t));
    function skyColors(alt) {
      const night = [[8, 14, 34], [22, 30, 66]], dusk = [[46, 42, 96], [240, 128, 92]], day = [[64, 146, 214], [176, 222, 245]];
      if (alt <= -12) return night;
      if (alt < -2) { const t = (alt + 12) / 10; return [mix(night[0], dusk[0], t), mix(night[1], dusk[1], t)]; }
      if (alt < 10) { const t = (alt + 2) / 12; return [mix(dusk[0], day[0], t), mix(dusk[1], day[1], t)]; }
      return day;
    }
    const skyPos = (body, w, horizon) => ({ x: w * (.5 + body.ha / 200), y: horizon - Math.max(-20, body.alt) / 90 * (horizon - 24) });
    return {
      mount(host) { view = makeCanvas(host, 1.25, 'Paisaje: el sol y la luna se mueven según su posición real en el cielo'); },
      render(p, ctx) {
        const g = view.g, w = view.w, h = view.h, date = new Date(), t = performance.now() / 1000;
        if (!scene || scene.w !== w) scene = build(w, h);
        const sunP = Astro.sunAltAz(date, ctx.lat, ctx.lon), moonP = Astro.moonAltAz(date, ctx.lat, ctx.lon), ph = Astro.phase(date);
        const [c1, c2] = skyColors(sunP.alt), horizon = h * .72;
        const grad = g.createLinearGradient(0, 0, 0, horizon); grad.addColorStop(0, `rgb(${c1})`); grad.addColorStop(1, `rgb(${c2})`);
        g.fillStyle = grad; g.fillRect(0, 0, w, h);
        const darkness = Math.max(0, Math.min(1, (-sunP.alt - 2) / 10));
        if (darkness > 0) {
          for (const s of scene.stars) { g.globalAlpha = darkness * (.55 + .45 * Math.sin(t * 2 + s.p)); g.fillStyle = '#fff'; g.beginPath(); g.arc(s.x, s.y, s.r, 0, TAU); g.fill(); }
          g.globalAlpha = 1;
          if (!ctx.reduced && !shooting && Math.random() < .002) shooting = { x: Math.random() * w * .7, y: Math.random() * h * .25, t: t };
          if (shooting) { const k = (t - shooting.t) / .8; if (k > 1) shooting = null; else { g.strokeStyle = `rgba(255,255,255,${1 - k})`; g.lineWidth = 2; g.beginPath(); g.moveTo(shooting.x + k * 160, shooting.y + k * 60); g.lineTo(shooting.x + k * 160 - 40, shooting.y + k * 60 - 15); g.stroke(); } }
        }
        if (moonP.alt > -8) {
          const m = skyPos(moonP, w, horizon), r = Math.max(10, w * .035);
          g.fillStyle = 'rgba(40,48,70,.85)'; g.beginPath(); g.arc(m.x, m.y, r, 0, TAU); g.fill();
          g.save(); if (ctx.lat < 0) { g.translate(m.x * 2, 0); g.scale(-1, 1); }
          g.fillStyle = '#f4f1de'; g.shadowColor = 'rgba(255,250,220,.6)'; g.shadowBlur = 18;
          g.fill(new Path2D(Astro.litPath(ph.elongation, m.x, m.y, r))); g.restore();
        }
        if (sunP.alt > -8) {
          const s = skyPos(sunP, w, horizon), r = Math.max(14, w * .05);
          const glow = g.createRadialGradient(s.x, s.y, r * .3, s.x, s.y, r * 3); glow.addColorStop(0, 'rgba(255,220,130,.55)'); glow.addColorStop(1, 'rgba(255,220,130,0)');
          g.fillStyle = glow; g.fillRect(s.x - r * 3, s.y - r * 3, r * 6, r * 6);
          g.fillStyle = sunP.alt < 6 ? '#ff9f5a' : '#ffd66b'; g.beginPath(); g.arc(s.x, s.y, r, 0, TAU); g.fill();
        }
        for (const c of scene.clouds) {
          const x = ((c.x + (ctx.reduced ? 0 : t * c.v)) % (w + 160)) - 80;
          g.fillStyle = `rgba(${darkness > .5 ? '150,160,190' : '255,255,255'},${.07 + (1 - darkness) * .55})`;
          for (const [dx, dy, rr] of [[0, 0, 18], [18, -8, 22], [40, 0, 17], [20, 6, 18]]) { g.beginPath(); g.arc(x + dx * c.s, c.y + dy * c.s, rr * c.s, 0, TAU); g.fill(); }
        }
        scene.hills.forEach((pts, k) => {
          g.fillStyle = k === 0 ? `rgba(${mix([70, 110, 120], [18, 28, 48], darkness)},1)` : `rgba(${mix([46, 92, 82], [12, 20, 36], darkness)},1)`;
          g.beginPath(); g.moveTo(0, h); pts.forEach(([x, y], i) => i ? g.quadraticCurveTo((pts[i - 1][0] + x) / 2, y - 10, x, y) : g.lineTo(x, y)); g.lineTo(w, h); g.fill();
        });
        const city = darkness > .3, base = h;
        for (const b of scene.buildings) {
          g.fillStyle = `rgb(${mix([60, 74, 92], [10, 14, 26], darkness)})`; g.fillRect(b.x, base - b.bh, b.bw, b.bh);
          if (city) {
            let k = 0;
            for (let y = base - b.bh + 6; y < base - 6; y += 9) for (let x = b.x + 4; x < b.x + b.bw - 5; x += 7) {
              const lit = b.win[k++ % 40] < .35 + .25 * Math.sin(p.minute * .7 + k); if (!lit) continue;
              g.fillStyle = 'rgba(255,214,120,.85)'; g.fillRect(x, y, 3, 4);
            }
          }
        }
        g.textAlign = 'center'; g.fillStyle = '#fff'; g.shadowColor = 'rgba(0,0,0,.35)'; g.shadowBlur = 14;
        g.font = `700 ${Math.round(w * .15)}px Manrope, sans-serif`;
        g.fillText(`${hourText(p, ctx)}:${pad(p.minute)}`, w / 2, h * .36);
        g.font = `600 ${Math.round(w * .032)}px "DM Mono", monospace`; g.shadowBlur = 6;
        const label = sunP.alt > 0 ? `☀ SOL A ${Math.round(sunP.alt)}° SOBRE EL HORIZONTE` : moonP.alt > 0 ? `☾ LUNA A ${Math.round(moonP.alt)}° · ${Math.round(ph.illumination * 100)}% ILUMINADA` : '✦ NOCHE CERRADA';
        g.fillText(`${pad(p.second)}s · ${label}`, w / 2, h * .45);
        g.shadowBlur = 0;
      },
      unmount() { view?.ro.disconnect(); view?.c.remove(); }
    };
  }

  const FACTORIES = {
    tetris: style => tetrisClock(style),
    creative: style => style === 'palabras' ? wordClock() : style === 'arena' ? sandClock() : landscapeClock()
  };
  let current = null, currentKey = '';
  return {
    STYLES: {
      tetris: [['clasico', 'Clásico'], ['turbo', 'Turbo + segundos'], ['gameboy', 'Retro verde']],
      creative: [['palabras', 'Palabras'], ['arena', 'Reloj de arena'], ['paisaje', 'Paisaje real']]
    },
    // Otros archivos registran sus relojes aquí (mecánicos, animales, 3D).
    register(type, styles, factory) { this.STYLES[type] = styles; FACTORIES[type] = factory; },
    util: { makeCanvas, pad, hourText, angles, TAU },
    show(type, style, host) {
      const key = type + ':' + style;
      if (key === currentKey) return;
      this.hide(host);
      if (!FACTORIES[type]) return;
      current = FACTORIES[type](style); currentKey = key; current.mount(host);
    },
    hide(host) { current?.unmount(); current = null; currentKey = ''; host?.replaceChildren(); },
    render(p, ctx) { if (current) current.render(p, { ...ctx, reduced: ctx.reduced ?? reduced() }); }
  };
})();
