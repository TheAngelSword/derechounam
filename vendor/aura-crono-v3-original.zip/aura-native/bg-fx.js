/* Aura Crono · Fondos animados en canvas: Visualizador musical, Hiperespacio, Lluvia de código y Luces bokeh.
   Se dibujan a media resolución y ~30 fps para cuidar la batería; reaccionan a la radio mediante AudioFX. */
'use strict';
const BgFX = (() => {
  const TAU = Math.PI * 2;
  let canvas, g, mode = null, raf = 0, last = 0, W = 0, H = 0, motion = true, state = {};
  const SCALE = .5;
  function fit() {
    W = Math.round(innerWidth * SCALE); H = Math.round(innerHeight * SCALE);
    canvas.width = W; canvas.height = H; state = {};
  }
  const levels = () => (typeof AudioFX !== 'undefined' ? AudioFX.levels() : { bass: .2, mid: .2, treble: .2, energy: .2, beat: false, spectrum: new Float32Array(64), playing: false });

  function music(t, au) {
    const hue = (t * 12) % 360;
    g.fillStyle = `hsla(${hue + 220},60%,6%,.35)`; g.fillRect(0, 0, W, H);
    const cx = W / 2, cy = H * .48, base = Math.min(W, H) * (.16 + au.bass * .06);
    g.globalCompositeOperation = 'lighter';
    // Anillo radial del espectro (espejado).
    for (let i = 0; i < 64; i++) {
      const v = au.spectrum[i], len = base * (.15 + v * 1.4);
      for (const side of [1, -1]) {
        const a = -Math.PI / 2 + side * (i / 64) * Math.PI;
        g.strokeStyle = `hsla(${hue + i * 4},90%,${45 + v * 30}%,.85)`; g.lineWidth = Math.max(1.5, base * .05);
        g.beginPath(); g.moveTo(cx + Math.cos(a) * base, cy + Math.sin(a) * base); g.lineTo(cx + Math.cos(a) * (base + len), cy + Math.sin(a) * (base + len)); g.stroke();
      }
    }
    const pulse = g.createRadialGradient(cx, cy, 0, cx, cy, base * (1 + au.bass));
    pulse.addColorStop(0, `hsla(${hue + 300},90%,60%,${.25 + au.bass * .4})`); pulse.addColorStop(1, 'hsla(0,0%,0%,0)');
    g.fillStyle = pulse; g.beginPath(); g.arc(cx, cy, base * (1 + au.bass), 0, TAU); g.fill();
    // Ondas expansivas en cada golpe.
    state.waves ||= [];
    if (au.beat) state.waves.push({ r: base, a: .8, h: hue });
    state.waves = state.waves.filter(w => (w.a -= .02) > 0);
    for (const w of state.waves) { w.r += 3; g.strokeStyle = `hsla(${w.h + 180},90%,65%,${w.a})`; g.lineWidth = 2; g.beginPath(); g.arc(cx, cy, w.r, 0, TAU); g.stroke() }
    // Barras inferiores.
    const bw = W / 64;
    for (let i = 0; i < 64; i++) { const v = au.spectrum[i], h = v * H * .3; g.fillStyle = `hsla(${hue + i * 5},85%,55%,.55)`; g.fillRect(i * bw, H - h, bw - 1, h) }
    // Partículas que suben.
    state.parts ||= Array.from({ length: 60 }, () => ({ x: Math.random() * W, y: Math.random() * H, v: .2 + Math.random() }));
    for (const p of state.parts) { p.y -= p.v * (1 + au.energy * 4); if (p.y < 0) { p.y = H; p.x = Math.random() * W } g.fillStyle = `hsla(${hue + p.x},90%,70%,.6)`; g.fillRect(p.x, p.y, 1.5, 1.5) }
    g.globalCompositeOperation = 'source-over';
  }
  function hyper(t, au) {
    g.fillStyle = 'rgba(2,3,12,.35)'; g.fillRect(0, 0, W, H);
    state.stars ||= Array.from({ length: 260 }, () => ({ x: (Math.random() - .5) * 2, y: (Math.random() - .5) * 2, z: Math.random() }));
    const cx = W / 2, cy = H / 2, speed = .004 + au.energy * .02 + (au.beat ? .02 : 0);
    g.lineCap = 'round';
    for (const s of state.stars) {
      const pz = s.z; s.z -= speed; if (s.z <= .02) { s.x = (Math.random() - .5) * 2; s.y = (Math.random() - .5) * 2; s.z = 1; continue }
      const k = 1 / s.z, k0 = 1 / pz, x = cx + s.x * k * W * .25, y = cy + s.y * k * H * .25, x0 = cx + s.x * k0 * W * .25, y0 = cy + s.y * k0 * H * .25;
      const b = Math.min(1, (1 - s.z) * 1.4);
      g.strokeStyle = `rgba(${180 + b * 75},${200 + b * 55},255,${b})`; g.lineWidth = Math.max(.5, (1 - s.z) * 2.2);
      g.beginPath(); g.moveTo(x0, y0); g.lineTo(x, y); g.stroke();
    }
  }
  const GL = 'ｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾅﾆﾇﾈﾉ0123456789';
  function code(t, au) {
    g.fillStyle = 'rgba(0,6,2,.18)'; g.fillRect(0, 0, W, H);
    const cell = 9; state.cols ||= Array.from({ length: Math.ceil(W / cell) }, () => Math.random() * -H / cell);
    g.font = `${cell}px monospace`; g.textAlign = 'center';
    state.cols.forEach((y, i) => {
      g.fillStyle = Math.random() < .05 ? '#d8ffe0' : `rgba(40,255,120,${.6 + au.energy * .4})`;
      g.fillText(GL[Math.floor(Math.random() * GL.length)], i * cell + cell / 2, y * cell);
      state.cols[i] = y * cell > H && Math.random() > .975 ? 0 : y + .5 + au.bass * .8;
    });
  }
  function bokeh(t, au) {
    const gr = g.createLinearGradient(0, 0, W, H); gr.addColorStop(0, '#0b0f24'); gr.addColorStop(1, '#2a0f2e');
    g.fillStyle = gr; g.fillRect(0, 0, W, H);
    state.orbs ||= Array.from({ length: 34 }, (_, i) => ({ x: Math.random() * W, y: Math.random() * H, r: 8 + Math.random() * 40, h: [330, 200, 45, 270, 160][i % 5], vx: (Math.random() - .5) * .3, vy: (Math.random() - .5) * .3, ph: Math.random() * TAU }));
    g.globalCompositeOperation = 'lighter';
    for (const o of state.orbs) {
      o.x = (o.x + o.vx + W) % W; o.y = (o.y + o.vy + H) % H;
      const r = o.r * (1 + au.bass * .5 * Math.sin(o.ph + t)), a = .12 + .1 * Math.sin(t + o.ph) + au.energy * .15;
      const rg = g.createRadialGradient(o.x, o.y, 0, o.x, o.y, r); rg.addColorStop(0, `hsla(${o.h},90%,65%,${a})`); rg.addColorStop(.7, `hsla(${o.h},90%,55%,${a * .5})`); rg.addColorStop(1, `hsla(${o.h},90%,50%,0)`);
      g.fillStyle = rg; g.beginPath(); g.arc(o.x, o.y, r, 0, TAU); g.fill();
    }
    g.globalCompositeOperation = 'source-over';
  }
  const MODES = { musica: music, hiperespacio: hyper, codigo: code, bokeh };
  function loop(now) {
    raf = 0; if (!mode) return;
    if (now - last >= 32) {
      last = now;
      const au = levels();
      MODES[mode](now / 1000, au);
    }
    if (motion && document.visibilityState === 'visible') raf = requestAnimationFrame(loop);
  }
  return {
    MODES: Object.keys(MODES),
    init(cv) { canvas = cv; g = cv.getContext('2d'); fit(); addEventListener('resize', () => { if (mode) { fit(); this.start() } }); document.addEventListener('visibilitychange', () => this.start()) },
    set(m) { mode = MODES[m] ? m : null; canvas.hidden = !mode; state = {}; if (mode) { g.clearRect(0, 0, W, H); this.start() } else cancelAnimationFrame(raf), raf = 0 },
    start() {
      if (!mode) return;
      if (!motion) {
        // Modo normal: un solo cuadro estático, bien asentado.
        cancelAnimationFrame(raf); raf = 0; state = {};
        for (let i = 0; i < 40; i++) MODES[mode](i * .05, levels());
        return;
      }
      if (!raf) raf = requestAnimationFrame(loop);
    },
    setMotion(on) { motion = on; this.start() }
  };
})();
