/* Aura Crono v2 | Reloj, clima, efemérides, astronomía y radio en una web estática (sin llaves API) */
'use strict';

const $ = (id) => document.getElementById(id);
const SETTINGS_KEY = 'aura-crono-preferences-v1';
const BG_IMAGE_KEY = 'aura-crono-bg-image';
const CLOCK_STYLES = {
  analog: [['atelier', 'Atelier'], ['pilot', 'Aviador'], ['zen', 'Zen'], ['stellar', 'Estelar']],
  digital: [['glass', 'Cristal'], ['led', 'LED'], ['flip', 'Flip'], ['editorial', 'Editorial']],
  orbital: [['orbit', 'Órbita temporal']],
  ...FunClocks.STYLES
};
const FUN_TYPES = new Set(['mechanical', 'animals', '3d', 'tetris', 'creative']);
// Relojes que necesitan animación fluida; el resto se actualiza una vez por segundo para ahorrar batería.
const SMOOTH = { analog: true, orbital: true, mechanical: true, animals: true, '3d': true, tetris: true, creative: s => s !== 'palabras' };

/* ── Radio: emisoras agrupadas por género, con URL de respaldo cuando existe ── */
const soma = (id, name) => ({ name: `SomaFM · ${name}`, urls: [`https://ice5.somafm.com/${id}-128-mp3`, `https://ice2.somafm.com/${id}-128-mp3`, `https://ice4.somafm.com/${id}-128-mp3`] });
const fip = (id, name) => ({ name: `FIP · ${name}`, urls: [`https://icecast.radiofrance.fr/${id}-midfi.mp3`, `https://icecast.radiofrance.fr/${id}-hifi.aac`] });
const STATION_GROUPS = [
  ['Ecléctica', {
    paradise: { name: 'Radio Paradise · Principal', urls: ['https://stream.radioparadise.com/mp3-128', 'https://stream-dc1.radioparadise.com/mp3-128'] },
    paradisemellow: { name: 'Radio Paradise · Mellow', urls: ['https://stream.radioparadise.com/mellow-128'] },
    paradiserock: { name: 'Radio Paradise · Rock', urls: ['https://stream.radioparadise.com/rock-128'] },
    paradiseglobal: { name: 'Radio Paradise · Global', urls: ['https://stream.radioparadise.com/global-128'] },
    fip: fip('fip', 'Eclectique (París)'),
    kexp: { name: 'KEXP 90.3 · Seattle', urls: ['https://kexp-mp3-128.streamguys1.com/kexp128.mp3'] }
  }],
  ['Chill y electrónica', {
    groovesalad: soma('groovesalad', 'Groove Salad'), lush: soma('lush', 'Lush'), fluid: soma('fluid', 'Fluid (beats)'),
    beatblender: soma('beatblender', 'Beat Blender'), vaporwaves: soma('vaporwaves', 'Vaporwaves'), cliqhop: soma('cliqhop', 'cliqhop idm'),
    fipelectro: fip('fipelectro', 'Electro'), fipgroove: fip('fipgroove', 'Groove')
  }],
  ['Ambiente y espacio', {
    spacestation: soma('spacestation', 'Space Station'), deepspaceone: soma('deepspaceone', 'Deep Space One'),
    dronezone: soma('dronezone', 'Drone Zone'), missioncontrol: soma('missioncontrol', 'Mission Control'), synphaera: soma('synphaera', 'Synphaera')
  }],
  ['Jazz, bossa y lounge', {
    bossa: soma('bossa', 'Bossa Beyond'), secretagent: soma('secretagent', 'Secret Agent'), sonicuniverse: soma('sonicuniverse', 'Sonic Universe'),
    illstreet: soma('illstreet', 'Illinois Street Lounge'), fipjazz: fip('fipjazz', 'Jazz'),
    swissjazz: { name: 'Radio Swiss Jazz', urls: ['https://stream.srg-ssr.ch/m/rsj/mp3_128'] }
  }],
  ['Clásica', {
    swissclassic: { name: 'Radio Swiss Classic', urls: ['https://stream.srg-ssr.ch/m/rsc_de/mp3_128'] }
  }],
  ['Rock, pop y retro', {
    u80s: soma('u80s', 'Underground 80s'), seventies: soma('seventies', 'Left Coast 70s'), indiepop: soma('indiepop', 'Indie Pop Rocks'),
    poptron: soma('poptron', 'PopTron'), bootliquor: soma('bootliquor', 'Boot Liquor (americana)'), metal: soma('metal', 'Metal Detector'),
    fiprock: fip('fiprock', 'Rock'), fippop: fip('fippop', 'Pop'), fipnouveautes: fip('fipnouveautes', 'Novedades'),
    swisspop: { name: 'Radio Swiss Pop', urls: ['https://stream.srg-ssr.ch/m/rsp/mp3_128'] }
  }],
  ['Músicas del mundo', {
    fipworld: fip('fipworld', 'Monde'), fipreggae: fip('fipreggae', 'Reggae'), suburbsofgoa: soma('suburbsofgoa', 'Suburbs of Goa'),
    folkfwd: soma('folkfwd', 'Folk Forward'), thistle: soma('thistle', 'ThistleRadio (celta)')
  }],
  ['Concentración', {
    defcon: soma('defcon', 'DEF CON Radio'), sf1033: soma('sf1033', 'SF 10-33'), n5md: soma('n5md', 'n5MD Radio')
  }]
];
const STATIONS = Object.assign({}, ...STATION_GROUPS.map(([, s]) => s));

/* ── Fondos temáticos ── */
const BG_THEMES = [
  ['weather', 'Clima en vivo', 'linear-gradient(145deg,#183749,#3d5160)'],
  ['aurora', 'Aurora boreal', 'linear-gradient(160deg,#04121f,#0b3b3a 45%,#3a1d5c)'],
  ['galaxia', 'Galaxia', 'radial-gradient(circle at 30% 30%,#3b2a6b,#0b0b1e 70%)'],
  ['oceano', 'Océano', 'linear-gradient(180deg,#0a4d68,#06283d 60%,#021526)'],
  ['atardecer', 'Atardecer', 'linear-gradient(180deg,#2d1b4e,#b3426b 50%,#f6a35c)'],
  ['bosque', 'Bosque', 'linear-gradient(180deg,#14281d,#1f3d2b 50%,#355e3b)'],
  ['sakura', 'Sakura', 'linear-gradient(160deg,#3a2433,#7d4a63 55%,#e7a9be)'],
  ['synthwave', 'Synthwave', 'linear-gradient(180deg,#120024,#3b0a5e 55%,#ff2e88)'],
  ['desierto', 'Desierto', 'linear-gradient(180deg,#3b2a4a,#c0694e 55%,#efb36f)'],
  ['medianoche', 'Minimal', 'linear-gradient(180deg,#0e1116,#151a22)'],
  ['musica', '♫ Visualizador musical', 'conic-gradient(from 90deg,#ff2e88,#7c4dff,#00e5ff,#00ff95,#ffe600,#ff2e88)'],
  ['hiperespacio', 'Hiperespacio', 'radial-gradient(circle,#c8d8ff 0 4%,#1a2350 12%,#02030c 70%)'],
  ['codigo', 'Lluvia de código', 'repeating-linear-gradient(90deg,#021006 0 6px,#0a5a24 6px 7px)'],
  ['bokeh', 'Luces bokeh', 'radial-gradient(circle at 30% 40%,#ff6fae 0 12%,transparent 13%),radial-gradient(circle at 70% 60%,#6fd3ff 0 16%,transparent 17%),linear-gradient(135deg,#0b0f24,#2a0f2e)']
];

const DEFAULT_LOCATION = { latitude: 19.4326, longitude: -99.1332, name: 'Ciudad de México', admin1: 'Ciudad de México', country: 'México', countryCode: 'MX', timezone: 'America/Mexico_City', source: 'default' };
const OBSERVANCES = {
  '01-01': ['Año Nuevo', 'El primer día del año: una oportunidad para nuevos comienzos.', '🎆'],
  '02-14': ['Día del Amor y la Amistad', 'Una fecha para celebrar los vínculos afectivos y la amistad.', '♥'],
  '03-08': ['Día Internacional de la Mujer', 'Una jornada de reflexión y reivindicación de los derechos de las mujeres.', '✿'],
  '03-21': ['Natalicio de Benito Juárez', 'México recuerda el nacimiento del expresidente Benito Juárez en 1806.', '✦'],
  '03-22': ['Día Mundial del Agua', 'Una jornada de concientización sobre el cuidado del agua.', '≈'],
  '04-22': ['Día Internacional de la Madre Tierra', 'Una invitación a proteger los ecosistemas y el planeta.', '◉'],
  '04-23': ['Día Mundial del Libro', 'Una celebración de la lectura, la literatura y el derecho de autor.', '✎'],
  '05-01': ['Día del Trabajo', 'Conmemoración del movimiento obrero y de los derechos laborales.', '✳'],
  '05-05': ['Batalla de Puebla', 'México recuerda la victoria de 1862 frente al ejército francés en Puebla.', '✦'],
  '05-10': ['Día de las Madres en México', 'Una fecha mexicana para agradecer y celebrar a las madres.', '♡'],
  '06-05': ['Día Mundial del Medio Ambiente', 'Un llamado internacional a cuidar nuestro entorno natural.', '❋'],
  '08-12': ['Día Internacional de la Juventud', 'Una jornada para reconocer la participación y los desafíos de las juventudes.', '✳'],
  '09-15': ['Noche del Grito de Independencia', 'En México se recuerda el inicio de la lucha por la Independencia con la ceremonia del Grito.', '✦'],
  '09-16': ['Independencia de México', 'Conmemoración del inicio del movimiento de Independencia en 1810.', '✦'],
  '10-02': ['Memoria del 2 de octubre de 1968', 'Una fecha de recuerdo de las víctimas de la represión estudiantil en Tlatelolco.', '✧'],
  '10-07': ['Día Mundial del Algodón', 'Una jornada internacional que reconoce la importancia social y económica de este cultivo.', '✳'],
  '10-12': ['Día de la Nación Pluricultural', 'En México se reconoce la diversidad cultural de los pueblos y comunidades.', '✳'],
  '10-31': ['Noche de Halloween', 'Una tradición de disfraces y relatos que se celebra en muchos países.', '☽'],
  '11-01': ['Día de Todos los Santos', 'Una conmemoración presente en distintas tradiciones cristianas.', '✦'],
  '11-02': ['Día de Muertos', 'Una tradición mexicana para honrar la memoria de quienes ya no están.', '✿'],
  '11-20': ['Día de la Revolución Mexicana', 'México recuerda el inicio de la Revolución de 1910.', '✦'],
  '12-12': ['Día de la Virgen de Guadalupe', 'Fecha de celebración religiosa y cultural para muchas comunidades de México.', '✦'],
  '12-24': ['Nochebuena', 'La víspera de Navidad se celebra con reuniones y tradiciones familiares.', '✳'],
  '12-25': ['Navidad', 'Una celebración cultural y religiosa en distintas partes del mundo.', '✦'],
  '12-31': ['Último día del año', 'Un momento para recordar lo vivido y prepararse para el año nuevo.', '✳']
};
const WEATHER = [
  { codes: [0], icon: '☀', text: 'Despejado', kind: 'clear' },
  { codes: [1], icon: '🌤', text: 'Mayormente despejado', kind: 'clear' },
  { codes: [2], icon: '⛅', text: 'Parcialmente nublado', kind: 'cloudy' },
  { codes: [3], icon: '☁', text: 'Nublado', kind: 'cloudy' },
  { codes: [45, 48], icon: '≋', text: 'Niebla', kind: 'fog' },
  { codes: [51, 53, 55, 56, 57], icon: '☂', text: 'Llovizna', kind: 'rain' },
  { codes: [61, 63, 65, 66, 67, 80, 81, 82], icon: '☂', text: 'Lluvia', kind: 'rain' },
  { codes: [71, 73, 75, 77, 85, 86], icon: '❄', text: 'Nieve', kind: 'snow' },
  { codes: [95, 96, 99], icon: 'ϟ', text: 'Tormenta', kind: 'storm' }
];
const MEXICO_SPECIFIC = new Set(['03-21', '05-05', '05-10', '09-15', '09-16', '10-02', '10-12', '11-20', '12-12']);
const YEAR_PHRASES = [
  'Un segundo a la vez. Todo lo demás es historia.',
  'El presente es el único momento que siempre tenemos.',
  'Hay días que pasan y días que permanecen.',
  'Cada instante tiene su propia geografía.',
  'Hasta el tiempo necesita un poco de música.'
];

const initialPrefs = (() => { try { return JSON.parse(localStorage.getItem(SETTINGS_KEY) || '{}') } catch { return {} } })();
if (initialPrefs.clock === 'characters') initialPrefs.clock = 'animals';
const customStations = Array.isArray(initialPrefs.customStations) ? initialPrefs.customStations.filter(s => s && s.id && /^https?:\/\//.test(s.url)) : [];
customStations.forEach(s => STATIONS[s.id] = { name: s.name, urls: [s.url], custom: true });
const defaultBg = { mode: 'weather', theme: 'weather', url: '', colors: ['#1d2b64', '#f8cdda'], dim: 25, blur: 0 };
const state = {
  clock: CLOCK_STYLES[initialPrefs.clock] ? initialPrefs.clock : 'analog',
  styles: { analog: 'atelier', digital: 'glass', orbital: 'orbit', mechanical: 'esqueleto', animals: 'gato', '3d': 'solar', tetris: 'clasico', creative: 'palabras', ...(initialPrefs.styles || {}) },
  motion: initialPrefs.motion === 'normal' ? 'normal' : 'full',
  solarMode: ['classic', 'orbits', 'vortex', 'geo'].includes(initialPrefs.solarMode) ? initialPrefs.solarMode : 'classic',
  theme: ['auto', 'light', 'dark'].includes(initialPrefs.theme) ? initialPrefs.theme : 'auto',
  format: initialPrefs.format === 12 ? 12 : 24,
  station: STATIONS[initialPrefs.station] ? initialPrefs.station : 'paradise',
  volume: Number.isFinite(initialPrefs.volume) ? Math.max(0, Math.min(1, initialPrefs.volume)) : .65,
  bg: { ...defaultBg, ...(initialPrefs.bg || {}) },
  location: { ...DEFAULT_LOCATION },
  currentWeather: null, dailyWeather: null, holidays: [], history: [],
  lastDate: '', lastSecond: -1, lastMinute: -1,
  geoSequence: 0, weatherSequence: 0, tickerPaused: false, playing: false, urlIndex: 0
};
// Un estilo guardado que ya no exista vuelve al primero de su tipo.
for (const [type, list] of Object.entries(CLOCK_STYLES)) if (!list.some(([k]) => k === state.styles[type])) state.styles[type] = list[0][0];

let saveTimer = 0;
function savePrefs() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    try { localStorage.setItem(SETTINGS_KEY, JSON.stringify({ clock: state.clock, styles: state.styles, theme: state.theme, format: state.format, station: state.station, volume: state.volume, bg: state.bg, motion: state.motion, solarMode: state.solarMode, customStations, manualLocation: state.location.source === 'manual' ? state.location : null })) } catch { }
  }, 250);
}
const pad = n => String(n).padStart(2, '0');
function weatherFor(code) { return WEATHER.find(w => w.codes.includes(Number(code))) || { icon: '◌', text: 'Cielo variable', kind: 'cloudy' } }

/* ── Tiempo zonal: el desfase se calcula con Intl una vez cada 30 s y el resto es aritmética ── */
const fmtCache = new Map();
function cachedFormat(key, factory) { let f = fmtCache.get(key); if (!f) { f = factory(); fmtCache.set(key, f) } return f }
function zoneFormatter(tz) {
  try { return cachedFormat('z|' + tz, () => new Intl.DateTimeFormat('en-GB', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23' })) }
  catch { return cachedFormat('z|local', () => new Intl.DateTimeFormat('en-GB', { year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23' })) }
}
const zone = { tz: null, offset: 0, checked: 0 };
function zonedParts(date, tz = state.location.timezone) {
  const t = date.getTime();
  if (zone.tz !== tz || t - zone.checked > 30000 || t < zone.checked) {
    const o = Object.fromEntries(zoneFormatter(tz).formatToParts(date).map(x => [x.type, x.value]));
    zone.offset = Date.UTC(+o.year, +o.month - 1, +o.day, +o.hour % 24, +o.minute, +o.second) - Math.floor(t / 1000) * 1000;
    zone.tz = tz; zone.checked = t;
  }
  const d = new Date(t + zone.offset);
  return { year: d.getUTCFullYear(), month: d.getUTCMonth() + 1, day: d.getUTCDate(), hour: d.getUTCHours(), minute: d.getUTCMinutes(), second: d.getUTCSeconds(), millis: d.getUTCMilliseconds() };
}
const formatZoned = zonedParts;
function datePartsAsDate(parts) { return new Date(Date.UTC(parts.year, parts.month - 1, parts.day, 12)) }
function localDateKey(parts) { return `${parts.year}-${pad(parts.month)}-${pad(parts.day)}` }
function timezoneOffset(date) {
  try { return cachedFormat('o|' + state.location.timezone, () => new Intl.DateTimeFormat('en-US', { timeZone: state.location.timezone, timeZoneName: 'longOffset' })).formatToParts(date).find(p => p.type === 'timeZoneName')?.value.replace('GMT', 'UTC') || 'UTC' } catch { return 'UTC' }
}
function fmtDate(date, opts) {
  const key = 'd|' + state.location.timezone + JSON.stringify(opts);
  try { return cachedFormat(key, () => new Intl.DateTimeFormat('es-MX', { timeZone: state.location.timezone, ...opts })).format(date) } catch { return date.toLocaleString('es-MX', opts) }
}
function currentHourInFormat(p) { return state.format === 24 ? p.hour : (p.hour % 12 || 12) }

function applyTheme(p) {
  let mode = state.theme;
  if (mode === 'auto' && state.bg.mode !== 'weather') mode = 'dark';
  else if (mode === 'auto') {
    const n = pad(p.hour) + ':' + pad(p.minute), day = localDateKey(p);
    const idx = state.dailyWeather?.time?.indexOf(day);
    const rise = idx >= 0 ? state.dailyWeather?.sunrise?.[idx]?.slice(11, 16) : null;
    const set = idx >= 0 ? state.dailyWeather?.sunset?.[idx]?.slice(11, 16) : null;
    mode = (rise && set) ? ((n >= rise && n < set) ? 'light' : 'dark') : (p.hour >= 7 && p.hour < 19 ? 'light' : 'dark');
  }
  if (document.body.dataset.theme !== mode) { document.body.dataset.theme = mode; document.querySelector('meta[name="theme-color"]')?.setAttribute('content', mode === 'light' ? '#d5e8ed' : '#101c2a') }
}

/* ── Animaciones: completas o normales (estáticas) ── */
const prefersReduced = window.matchMedia?.('(prefers-reduced-motion: reduce)');
function motionReduced() { return state.motion === 'normal' || !!prefersReduced?.matches }
function applyMotion() {
  const full = !motionReduced();
  document.body.dataset.motion = full ? 'full' : 'normal';
  $('motionButton').textContent = state.motion === 'full' ? '✦ Animaciones' : '◻ Modo normal';
  $('motionButton').setAttribute('aria-pressed', String(state.motion === 'full'));
  $('motionButton').title = state.motion === 'full' ? 'Animaciones completas activadas (pulsa para modo normal)' : 'Modo normal sin animaciones (pulsa para activarlas)';
  BgFX.setMotion(full); SolarAnim.setMotion(full);
  syncSolarControls();
}

/* ── Bucle de render ── */
const el = {};
function cacheElements() {
  ['hourHand', 'minuteHand', 'secondHand', 'digitalHours', 'digitalMinutes', 'digitalSeconds', 'digitalAmPm', 'digitalTz', 'orbitTime', 'analogClock', 'orbitalClock', 'digitalClock', 'funClock',
    'orbitHours', 'orbitMinutes', 'orbitSeconds', 'orbitHourDot', 'orbitMinuteDot', 'orbitSecondDot', 'clockMoon'].forEach(id => el[id] = $(id));
  for (const id of ['orbitHours', 'orbitMinutes', 'orbitSeconds']) el[id].circ = 2 * Math.PI * Number(el[id].getAttribute('r'));
}
function isSmooth() { const s = SMOOTH[state.clock]; return typeof s === 'function' ? s(state.styles[state.clock]) : !!s }
let frameHandle = 0, frameIsTimeout = false;
function scheduleFrame() {
  if (frameIsTimeout) clearTimeout(frameHandle); else cancelAnimationFrame(frameHandle);
  if (document.visibilityState === 'hidden') { frameIsTimeout = true; frameHandle = setTimeout(frame, 1000); return }
  if (isSmooth()) { frameIsTimeout = false; frameHandle = requestAnimationFrame(frame) }
  else { frameIsTimeout = true; frameHandle = setTimeout(frame, 1005 - new Date().getMilliseconds()) }
}
function frame() { tick(); scheduleFrame() }

function tick() {
  const date = new Date(), p = zonedParts(date), part = p.millis / 1000;
  const secondChanged = p.second !== state.lastSecond;
  const hidden = document.visibilityState === 'hidden';
  const hh = pad(currentHourInFormat(p)), mm = pad(p.minute), ss = pad(p.second);
  const ampm = state.format === 12 ? (p.hour >= 12 ? 'PM' : 'AM') : '';
  if (!hidden) {
    if (state.clock === 'analog') {
      el.hourHand.style.transform = `rotate(${((p.hour % 12) + p.minute / 60 + (p.second + part) / 3600) * 30}deg)`;
      el.minuteHand.style.transform = `rotate(${(p.minute + (p.second + part) / 60) * 6}deg)`;
      el.secondHand.style.transform = `rotate(${(p.second + part) * 6}deg)`;
    } else if (state.clock === 'orbital') {
      const hf = state.format === 12 ? (((p.hour % 12) + p.minute / 60) / 12) : ((p.hour + p.minute / 60) / 24);
      const mf = (p.minute + (p.second + part) / 60) / 60, sf = (p.second + part) / 60;
      setRing('orbitHours', hf); setRing('orbitMinutes', mf); setRing('orbitSeconds', sf);
      positionOrbitDot('orbitHourDot', 178, hf); positionOrbitDot('orbitMinuteDot', 144, mf); positionOrbitDot('orbitSecondDot', 110, sf);
    } else if (FUN_TYPES.has(state.clock)) {
      FunClocks.render(p, { format: state.format, lat: state.location.latitude, lon: state.location.longitude, reduced: motionReduced(), audio: AudioFX.levels() });
    }
  }
  if (!secondChanged) return;
  state.lastSecond = p.second;
  if (el.digitalHours.textContent !== hh) el.digitalHours.textContent = hh;
  if (el.digitalMinutes.textContent !== mm) el.digitalMinutes.textContent = mm;
  el.digitalSeconds.textContent = ss;
  el.digitalAmPm.hidden = state.format !== 12; el.digitalAmPm.textContent = ampm;
  el.orbitTime.textContent = `${hh}:${mm}`;
  const label = `Son las ${hh}:${mm}:${ss} ${ampm}`.trim();
  el.analogClock.setAttribute('aria-label', label);
  el.funClock.setAttribute('aria-label', label);
  el.orbitalClock.setAttribute('aria-label', `Órbita temporal: ${label}; anillos de horas, minutos y segundos`);
  const today = localDateKey(p);
  if (today !== state.lastDate) { const previousDate = state.lastDate; state.lastDate = today; renderDateInfo(p); loadHistory(p); loadHolidays(p); if (previousDate && state.currentWeather) refreshWeather() }
  if (p.minute !== state.lastMinute) {
    state.lastMinute = p.minute;
    el.digitalTz.textContent = timezoneOffset(date);
    applyTheme(p);
    renderAstro(date);
  }
}
function positionOrbitDot(id, r, f) { const angle = f * Math.PI * 2 - Math.PI / 2; el[id].setAttribute('cx', (210 + r * Math.cos(angle)).toFixed(2)); el[id].setAttribute('cy', (210 + r * Math.sin(angle)).toFixed(2)) }
function setRing(id, fraction) { const c = el[id].circ; el[id].style.strokeDasharray = c; el[id].style.strokeDashoffset = c * (1 - Math.min(1, Math.max(0, fraction))) }

function renderDateInfo(p) {
  const d = datePartsAsDate(p), tz = state.location.timezone;
  const weekday = new Intl.DateTimeFormat('es-MX', { weekday: 'long', timeZone: 'UTC' }).format(d);
  const month = new Intl.DateTimeFormat('es-MX', { month: 'long', timeZone: 'UTC' }).format(d);
  const shortMonth = new Intl.DateTimeFormat('es-MX', { month: 'short', timeZone: 'UTC' }).format(d).replace('.', '');
  const weekdayCaps = weekday.toLocaleUpperCase('es-MX'), monthCaps = month.toLocaleUpperCase('es-MX');
  $('introWeekday').textContent = weekdayCaps;
  $('introDate').textContent = `${pad(p.day)} ${shortMonth.toUpperCase()} ${p.year}`;
  $('introTimeZone').textContent = tz;
  $('timezoneName').textContent = tz;
  $('utcOffset').textContent = timezoneOffset(new Date());
  $('digitalWeekday').textContent = weekdayCaps;
  $('orbitSmall').textContent = `${pad(p.day)} ${monthCaps}`;
  $('occasionDay').textContent = pad(p.day);
  $('occasionMonth').textContent = monthCaps;
  $('copyrightYear').textContent = p.year;
  const start = Date.UTC(p.year, 0, 1), now = Date.UTC(p.year, p.month - 1, p.day);
  const n = Math.round((now - start) / 86400000) + 1;
  const total = (Date.UTC(p.year + 1, 0, 1) - start) / 86400000;
  $('dayYear').textContent = n;
  $('daysTotal').textContent = `/ ${total} días`;
  $('yearProgress').style.width = (n / total * 100).toFixed(2) + '%';
  $('yearPercent').textContent = (n / total * 100).toFixed(1) + '% del año';
  $('daysRemaining').textContent = `${total - n} restantes`;
  $('dailyThought').textContent = YEAR_PHRASES[n % YEAR_PHRASES.length];
  applyTheme(p);
  showObservance(p);
}
function makeDial() {
  const marks = $('dialMarks'), nums = $('dialNumbers'), fragM = document.createDocumentFragment(), fragN = document.createDocumentFragment();
  for (let n = 0; n < 60; n++) { const mark = document.createElement('i'); mark.className = 'dial-mark' + (n % 5 === 0 ? ' major' : ''); mark.style.setProperty('--deg', `${n * 6}deg`); fragM.appendChild(mark) }
  for (let n = 1; n <= 12; n++) {
    const angle = n * Math.PI / 6, s = document.createElement('span'); s.className = 'dial-number'; s.textContent = n;
    s.style.setProperty('--x', `${50 + 38 * Math.sin(angle)}%`); s.style.setProperty('--y', `${50 - 38 * Math.cos(angle)}%`); fragN.appendChild(s);
  }
  marks.appendChild(fragM); nums.appendChild(fragN);
  for (const name of ['orbitHours', 'orbitMinutes', 'orbitSeconds']) setRing(name, 0);
}
function updateClockStyles() {
  el.analogClock.hidden = state.clock !== 'analog';
  el.digitalClock.hidden = state.clock !== 'digital';
  el.orbitalClock.hidden = state.clock !== 'orbital';
  el.funClock.hidden = !FUN_TYPES.has(state.clock);
  if (FUN_TYPES.has(state.clock)) { el.funClock.className = `fun-clock fun-${state.clock}`; FunClocks.show(state.clock, state.styles[state.clock], el.funClock) }
  else FunClocks.hide(el.funClock);
  el.analogClock.className = `analog-clock style-${state.styles.analog}`;
  el.digitalClock.className = `digital-clock style-${state.styles.digital}`;
  document.querySelectorAll('#clockTypeSelector button').forEach(b => {
    const active = b.dataset.clock === state.clock; b.classList.toggle('active', active); b.setAttribute('aria-pressed', String(active));
  });
  const host = $('styleSelector'); host.replaceChildren();
  for (const [key, label] of CLOCK_STYLES[state.clock]) {
    const button = document.createElement('button'); button.type = 'button'; button.textContent = label;
    const active = state.styles[state.clock] === key; button.classList.toggle('active', active); button.setAttribute('aria-pressed', String(active));
    button.addEventListener('click', () => { state.styles[state.clock] = key; savePrefs(); updateClockStyles() }); host.appendChild(button);
  }
  $('hourFormatButton').textContent = state.format === 24 ? '24 H' : '12 H';
  $('currentHourFormat').textContent = state.format === 24 ? '24 HORAS' : '12 HORAS';
  $('themeSelect').value = state.theme;
  state.lastSecond = -1; tick(); scheduleFrame();
}
function shortLocation(loc) { return `${loc.name}${loc.country && loc.country !== loc.name ? ', ' + loc.country : ''}` }
function renderLocation() {
  const loc = state.location;
  $('headerLocation').textContent = shortLocation(loc) + (loc.source === 'default' ? ' · predeterminado' : '');
  $('headerLocation').title = loc.source === 'default' ? 'Ubicación predeterminada; puedes elegir tu ciudad.' : shortLocation(loc);
  $('clockCity').textContent = loc.name.toLocaleUpperCase('es-MX');
  $('weatherPlace').textContent = shortLocation(loc);
  $('forecastRegion').textContent = `Pronóstico para ${loc.name}`;
  $('timezoneName').textContent = loc.timezone;
}
function toast(text) { const t = $('toast'); t.textContent = text; t.hidden = false; clearTimeout(toast.timeout); toast.timeout = setTimeout(() => t.hidden = true, 4900) }
async function fetchJson(url, timeout = 12000) {
  const ctrl = new AbortController(), timer = setTimeout(() => ctrl.abort(), timeout);
  try { const r = await fetch(url, { signal: ctrl.signal, headers: { Accept: 'application/json' } }); if (!r.ok) throw Error(`HTTP ${r.status}`); return await r.json() } finally { clearTimeout(timer) }
}
async function setLocation(loc) {
  const id = ++state.geoSequence;
  state.location = { ...loc }; state.currentWeather = null; state.dailyWeather = null; state.holidays = [];
  renderLocation(); savePrefs(); state.lastDate = ''; state.lastSecond = -1; state.lastMinute = -1; tick();
  await refreshWeather();
  if (id !== state.geoSequence) return;
  loadHolidays(zonedParts(new Date()));
}
async function detectLocation(automatic = false) {
  if (!('geolocation' in navigator)) { if (!automatic) toast('Tu navegador no ofrece geolocalización. Busca la ciudad manualmente.'); return }
  if (!window.isSecureContext) { if (!automatic) toast('La ubicación automática necesita HTTPS o localhost. Puedes buscar tu ciudad.'); return }
  $('detectLocation').disabled = true;
  if (!automatic) toast('Solicitando permiso de ubicación al navegador…');
  navigator.geolocation.getCurrentPosition(async (position) => {
    const { latitude, longitude } = position.coords;
    closeModal('locationModal');
    const myLoc = { latitude, longitude, name: 'Mi ubicación', admin1: '', country: '', countryCode: '', timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC', source: 'geo' };
    await setLocation(myLoc);
    reverseGeocode(latitude, longitude, state.geoSequence);
    $('detectLocation').disabled = false;
  }, err => {
    $('detectLocation').disabled = false;
    const reason = err.code === 1 ? 'No se autorizó el acceso a tu ubicación.' : 'No fue posible obtener tu posición actual.';
    if (!automatic) toast(`${reason} Puedes seleccionar una ciudad manualmente.`);
  }, { enableHighAccuracy: false, timeout: 11000, maximumAge: 300000 });
}
async function reverseGeocode(lat, lon, sequence) {
  try {
    const query = new URLSearchParams({ lat: String(lat), lon: String(lon), zoom: '10', format: 'jsonv2', 'accept-language': 'es' });
    const v = await fetchJson(`https://nominatim.openstreetmap.org/reverse?${query}`, 9500);
    if (sequence !== state.geoSequence) return;
    const a = v.address || {};
    Object.assign(state.location, { name: a.city || a.town || a.village || a.municipality || a.county || a.state || 'Mi ubicación', admin1: a.state || '', country: a.country || '', countryCode: (a.country_code || '').toUpperCase() });
    renderLocation(); loadHolidays(zonedParts(new Date()));
  } catch {
    try {
      const v = await fetchJson(`https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${lat}&longitude=${lon}&localityLanguage=es`, 9500);
      if (sequence !== state.geoSequence) return;
      Object.assign(state.location, { name: v.city || v.locality || 'Mi ubicación', country: v.countryName || '', countryCode: v.countryCode || '' });
      renderLocation(); loadHolidays(zonedParts(new Date()));
    } catch { /* La hora y el clima funcionan aun sin una etiqueta de ciudad. */ }
  }
}
async function refreshWeather() {
  const id = ++state.weatherSequence, loc = state.location;
  $('weatherStatus').textContent = 'Actualizando pronóstico…';
  const params = new URLSearchParams({ latitude: String(loc.latitude), longitude: String(loc.longitude), current: 'temperature_2m,relative_humidity_2m,apparent_temperature,is_day,weather_code,wind_speed_10m', daily: 'weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,sunrise,sunset', timezone: 'auto', forecast_days: '5' });
  try {
    const weather = await fetchJson(`https://api.open-meteo.com/v1/forecast?${params}`, 14000);
    if (id !== state.weatherSequence) return;
    if (!weather.current || !weather.daily) throw Error('Datos incompletos');
    state.currentWeather = weather.current; state.dailyWeather = weather.daily;
    const previousTimezone = state.location.timezone;
    if (weather.timezone) { state.location.timezone = weather.timezone; renderLocation() }
    const w = weatherFor(weather.current.weather_code);
    document.body.dataset.weather = w.kind;
    $('weatherIcon').textContent = w.icon;
    $('currentTemp').textContent = Math.round(weather.current.temperature_2m);
    $('weatherDescription').textContent = w.text;
    $('feelsLike').textContent = Math.round(weather.current.apparent_temperature) + '°';
    $('humidity').textContent = Math.round(weather.current.relative_humidity_2m) + '%';
    $('wind').textContent = Math.round(weather.current.wind_speed_10m) + ' km/h';
    $('weatherStatus').textContent = 'Actualizado a las ' + fmtDate(new Date(), { hour: '2-digit', minute: '2-digit' }) + ' · Open-Meteo';
    if (previousTimezone !== state.location.timezone) { state.lastDate = ''; state.lastSecond = -1; state.lastMinute = -1; tick() } else applyTheme(zonedParts(new Date()));
    renderForecast(weather.daily);
  } catch (e) {
    if (id !== state.weatherSequence) return;
    $('weatherStatus').textContent = 'No se pudo actualizar. Intenta recargar.';
    if (!state.currentWeather) $('weatherDescription').textContent = 'Clima temporalmente no disponible';
    const msg = document.createElement('div'); msg.className = 'forecast-placeholder'; msg.textContent = 'No fue posible consultar el pronóstico. Comprueba tu conexión y vuelve a intentarlo.';
    $('forecastGrid').replaceChildren(msg);
    console.warn('Clima:', e.message);
  }
}
function renderForecast(daily) {
  const frag = document.createDocumentFragment(), count = Math.min(5, daily.time.length);
  const dayFmt = new Intl.DateTimeFormat('es-MX', { weekday: 'long', timeZone: 'UTC' }), dateFmt = new Intl.DateTimeFormat('es-MX', { day: 'numeric', month: 'short', timeZone: 'UTC' });
  for (let i = 0; i < count; i++) {
    const day = new Date(`${daily.time[i]}T12:00:00Z`), w = weatherFor(daily.weather_code[i]);
    const name = i === 0 ? 'Hoy' : dayFmt.format(day);
    const card = document.createElement('article'); card.className = 'forecast-card';
    const first = document.createElement('div'); first.className = 'forecast-day'; first.textContent = name.charAt(0).toUpperCase() + name.slice(1);
    const second = document.createElement('div'); second.className = 'forecast-date'; second.textContent = dateFmt.format(day).replace('.', '');
    const middle = document.createElement('div'); middle.className = 'forecast-mid';
    const icon = document.createElement('span'); icon.className = 'forecast-icon'; icon.textContent = w.icon; icon.setAttribute('aria-label', w.text);
    const temps = document.createElement('span'); temps.className = 'forecast-temp'; temps.textContent = Math.round(daily.temperature_2m_max[i]) + '°';
    const min = document.createElement('small'); min.textContent = ' / ' + Math.round(daily.temperature_2m_min[i]) + '°'; temps.appendChild(min);
    middle.append(icon, temps);
    const bottom = document.createElement('div'); bottom.className = 'forecast-bottom';
    const cond = document.createElement('span'); cond.textContent = w.text;
    const prob = document.createElement('b'); prob.textContent = '☂ ' + Math.round(daily.precipitation_probability_max[i] ?? 0) + '%';
    bottom.append(cond, prob); card.append(first, second, middle, bottom); frag.appendChild(card);
  }
  $('forecastGrid').replaceChildren(frag);
}
function showObservance(p) {
  const key = `${pad(p.month)}-${pad(p.day)}`, chosen = (MEXICO_SPECIFIC.has(key) && state.location.countryCode && state.location.countryCode !== 'MX') ? null : OBSERVANCES[key];
  const national = state.holidays.find(h => h.date === localDateKey(p) && (h.global ?? true)) || state.holidays.find(h => h.date === localDateKey(p));
  const holiday = !chosen && national;
  const firstEvent = state.history[0];
  const heading = chosen?.[0] || holiday?.localName || holiday?.name || (firstEvent ? `En ${firstEvent.year}…` : 'Un día con su propia historia');
  const desc = chosen?.[1] || (holiday ? 'Celebración registrada en el calendario público del país seleccionado.' : firstEvent?.text || 'Cada fecha guarda acontecimientos que merecen ser recordados. Explora las efemérides de hoy en la marquesina.');
  $('occasionHeading').textContent = heading;
  $('centralOccasionTitle').textContent = heading;
  $('occasionDescription').textContent = desc;
  document.querySelector('.occasion-symbol').textContent = chosen?.[2] || (holiday ? '✦' : '✧');
  $('occasionTag').textContent = chosen ? 'CONMEMORACIÓN DEL DÍA' : holiday ? 'FESTIVIDAD DEL PAÍS' : 'UN DÍA COMO HOY';
  $('occasionLink').hidden = !firstEvent || !!chosen || !!holiday;
  if (firstEvent?.url) $('occasionLink').href = firstEvent.url;
}
const holidayCache = new Map();
async function loadHolidays(p) {
  const timeKey = localDateKey(p), country = (state.location.countryCode || '').toUpperCase();
  state.holidays = []; showObservance(p);
  if (!/^[A-Z]{2}$/.test(country)) return;
  const cacheKey = country + p.year;
  try {
    if (!holidayCache.has(cacheKey)) holidayCache.set(cacheKey, fetchJson(`https://date.nager.at/api/v3/PublicHolidays/${p.year}/${country}`, 9500));
    const data = await holidayCache.get(cacheKey);
    if (state.location.countryCode.toUpperCase() !== country || state.lastDate !== timeKey) return;
    state.holidays = Array.isArray(data) ? data : []; showObservance(p);
  } catch { holidayCache.delete(cacheKey) /* El calendario editorial sigue visible sin esta API. */ }
}
async function loadHistory(p) {
  const dayKey = localDateKey(p), month = pad(p.month), day = pad(p.day), base = 'https://es.wikipedia.org/api/rest_v1/feed/onthisday';
  $('historyStatus').textContent = 'Consultando efemérides…';
  const results = await Promise.allSettled([`${base}/selected/${month}/${day}`, `${base}/events/${month}/${day}`].map(u => fetchJson(u, 15000)));
  if (dayKey !== state.lastDate) return;
  const items = [], keys = new Set();
  results.forEach((res, i) => {
    if (res.status !== 'fulfilled') return;
    const events = i === 0 ? (res.value.selected || res.value.events || []) : (res.value.events || []);
    for (const event of events) {
      const text = String(event.text || '').replace(/\s+/g, ' ').trim(), year = Number(event.year);
      if (!text || !Number.isFinite(year) || text.length < 30) continue;
      const norm = year + ':' + text.slice(0, 56).toLocaleLowerCase(); if (keys.has(norm)) continue; keys.add(norm);
      const url = event.pages?.find(page => page.content_urls?.desktop?.page)?.content_urls.desktop.page || null;
      items.push({ year, text, url });
    }
  });
  const featured = items.slice(0, Math.min(3, results[0].status === 'fulfilled' ? (results[0].value.selected || []).length : 0));
  const chosen = [...featured], available = items.filter(x => !featured.includes(x)).sort((a, b) => a.year - b.year);
  while (chosen.length < 7 && available.length) chosen.push(available.splice(Math.min(available.length - 1, Math.floor(available.length * (chosen.length % 2 === 0 ? .72 : .33))), 1)[0]);
  if (chosen.length < 7) {
    try {
      const other = await fetchJson(`${base}/births/${month}/${day}`, 12000);
      if (dayKey !== state.lastDate) return;
      for (const event of other.births || []) {
        if (chosen.length >= 7) break;
        if (!event.text || !Number.isFinite(Number(event.year))) continue;
        const url = event.pages?.find(page => page.content_urls?.desktop?.page)?.content_urls.desktop.page || null;
        chosen.push({ year: Number(event.year), text: `Nació: ${event.text.replace(/\s+/g, ' ').trim()}`, url });
      }
    } catch { }
  }
  if (dayKey !== state.lastDate) return;
  state.history = chosen.slice(0, 7);
  showHistory(); showObservance(p);
}
function showHistory() {
  const host = $('historyTrack');
  if (!state.history.length) {
    const msg = document.createElement('span'); msg.className = 'loading-history'; msg.textContent = 'No se pudieron consultar los acontecimientos de hoy. Revisa tu conexión y recarga la página.';
    host.replaceChildren(msg); $('historyStatus').textContent = 'Sin datos históricos disponibles ahora'; return;
  }
  const frag = document.createDocumentFragment();
  [...state.history, ...state.history].forEach((event, i) => {
    const link = document.createElement(event.url ? 'a' : 'div'); link.className = 'marquee-card';
    if (i >= state.history.length) link.setAttribute('aria-hidden', 'true'), link.tabIndex = -1;
    if (event.url) { link.href = event.url; link.target = '_blank'; link.rel = 'noopener noreferrer'; link.setAttribute('aria-label', `Leer efeméride de ${event.year} en Wikipedia`) }
    const year = document.createElement('div'); year.className = 'marquee-year'; year.textContent = event.year + ' · HISTORIA';
    const txt = document.createElement('p'); txt.textContent = event.text;
    const more = document.createElement('span'); more.className = 'marquee-more'; more.textContent = event.url ? 'CONOCER MÁS ↗' : 'DATO HISTÓRICO';
    link.append(year, txt, more); frag.appendChild(link);
  });
  host.replaceChildren(frag);
  host.classList.toggle('paused', state.tickerPaused);
  $('historyStatus').textContent = `${state.history.length} acontecimientos del ${pad(zonedParts(new Date()).day)} · Wikipedia en español`;
}
async function searchCities(name) {
  const target = $('cityResults'), msg = document.createElement('p'); msg.textContent = 'Buscando ciudades…'; target.replaceChildren(msg);
  try {
    const data = await fetchJson('https://geocoding-api.open-meteo.com/v1/search?' + new URLSearchParams({ name, count: '7', language: 'es', format: 'json' }), 11000);
    target.replaceChildren();
    if (!data.results?.length) { msg.textContent = 'No encontramos resultados. Prueba con otra ciudad.'; target.appendChild(msg); return }
    for (const place of data.results) {
      const b = document.createElement('button'); b.type = 'button'; b.textContent = [place.name, place.admin1, place.country].filter(Boolean).join(' · ');
      b.addEventListener('click', () => {
        closeModal('locationModal');
        setLocation({ latitude: place.latitude, longitude: place.longitude, name: place.name, admin1: place.admin1 || '', country: place.country || '', countryCode: place.country_code || '', timezone: place.timezone || 'UTC', source: 'manual' });
        toast(`Ciudad seleccionada: ${place.name}`);
      }); target.appendChild(b);
    }
  } catch { msg.textContent = 'Error al buscar. Revisa tu conexión y vuelve a intentar.'; target.replaceChildren(msg) }
}

/* ── Modales ── */
let lastFocus = null;
function openModal(id, focusId) { lastFocus = document.activeElement; $(id).hidden = false; (focusId ? $(focusId) : $(id).querySelector('button,input,select'))?.focus() }
function closeModal(id) { if ($(id).hidden) return; $(id).hidden = true; lastFocus?.focus?.() }

/* ── Astronomía: fase lunar y minimapa solar ── */
const astroCache = { phases: null, phasesAt: 0, season: null, seasonAt: 0, lat: null };
const SVGNS = 'http://www.w3.org/2000/svg';
function svgEl(tag, attrs, parent) { const n = document.createElementNS(SVGNS, tag); for (const k in attrs) n.setAttribute(k, attrs[k]); parent?.appendChild(n); return n }
function moonSvg(svg, elong, r, flip) {
  svg.replaceChildren();
  const c = 100;
  const defs = svgEl('defs', {}, svg);
  const grad = svgEl('radialGradient', { id: svg.id + 'g', cx: '40%', cy: '35%', r: '75%' }, defs);
  svgEl('stop', { offset: '0%', 'stop-color': '#fbf7e6' }, grad); svgEl('stop', { offset: '100%', 'stop-color': '#d8d0b4' }, grad);
  svgEl('circle', { cx: c, cy: c, r, class: 'moon-dark' }, svg);
  const g = svgEl('g', flip ? { transform: `translate(${2 * c} 0) scale(-1 1)` } : {}, svg);
  const d = Astro.litPath(elong, c, c, r);
  if (d) svgEl('path', { d, fill: `url(#${svg.id}g)` }, g);
  for (const [x, y, rr] of [[-.3, -.2, .16], [.25, .15, .11], [-.05, .4, .09], [.35, -.35, .07], [-.45, .25, .07]]) svgEl('circle', { cx: c + x * r, cy: c + y * r, r: rr * r, class: 'moon-crater' }, svg);
  svgEl('circle', { cx: c, cy: c, r, class: 'moon-rim' }, svg);
}
function fmtShort(date) { return fmtDate(date, { weekday: 'short', day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }).replace(/\./g, '') }
function renderAstro(now = new Date()) {
  if (typeof Astro === 'undefined') return;
  const lat = state.location.latitude, south = lat < 0, ph = Astro.phase(now);
  if (!astroCache.phases || now - astroCache.phasesAt > 3600000 || astroCache.phases[0].date < now) { astroCache.phases = Astro.upcomingPhases(now); astroCache.phasesAt = +now }
  if (!astroCache.season || now - astroCache.seasonAt > 3600000 || astroCache.lat !== lat) { astroCache.season = Astro.nextSeason(now, lat); astroCache.seasonAt = +now; astroCache.lat = lat }
  // Luna
  moonSvg($('moonSvg'), ph.elongation, 86, south);
  $('moonName').textContent = ph.name;
  $('moonIllum').textContent = `${(ph.illumination * 100).toFixed(1)}% iluminada · ${ph.waxing ? 'creciendo' : 'menguando'}`;
  $('moonAge').textContent = `${ph.age.toFixed(1)} días`;
  $('moonDistance').textContent = `${Math.round(ph.moon.distKm).toLocaleString('es-MX')} km`;
  $('moonLon').textContent = `${ph.moon.lon.toFixed(1)}°`;
  $('moonHemisphere').textContent = south ? 'Vista desde el hemisferio sur' : 'Vista desde el hemisferio norte';
  const next = $('moonNext'), frag = document.createDocumentFragment();
  for (const ev of astroCache.phases) {
    const li = document.createElement('li'); const days = Math.round((ev.date - now) / 86400000);
    li.innerHTML = `<span class="moon-ev-emoji"></span><span><b></b><small></small></span><em></em>`;
    li.children[0].textContent = ev.emoji; li.querySelector('b').textContent = ev.name; li.querySelector('small').textContent = fmtShort(ev.date);
    li.querySelector('em').textContent = days <= 0 ? 'hoy' : `en ${days} d`;
    frag.appendChild(li);
  }
  next.replaceChildren(frag);
  const strip = $('moonStrip'), sfrag = document.createDocumentFragment();
  for (let i = 0; i < 8; i++) {
    const d = new Date(+now + i * 86400000), p2 = Astro.phase(d);
    const cell = document.createElement('div'); cell.className = 'moon-day' + (i === 0 ? ' today' : '');
    const svg = svgEl('svg', { viewBox: '0 0 200 200', id: 'ms' + i, 'aria-hidden': 'true' }); moonSvg(svg, p2.elongation, 80, south);
    const lab = document.createElement('span'); lab.textContent = i === 0 ? 'HOY' : fmtDate(d, { weekday: 'short' }).replace('.', '').toUpperCase();
    const pct = document.createElement('small'); pct.textContent = Math.round(p2.illumination * 100) + '%';
    cell.append(lab, svg, pct); sfrag.appendChild(cell);
  }
  strip.replaceChildren(sfrag);
  if (el.clockMoon) el.clockMoon.textContent = `${ph.emoji} ${Math.round(ph.illumination * 100)}%`;
  // Tierra y Sol
  const earth = Astro.planet('earth', now), aps = Astro.apsides(now);
  const season = astroCache.season;
  $('earthDistance').textContent = `${(earth.r * 149597870.7 / 1e6).toFixed(2)} M km`;
  $('earthAu').textContent = `${earth.r.toFixed(4)} UA`;
  $('earthSpeed').textContent = `${Astro.earthSpeed(earth.r).toFixed(2)} km/s`;
  $('earthSeason').textContent = `${Astro.currentSeason(now, lat)} (${south ? 'hemisferio sur' : 'hemisferio norte'})`;
  $('earthNextSeason').textContent = season.date ? `${season.name} · ${fmtShort(season.date)}` : season.name;
  const toPeri = Math.round((aps.perihelion - now) / 86400000), toAph = Math.round((aps.aphelion - now) / 86400000);
  $('earthApsis').textContent = toPeri < toAph ? `Perihelio en ${toPeri} días (punto más cercano)` : `Afelio en ${toAph} días (punto más lejano)`;
  const orbitDeg = Astro.norm(earth.lon - 180);
  $('earthOrbit').textContent = `${orbitDeg.toFixed(1)}° desde el equinoccio de marzo (${(orbitDeg / 3.6).toFixed(1)}% de la vuelta)`;
  const sep = Math.round(ph.elongation);
  $('moonRelative').textContent = `${sep <= 180 ? sep + '° al este' : (360 - sep) + '° al oeste'} del Sol · ${Math.round(ph.moon.distKm).toLocaleString('es-MX')} km`;
  drawSolarMap(now, ph, earth);
  drawEarthMoon(ph, south);
  $('astroUpdated').textContent = 'Calculado en tu navegador · ' + fmtDate(now, { hour: '2-digit', minute: '2-digit' });
}
const MAP = { c: 200, orbits: { mercury: 58, venus: 94, earth: 136, mars: 182 }, colors: { mercury: '#b9b2a6', venus: '#f2cf8a', earth: '#5aa9ff', mars: '#f07a52' }, names: { mercury: 'Mercurio', venus: 'Venus', earth: 'Tierra', mars: 'Marte' } };
function mapXY(lon, R) { return [MAP.c + R * Math.cos(lon * Math.PI / 180), MAP.c - R * Math.sin(lon * Math.PI / 180)] }
function drawSolarMap(now, ph, earth) {
  const svg = $('solarMap'); svg.replaceChildren();
  const defs = svgEl('defs', {}, svg);
  const sg = svgEl('radialGradient', { id: 'sunGlow' }, defs);
  svgEl('stop', { offset: '0%', 'stop-color': '#fff3b0' }, sg); svgEl('stop', { offset: '45%', 'stop-color': '#ffc34d' }, sg); svgEl('stop', { offset: '100%', 'stop-color': 'rgba(255,170,60,0)' }, sg);
  // Rumbos de las estaciones (posición de la Tierra en cada equinoccio/solsticio).
  for (const [lon, label] of [[180, 'EQUINOCCIO MAR'], [270, 'SOLSTICIO JUN'], [0, 'EQUINOCCIO SEP'], [90, 'SOLSTICIO DIC']]) {
    const [x1, y1] = mapXY(lon, MAP.orbits.earth - 7), [x2, y2] = mapXY(lon, MAP.orbits.earth + 7), [tx, ty] = mapXY(lon, MAP.orbits.earth + (lon % 180 ? 16 : 24));
    svgEl('line', { x1, y1, x2, y2, class: 'map-tick' }, svg);
    const t = svgEl('text', { x: tx, y: ty + 3, class: 'map-season', 'text-anchor': 'middle' }, svg); t.textContent = label;
    if (lon % 180 === 0) t.setAttribute('transform', `rotate(${lon === 0 ? 90 : -90} ${tx} ${ty})`);
  }
  for (const name of Object.keys(MAP.orbits)) svgEl('circle', { cx: MAP.c, cy: MAP.c, r: MAP.orbits[name], class: 'map-orbit' + (name === 'earth' ? ' earth-orbit' : '') }, svg);
  // Estela de los últimos 30 días de la Tierra.
  let trail = '';
  for (let i = 30; i >= 0; i -= 2) { const e = Astro.planet('earth', new Date(+now - i * 86400000)); const [x, y] = mapXY(e.lon, MAP.orbits.earth * e.r); trail += (trail ? 'L' : 'M') + x.toFixed(1) + ' ' + y.toFixed(1) }
  svgEl('path', { d: trail, class: 'map-trail' }, svg);
  svgEl('circle', { cx: MAP.c, cy: MAP.c, r: 30, fill: 'url(#sunGlow)' }, svg);
  svgEl('circle', { cx: MAP.c, cy: MAP.c, r: 12, class: 'map-sun' }, svg);
  for (const name of ['mercury', 'venus', 'mars', 'earth']) {
    const pl = Astro.planet(name, now), R = MAP.orbits[name] * pl.r / pl.a, [x, y] = mapXY(pl.lon, R);
    const g = svgEl('g', { class: 'map-planet' }, svg);
    const title = svgEl('title', {}, g); title.textContent = `${MAP.names[name]}: ${pl.r.toFixed(3)} UA del Sol`;
    if (name === 'earth') {
      svgEl('circle', { cx: x, cy: y, r: 20, class: 'map-moon-orbit' }, g);
      const [mx, my] = [x + 20 * Math.cos(ph.moon.lon * Math.PI / 180), y - 20 * Math.sin(ph.moon.lon * Math.PI / 180)];
      svgEl('line', { x1: MAP.c, y1: MAP.c, x2: x, y2: y, class: 'map-sunline' }, g);
      svgEl('circle', { cx: x, cy: y, r: 7.5, fill: MAP.colors.earth, class: 'map-earth' }, g);
      svgEl('circle', { cx: mx, cy: my, r: 3.2, class: 'map-moon' }, g);
      const t = svgEl('text', { x, y: y + 33, class: 'map-label strong', 'text-anchor': 'middle' }, g); t.textContent = 'TIERRA';
    } else {
      svgEl('circle', { cx: x, cy: y, r: name === 'mercury' ? 3.5 : 5, fill: MAP.colors[name] }, g);
      const t = svgEl('text', { x, y: y - 9, class: 'map-label', 'text-anchor': 'middle' }, g); t.textContent = MAP.names[name].toUpperCase();
    }
  }
}
function drawEarthMoon(ph, south) {
  const svg = $('earthMoonMap'); svg.replaceChildren();
  const c = 100, sunDir = 180; // El Sol se dibuja a la izquierda y la geometría gira con él.
  const rel = Astro.norm(ph.elongation), ang = (sunDir + rel) * Math.PI / 180;
  svgEl('circle', { cx: c, cy: c, r: 66, class: 'map-moon-orbit' }, svg);
  for (let i = 0; i < 7; i++) svgEl('line', { x1: 4, y1: 30 + i * 23, x2: 26, y2: 30 + i * 23, class: 'em-ray' }, svg);
  const st = svgEl('text', { x: 6, y: 18, class: 'map-label' }, svg); st.textContent = '☀ LUZ SOLAR';
  svgEl('circle', { cx: c, cy: c, r: 16, class: 'em-earth-night' }, svg);
  svgEl('path', { d: `M${c} ${c - 16} A16 16 0 0 0 ${c} ${c + 16}Z`, class: 'em-earth-day' }, svg);
  const mx = c + 66 * Math.cos(ang), my = c - 66 * Math.sin(ang);
  svgEl('circle', { cx: mx, cy: my, r: 8, class: 'em-moon-night' }, svg);
  svgEl('path', { d: `M${mx} ${my - 8} A8 8 0 0 0 ${mx} ${my + 8}Z`, class: 'em-moon-day' }, svg);
  const t = svgEl('text', { x: mx, y: my + (my > c ? 22 : -14), class: 'map-label strong', 'text-anchor': 'middle' }, svg); t.textContent = 'LUNA';
  const e = svgEl('text', { x: c, y: c + 32, class: 'map-label', 'text-anchor': 'middle' }, svg); e.textContent = 'TIERRA';
  svg.setAttribute('aria-label', `La Luna está a ${Math.round(rel)} grados del Sol vista desde la Tierra (${ph.name.toLowerCase()})${south ? '; desde el hemisferio sur se ve invertida' : ''}`);
}

/* ── Fondos personalizados ── */
function bgImage() { try { return localStorage.getItem(BG_IMAGE_KEY) || '' } catch { return sessionBg || '' } }
let sessionBg = '';
function applyBackground() {
  const sc = document.querySelector('.scenery'), layer = $('bgLayer'), bg = state.bg;
  const mode = bg.mode === 'theme' ? bg.theme : bg.mode;
  sc.dataset.bg = mode;
  BgFX.set(bg.mode === 'theme' && BgFX.MODES.includes(bg.theme) ? bg.theme : null);
  layer.replaceChildren(); layer.style.backgroundImage = ''; layer.style.filter = '';
  if (bg.mode === 'image' || bg.mode === 'url') {
    const src = bg.mode === 'image' ? (bgImage() || sessionBg) : bg.url;
    if (src) { const safe = src.replace(/["\\\n\r]/g, ''); layer.style.backgroundImage = `url("${safe}")`; layer.style.filter = bg.blur ? `blur(${bg.blur}px)` : '' }
  } else if (bg.mode === 'gradient') {
    layer.style.backgroundImage = `linear-gradient(145deg, ${bg.colors[0]}, ${bg.colors[1]})`;
  } else if (mode === 'sakura' || mode === 'galaxia' || mode === 'aurora' || mode === 'synthwave' || mode === 'oceano' || mode === 'bosque' || mode === 'desierto') {
    decorateTheme(layer, mode);
  }
  $('bgDim').style.opacity = String(bg.mode === 'weather' ? 0 : bg.dim / 100);
  applyTheme(zonedParts(new Date()));
  document.querySelectorAll('#bgThemes button').forEach(b => b.classList.toggle('active', (bg.mode === 'theme' && b.dataset.bg === bg.theme) || (bg.mode === 'weather' && b.dataset.bg === 'weather')));
  $('bgDimRange').value = bg.dim; $('bgBlurRange').value = bg.blur; $('bgColorA').value = bg.colors[0]; $('bgColorB').value = bg.colors[1];
}
function decorateTheme(layer, mode) {
  const frag = document.createDocumentFragment(), rnd = (a, b) => a + Math.random() * (b - a);
  const add = (cls, styles) => { const s = document.createElement('i'); s.className = cls; Object.assign(s.style, styles); frag.appendChild(s) };
  if (mode === 'sakura') for (let i = 0; i < 22; i++) add('petal', { left: rnd(0, 100) + '%', animationDelay: -rnd(0, 18) + 's', animationDuration: rnd(11, 20) + 's', transform: `scale(${rnd(.6, 1.3)})` });
  if (mode === 'galaxia') { for (let i = 0; i < 70; i++) add('star', { left: rnd(0, 100) + '%', top: rnd(0, 100) + '%', animationDelay: -rnd(0, 4) + 's', width: rnd(1, 3) + 'px', height: '' }); add('nebula', {}) }
  if (mode === 'aurora') for (let i = 0; i < 3; i++) add('aurora-band b' + i, {});
  if (mode === 'synthwave') { add('synth-sun', {}); add('synth-grid', {}) }
  if (mode === 'oceano') for (let i = 0; i < 3; i++) add('wave w' + i, {});
  if (mode === 'oceano' || mode === 'bosque') for (let i = 0; i < 16; i++) add(mode === 'oceano' ? 'bubble' : 'firefly', { left: rnd(0, 100) + '%', top: mode === 'bosque' ? rnd(30, 95) + '%' : '', animationDelay: -rnd(0, 14) + 's', animationDuration: rnd(8, 16) + 's' });
  if (mode === 'desierto') { add('dune d0', {}); add('dune d1', {}) }
  layer.appendChild(frag);
}
function compressImage(file) {
  return new Promise((resolve, reject) => {
    const img = new Image(), url = URL.createObjectURL(file);
    img.onload = () => {
      const max = 1920, k = Math.min(1, max / Math.max(img.width, img.height));
      const c = document.createElement('canvas'); c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height); URL.revokeObjectURL(url);
      resolve(c.toDataURL('image/jpeg', .82));
    };
    img.onerror = () => { URL.revokeObjectURL(url); reject(Error('Imagen no válida')) };
    img.src = url;
  });
}
function initBackgrounds() {
  const host = $('bgThemes');
  for (const [key, label, preview] of BG_THEMES) {
    const b = document.createElement('button'); b.type = 'button'; b.dataset.bg = key;
    const sw = document.createElement('span'); sw.className = 'bg-swatch'; sw.style.background = preview;
    const t = document.createElement('span'); t.textContent = label; b.append(sw, t);
    b.addEventListener('click', () => { state.bg.mode = key === 'weather' ? 'weather' : 'theme'; state.bg.theme = key; savePrefs(); applyBackground() });
    host.appendChild(b);
  }
  $('bgFile').addEventListener('change', async e => {
    const file = e.target.files?.[0]; if (!file) return;
    if (!file.type.startsWith('image/')) { toast('Elige un archivo de imagen (JPG, PNG, WEBP…).'); return }
    try {
      const data = await compressImage(file);
      sessionBg = data;
      try { localStorage.setItem(BG_IMAGE_KEY, data) } catch { toast('La imagen es grande: se usará en esta visita, pero no se guardará.') }
      state.bg.mode = 'image'; savePrefs(); applyBackground(); toast('Fondo personalizado aplicado.');
    } catch { toast('No se pudo leer esa imagen.') }
    e.target.value = '';
  });
  $('bgUrlForm').addEventListener('submit', e => {
    e.preventDefault(); const url = $('bgUrl').value.trim();
    if (!/^https:\/\/\S+$/i.test(url)) { toast('Escribe una dirección que empiece con https://'); return }
    state.bg.mode = 'url'; state.bg.url = url; savePrefs(); applyBackground(); toast('Fondo desde URL aplicado.');
  });
  const grad = () => { state.bg.mode = 'gradient'; state.bg.colors = [$('bgColorA').value, $('bgColorB').value]; savePrefs(); applyBackground() };
  $('bgColorA').addEventListener('input', grad); $('bgColorB').addEventListener('input', grad);
  $('bgDimRange').addEventListener('input', e => { state.bg.dim = +e.target.value; $('bgDim').style.opacity = state.bg.mode === 'weather' ? 0 : state.bg.dim / 100; savePrefs() });
  $('bgBlurRange').addEventListener('input', e => { state.bg.blur = +e.target.value; savePrefs(); applyBackground() });
  $('bgReset').addEventListener('click', () => { state.bg = { ...defaultBg }; try { localStorage.removeItem(BG_IMAGE_KEY) } catch { } sessionBg = ''; savePrefs(); applyBackground(); toast('Fondo restablecido al clima en vivo.') });
  $('bgButton').addEventListener('click', () => openModal('bgModal'));
  $('closeBg').addEventListener('click', () => closeModal('bgModal'));
  applyBackground();
}

/* ── Radio (la reproducción y el análisis de audio viven en AudioFX) ── */
function stationOptions() {
  const sel = $('radioStation'); sel.replaceChildren();
  const groups = [...STATION_GROUPS];
  if (customStations.length) groups.push(['Mis emisoras', Object.fromEntries(customStations.map(s => [s.id, STATIONS[s.id]]))]);
  for (const [label, list] of groups) {
    const og = document.createElement('optgroup'); og.label = label;
    for (const [id, st] of Object.entries(list)) { const o = document.createElement('option'); o.value = id; o.textContent = st.name; og.appendChild(o) }
    sel.appendChild(og);
  }
  sel.value = state.station;
  $('removeStation').hidden = !STATIONS[state.station]?.custom;
  $('stationCount').textContent = `${Object.keys(STATIONS).length} emisoras`;
}
function setRadioUi(playing, status) {
  $('radioToggle').textContent = playing ? 'Ⅱ' : '▶';
  $('radioToggle').setAttribute('aria-label', playing ? 'Pausar radio' : 'Reproducir radio');
  document.querySelector('.radio-panel').classList.toggle('is-playing', playing);
  if (status) $('radioStatus').textContent = status;
}
function changeAudioStation(autoplay = false) {
  AudioFX.pause(); state.playing = false; state.urlIndex = 0;
  setRadioUi(false, autoplay ? 'Conectando con la emisora…' : 'Pulsa reproducir para escuchar');
  $('removeStation').hidden = !STATIONS[state.station]?.custom;
  if (autoplay) startRadio();
}
async function startRadio() {
  const st = STATIONS[state.station], station = state.station;
  setRadioUi(false, 'Conectando con ' + st.name + '…');
  try {
    const how = await AudioFX.play(st.urls[state.urlIndex]);
    if (how === 'stale' || station !== state.station) return;
    state.playing = true;
    setRadioUi(true, how === 'real' ? 'Reproduciendo en vivo · animaciones al ritmo real' : 'Reproduciendo en vivo · ritmo estimado');
  } catch (err) {
    if (station !== state.station) return;
    if (err?.name === 'NotAllowedError') { setRadioUi(false, 'Pulsa reproducir para escuchar'); return }
    tryNextUrl();
  }
}
function tryNextUrl() {
  const st = STATIONS[state.station];
  if (state.urlIndex + 1 < st.urls.length) { state.urlIndex++; startRadio(); return }
  state.playing = false; state.urlIndex = 0; setRadioUi(false, 'La transmisión no responde. Prueba con otra emisora.');
}
function initRadio() {
  stationOptions();
  $('radioVolume').value = String(Math.round(state.volume * 100)); $('volumeText').textContent = Math.round(state.volume * 100) + '%';
  AudioFX.setVolume(state.volume);
  $('radioToggle').addEventListener('click', () => { if (state.playing) { AudioFX.pause(); state.playing = false; setRadioUi(false, 'En pausa') } else { state.urlIndex = 0; startRadio() } });
  $('radioStation').addEventListener('change', e => { const play = state.playing; state.station = e.target.value; savePrefs(); changeAudioStation(play) });
  const stepStation = dir => { const ids = [...$('radioStation').options].map(o => o.value), i = ids.indexOf(state.station), play = state.playing; state.station = ids[(i + dir + ids.length) % ids.length]; $('radioStation').value = state.station; savePrefs(); changeAudioStation(play) };
  $('prevStation').addEventListener('click', () => stepStation(-1));
  $('nextStation').addEventListener('click', () => stepStation(1));
  $('radioVolume').addEventListener('input', e => { state.volume = Number(e.target.value) / 100; AudioFX.setVolume(state.volume); $('volumeText').textContent = e.target.value + '%'; savePrefs() });
  AudioFX.on('waiting', () => { if (state.playing) $('radioStatus').textContent = 'Cargando transmisión…' });
  AudioFX.on('playing', () => { if (state.playing) setRadioUi(true) });
  AudioFX.on('error', () => { if (state.playing) { state.playing = false; tryNextUrl() } });
  $('addStationToggle').addEventListener('click', () => { const f = $('stationForm'); f.hidden = !f.hidden; if (!f.hidden) $('stationName').focus() });
  $('stationForm').addEventListener('submit', e => {
    e.preventDefault();
    const name = $('stationName').value.trim().slice(0, 60), url = $('stationUrl').value.trim();
    if (!name || !/^https?:\/\/\S+$/i.test(url)) { toast('Escribe un nombre y una URL de stream válida (MP3/AAC).'); return }
    if (location.protocol === 'https:' && url.startsWith('http:')) toast('Aviso: en páginas HTTPS los streams http:// suelen bloquearse.');
    const id = 'custom-' + Date.now().toString(36);
    customStations.push({ id, name, url }); STATIONS[id] = { name, urls: [url], custom: true };
    state.station = id; savePrefs(); stationOptions(); changeAudioStation(false);
    $('stationForm').reset(); $('stationForm').hidden = true; toast(`Emisora «${name}» agregada.`);
  });
  $('removeStation').addEventListener('click', () => {
    const id = state.station; if (!STATIONS[id]?.custom) return;
    const i = customStations.findIndex(s => s.id === id); if (i >= 0) customStations.splice(i, 1);
    delete STATIONS[id]; state.station = 'paradise'; savePrefs(); stationOptions(); changeAudioStation(false); toast('Emisora eliminada.');
  });
}

/* ── Minimapa solar: clásico o animado ── */
const SOLAR_INFO = {
  classic: 'Posiciones reales de hoy vistas desde el norte de la eclíptica.',
  orbits: 'Órbitas en 3D a cámara rápida, con estelas. Empieza en las posiciones reales de hoy.',
  vortex: 'Modelo helicoidal: el Sol viaja por la galaxia y los planetas lo siguen trazando espirales (ilustrativo, sin escala).',
  geo: 'Vista geocéntrica: así se mueven el Sol y los planetas vistos desde la Tierra; los bucles son los movimientos retrógrados.'
};
function syncSolarControls() {
  const m = state.solarMode, animated = m !== 'classic';
  document.querySelectorAll('#solarModes button').forEach(b => { const on = b.dataset.mode === m; b.classList.toggle('active', on); b.setAttribute('aria-pressed', String(on)) });
  $('solarMap').toggleAttribute('hidden', animated); $('solarCanvas').hidden = !animated; $('solarAnimControls').hidden = !animated;
  $('solarModeInfo').textContent = SOLAR_INFO[m] + (animated && motionReduced() ? ' (Modo normal: imagen fija; activa las animaciones para verla en movimiento).' : '');
  $('solarPlay').textContent = SolarAnim.playing ? 'Ⅱ Pausa' : '▶ Reproducir';
}
function initSolar() {
  SolarAnim.init($('solarCanvas'), (date, days) => {
    $('solarSimDate').textContent = fmtDate(date, { day: 'numeric', month: 'short', year: 'numeric' }).replace('.', '') + (Math.abs(days) < .5 ? ' · hoy' : ` · ${days > 0 ? '+' : ''}${Math.round(days)} días`);
  });
  document.querySelectorAll('#solarModes button').forEach(b => b.addEventListener('click', () => { state.solarMode = b.dataset.mode; SolarAnim.setMode(state.solarMode); savePrefs(); syncSolarControls() }));
  $('solarPlay').addEventListener('click', () => { SolarAnim.setPlaying(!SolarAnim.playing); syncSolarControls() });
  $('solarSpeed').addEventListener('change', e => SolarAnim.setSpeed(Number(e.target.value)));
  $('solarToday').addEventListener('click', () => SolarAnim.reset());
  SolarAnim.setSpeed(Number($('solarSpeed').value));
  SolarAnim.setMode(state.solarMode);
}

function initControls() {
  document.querySelectorAll('#clockTypeSelector button').forEach(b => b.addEventListener('click', () => { state.clock = b.dataset.clock; savePrefs(); updateClockStyles() }));
  $('hourFormatButton').addEventListener('click', () => { state.format = state.format === 24 ? 12 : 24; savePrefs(); updateClockStyles() });
  $('themeSelect').addEventListener('change', e => { state.theme = e.target.value; savePrefs(); applyTheme(zonedParts(new Date())) });
  $('locationButton').addEventListener('click', () => openModal('locationModal', 'citySearch'));
  $('closeModal').addEventListener('click', () => closeModal('locationModal'));
  for (const id of ['locationModal', 'bgModal']) $(id).addEventListener('click', e => { if (e.target === $(id)) closeModal(id) });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') { closeModal('locationModal'); closeModal('bgModal') } });
  $('detectLocation').addEventListener('click', () => detectLocation(false));
  $('cityForm').addEventListener('submit', e => { e.preventDefault(); const name = $('citySearch').value.trim(); if (name.length >= 2) searchCities(name) });
  $('tickerToggle').addEventListener('click', () => { state.tickerPaused = !state.tickerPaused; $('historyTrack').classList.toggle('paused', state.tickerPaused); $('tickerToggle').textContent = state.tickerPaused ? '▶ Reanudar marquesina' : 'Ⅱ Pausar marquesina'; $('tickerToggle').setAttribute('aria-pressed', String(state.tickerPaused)) });
  $('motionButton').addEventListener('click', () => { state.motion = state.motion === 'full' ? 'normal' : 'full'; savePrefs(); applyMotion(); state.lastSecond = -1; tick(); toast(state.motion === 'full' ? 'Animaciones completas activadas.' : 'Modo normal: sin animaciones de fondo ni efectos.') });
  prefersReduced?.addEventListener?.('change', applyMotion);
  $('fullscreenButton').addEventListener('click', () => {
    const panel = document.querySelector('.clock-panel');
    if (document.fullscreenElement) document.exitFullscreen?.(); else panel.requestFullscreen?.().catch(() => toast('Tu navegador no permite pantalla completa aquí.'));
  });
}
function start() {
  cacheElements(); makeDial(); BgFX.init($('bgCanvas')); initSolar(); initControls(); initRadio(); initBackgrounds(); applyMotion();
  const saved = initialPrefs.manualLocation;
  if (saved && Number.isFinite(saved.latitude) && Number.isFinite(saved.longitude) && saved.source === 'manual') setLocation(saved);
  else { setLocation({ ...DEFAULT_LOCATION }); if(!window.__AURA_PORTAL_EMBED__) detectLocation(true) }
  updateClockStyles();
  setInterval(() => { if (document.visibilityState === 'visible') refreshWeather() }, 15 * 60 * 1000);
  document.addEventListener('visibilitychange', () => { state.lastSecond = -1; if (document.visibilityState === 'visible') { state.lastMinute = -1; tick() } scheduleFrame() });
}
start();
