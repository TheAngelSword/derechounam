/* Aura Crono · AudioFX: reproduce la radio y entrega niveles de audio para animaciones reactivas.
   Intenta el stream con CORS (permite analizar el espectro real). Si la emisora no lo permite,
   reproduce el stream normal y genera un pulso musical simulado para que las animaciones sigan bailando. */
'use strict';
const AudioFX = (() => {
  const plain = document.getElementById('radioAudio');
  const cors = new Audio(); cors.crossOrigin = 'anonymous'; cors.preload = 'none';
  let active = plain, actx = null, analyser = null, gain = null, freq = null, wired = false;
  let real = false, volume = .65, token = 0;
  const avg = { bass: .2 }, out = { bass: 0, mid: 0, treble: 0, energy: 0, beat: false, spectrum: new Float32Array(64), playing: false, real: false };
  let lastBeat = 0;

  function ensureContext() {
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return false;
    if (!actx) {
      actx = new AC();
      analyser = actx.createAnalyser(); analyser.fftSize = 512; analyser.smoothingTimeConstant = .78;
      gain = actx.createGain(); gain.gain.value = volume;
      analyser.connect(gain); gain.connect(actx.destination);
      freq = new Uint8Array(analyser.frequencyBinCount);
    }
    if (actx.state === 'suspended') actx.resume().catch(() => { });
    return true;
  }
  function wire() {
    if (wired || !actx) return;
    try { actx.createMediaElementSource(cors).connect(analyser); wired = true; cors.volume = 1 } catch { }
  }
  function stopAll() { for (const a of [plain, cors]) { a.pause(); a.removeAttribute('src'); a.load() } }

  async function play(url) {
    const my = ++token;
    const canAnalyse = ensureContext();
    stopAll();
    if (canAnalyse) {
      try {
        cors.src = url; if (!wired) cors.volume = volume;
        await cors.play();
        if (my !== token) return 'stale';
        wire(); active = cors; real = wired; return real ? 'real' : 'sim';
      } catch (e) {
        if (my !== token) return 'stale';
        if (e.name === 'NotAllowedError') throw e;
        cors.pause(); cors.removeAttribute('src');
      }
    }
    plain.src = url; plain.volume = volume;
    await plain.play();
    if (my !== token) return 'stale';
    active = plain; real = false; return 'sim';
  }
  function pause() { token++; plain.pause(); cors.pause(); }
  function setVolume(v) { volume = v; plain.volume = v; if (wired) gain.gain.value = v; else cors.volume = v; }
  function on(type, fn) { for (const a of [plain, cors]) a.addEventListener(type, e => { if (e.target === active) fn(e) }); }
  const isPlaying = () => !active.paused && !active.ended && active.readyState > 2;

  function levels(now = performance.now()) {
    const playing = isPlaying();
    out.playing = playing; out.real = playing && real; out.beat = false;
    const sp = out.spectrum;
    if (playing && real) {
      analyser.getByteFrequencyData(freq);
      const n = freq.length, band = (a, b) => { let s = 0; for (let i = a; i < b; i++) s += freq[i]; return s / (b - a) / 255 };
      out.bass = band(1, 7); out.mid = band(7, 40); out.treble = band(40, Math.min(140, n));
      for (let i = 0; i < 64; i++) { const k = Math.floor(Math.pow(i / 64, 1.6) * (n * .7)) + 1; sp[i] = freq[k] / 255 }
    } else {
      const t = now / 1000, bpm = playing ? 118 : 60, ph = (t * bpm / 60) % 1, kick = Math.pow(1 - ph, 4);
      const amp = playing ? 1 : .25;
      out.bass = amp * (.25 + .6 * kick);
      out.mid = amp * (.35 + .2 * Math.sin(t * 3.1) * Math.sin(t * 1.3) + .1 * Math.sin(t * 7));
      out.treble = amp * (.25 + .15 * Math.abs(Math.sin(t * 9.7)) + .1 * Math.sin(t * 13));
      for (let i = 0; i < 64; i++) {
        const base = i < 8 ? out.bass : i < 30 ? out.mid : out.treble;
        sp[i] = Math.max(0, Math.min(1, base * (1 - i / 110) + .15 * amp * Math.sin(t * (2 + i * .37) + i)));
      }
    }
    out.energy = out.bass * .5 + out.mid * .3 + out.treble * .2;
    avg.bass = avg.bass * .96 + out.bass * .04;
    if (playing && out.bass > avg.bass * 1.28 && out.bass > .3 && now - lastBeat > 280) { out.beat = true; lastBeat = now }
    out.sinceBeat = (now - lastBeat) / 1000;
    return out;
  }
  return { play, pause, setVolume, on, levels, isPlaying, get active() { return active }, get real() { return real } };
})();
