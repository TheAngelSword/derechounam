/* Aura Crono · Relojes mecánicos con la maquinaria a la vista:
   Esqueleto (tren de engranajes, escape y volante), Tourbillon (jaula giratoria) y Astronómico 3D (carrusel con planetas-gema). */
'use strict';
(() => {
  const { makeCanvas, pad, hourText, TAU } = FunClocks.util;
  const gearCache = new Map();

  // Rueda dentada como Path2D centrada en el origen (dientes + llanta + radios recortados).
  function gearPath(r, teeth, spokes = 5, depth = .09) {
    const key = [r.toFixed(1), teeth, spokes, depth].join('|');
    if (gearCache.has(key)) return gearCache.get(key);
    const p = new Path2D(), ri = r * (1 - depth), step = TAU / teeth;
    for (let i = 0; i < teeth; i++) {
      const a = i * step;
      const pts = [[ri, a], [r, a + step * .18], [r, a + step * .48], [ri, a + step * .66]];
      pts.forEach(([rr, aa], k) => (i === 0 && k === 0) ? p.moveTo(rr * Math.cos(aa), rr * Math.sin(aa)) : p.lineTo(rr * Math.cos(aa), rr * Math.sin(aa)));
    }
    p.closePath();
    if (spokes && r > 12) {
      // Huecos entre radios (se rellenan con la regla evenodd).
      const rin = ri * .8, hub = Math.max(3, r * .2), half = (TAU / spokes) / 2, gap = Math.min(.5, 2.4 / spokes) * .5;
      for (let s = 0; s < spokes; s++) {
        const a0 = s * TAU / spokes + gap, a1 = (s + 1) * TAU / spokes - gap;
        p.moveTo(rin * Math.cos(a0), rin * Math.sin(a0));
        p.arc(0, 0, rin, a0, a1);
        p.lineTo(hub * 1.6 * Math.cos(a1 - half * .2), hub * 1.6 * Math.sin(a1 - half * .2));
        p.arc(0, 0, hub * 1.6, a1 - half * .2, a0 + half * .2, true);
        p.closePath();
      }
    }
    gearCache.set(key, p);
    return p;
  }
  function drawGear(g, x, y, r, teeth, angle, fill, opts = {}) {
    g.save(); g.translate(x, y); g.rotate(angle);
    g.shadowColor = 'rgba(0,0,0,.55)'; g.shadowBlur = r * .12; g.shadowOffsetY = r * .06;
    g.fillStyle = fill; g.fill(gearPath(r, teeth, opts.spokes ?? 5, opts.depth), 'evenodd');
    g.shadowColor = 'transparent';
    g.strokeStyle = 'rgba(70,40,0,.45)'; g.lineWidth = .8; g.stroke(gearPath(r, teeth, opts.spokes ?? 5, opts.depth));
    g.restore();
    jewel(g, x, y, Math.max(2, r * .09));
  }
  function jewel(g, x, y, r) {
    const gr = g.createRadialGradient(x - r * .3, y - r * .3, 0, x, y, r);
    gr.addColorStop(0, '#ff9aa8'); gr.addColorStop(.5, '#c3122f'); gr.addColorStop(1, '#5a0010');
    g.fillStyle = '#d8c48c'; g.beginPath(); g.arc(x, y, r * 1.7, 0, TAU); g.fill();
    g.fillStyle = gr; g.beginPath(); g.arc(x, y, r, 0, TAU); g.fill();
  }
  function screw(g, x, y, r, a = .6) {
    const gr = g.createRadialGradient(x - r * .3, y - r * .3, 0, x, y, r);
    gr.addColorStop(0, '#9fc3ff'); gr.addColorStop(1, '#1d3a8a');
    g.fillStyle = gr; g.beginPath(); g.arc(x, y, r, 0, TAU); g.fill();
    g.strokeStyle = 'rgba(10,20,50,.8)'; g.lineWidth = Math.max(1, r * .3);
    g.beginPath(); g.moveTo(x - r * Math.cos(a), y - r * Math.sin(a)); g.lineTo(x + r * Math.cos(a), y + r * Math.sin(a)); g.stroke();
  }
  const goldFill = (g, r) => { const gr = g.createLinearGradient(-r, -r, r, r); gr.addColorStop(0, '#fff1b8'); gr.addColorStop(.35, '#e2b04a'); gr.addColorStop(.7, '#9c6a18'); gr.addColorStop(1, '#f3d27a'); return gr };
  const steelFill = (g, r) => { const gr = g.createLinearGradient(-r, -r, r, r); gr.addColorStop(0, '#f4f6f8'); gr.addColorStop(.5, '#9aa4ae'); gr.addColorStop(1, '#dde3e8'); return gr };

  function balance(g, x, y, r, ang, ctx) {
    // Espiral (muelle) que "respira" con la oscilación.
    g.save(); g.translate(x, y);
    g.strokeStyle = 'rgba(200,215,235,.75)'; g.lineWidth = 1; g.beginPath();
    for (let t = 0; t < 1; t += .01) { const rr = r * (.12 + .6 * t) * (1 + .04 * Math.sin(ang)), a = t * TAU * 5 + ang * .25; t === 0 ? g.moveTo(rr * Math.cos(a), rr * Math.sin(a)) : g.lineTo(rr * Math.cos(a), rr * Math.sin(a)) }
    g.stroke();
    g.rotate(ang);
    g.shadowColor = 'rgba(0,0,0,.5)'; g.shadowBlur = 6; g.shadowOffsetY = 3;
    g.strokeStyle = goldFill(g, r); g.lineWidth = r * .16; g.beginPath(); g.arc(0, 0, r * .9, 0, TAU); g.stroke();
    g.shadowColor = 'transparent'; g.lineWidth = r * .1;
    for (let i = 0; i < 3; i++) { const a = i * TAU / 3; g.beginPath(); g.moveTo(0, 0); g.lineTo(r * .85 * Math.cos(a), r * .85 * Math.sin(a)); g.stroke() }
    for (let i = 0; i < 8; i++) { const a = i * TAU / 8; g.fillStyle = '#f7e2a0'; g.beginPath(); g.arc(r * .9 * Math.cos(a), r * .9 * Math.sin(a), r * .07, 0, TAU); g.fill() }
    g.restore();
    jewel(g, x, y, Math.max(2, r * .1));
  }
  function anchor(g, x, y, r, ang) {
    g.save(); g.translate(x, y); g.rotate(ang); g.fillStyle = steelFill(g, r);
    g.beginPath(); g.moveTo(-r, -r * .15); g.lineTo(0, -r * .25); g.lineTo(r, -r * .15); g.lineTo(r * .85, r * .25); g.lineTo(r * .15, r * .05); g.lineTo(0, r * 1.2); g.lineTo(-r * .15, r * .05); g.lineTo(-r * .85, r * .25); g.closePath(); g.fill();
    g.fillStyle = '#c3122f'; g.fillRect(-r * .95, r * .1, r * .18, r * .22); g.fillRect(r * .77, r * .1, r * .18, r * .22);
    g.restore();
  }
  function breguetHand(g, cx, cy, len, ang, width, color) {
    g.save(); g.translate(cx, cy); g.rotate(ang); g.fillStyle = color; g.strokeStyle = color;
    g.beginPath(); g.moveTo(-width * .5, len * .12); g.lineTo(-width * .35, -len * .7); g.lineTo(0, -len); g.lineTo(width * .35, -len * .7); g.lineTo(width * .5, len * .12); g.closePath(); g.fill();
    g.lineWidth = width * .45; g.fillStyle = 'rgba(0,0,0,0)'; g.beginPath(); g.arc(0, -len * .72, width * 1.15, 0, TAU); g.stroke();
    g.restore();
  }
  const ROMAN = ['XII', 'I', 'II', 'III', 'IIII', 'V', 'VI', 'VII', 'VIII', 'IX', 'X', 'XI'];

  function skeletonClock(style) {
    let view; const tourbillon = style === 'tourbillon';
    return {
      mount(host) { view = makeCanvas(host, 1, tourbillon ? 'Reloj tourbillon: la jaula del escape gira una vez por minuto' : 'Reloj esqueleto: engranajes, escape y volante a la vista'); },
      render(p, ctx) {
        const g = view.g, S = view.w, c = S / 2, R = S * .47, now = performance.now() / 1000;
        const sec = p.second + p.millis / 1000, minA = (p.minute + sec / 60) / 60 * TAU, hourA = ((p.hour % 12) + p.minute / 60 + sec / 3600) / 12 * TAU;
        // Escape a 3 Hz (6 tics por segundo) con salto suave.
        const ticks = sec * 6, tickEase = Math.floor(ticks) + Math.min(1, (ticks % 1) * 5);
        const balA = ctx.reduced ? 0 : Math.sin(sec * TAU * 3) * 1.6, anchorA = ctx.reduced ? 0 : Math.sign(Math.sin(sec * TAU * 3)) * .12;
        g.clearRect(0, 0, S, S);
        // Caja y fondo visto a través del cristal.
        const bez = g.createLinearGradient(0, 0, S, S); bez.addColorStop(0, '#fff0b0'); bez.addColorStop(.3, '#c8901e'); bez.addColorStop(.6, '#8a5a0c'); bez.addColorStop(1, '#f5d580');
        g.fillStyle = bez; g.beginPath(); g.arc(c, c, R * 1.06, 0, TAU); g.fill();
        const inner = g.createRadialGradient(c, c * .9, R * .1, c, c, R);
        inner.addColorStop(0, tourbillon ? '#1d2532' : '#2a1f10'); inner.addColorStop(1, tourbillon ? '#06090f' : '#0b0703');
        g.fillStyle = inner; g.beginPath(); g.arc(c, c, R, 0, TAU); g.fill();
        g.save(); g.beginPath(); g.arc(c, c, R, 0, TAU); g.clip();
        // Puentes translúcidos.
        g.fillStyle = tourbillon ? 'rgba(160,175,195,.18)' : 'rgba(230,190,110,.16)'; g.strokeStyle = 'rgba(255,230,170,.25)'; g.lineWidth = 1.2;
        for (const [a0, a1, rr, w] of [[-2.6, -.6, .62, .16], [.3, 1.6, .7, .14], [2.1, 3.2, .45, .18]]) {
          g.beginPath(); g.arc(c, c, R * (rr + w / 2), a0, a1); g.arc(c, c, R * (rr - w / 2), a1, a0, true); g.closePath(); g.fill(); g.stroke();
        }
        const G = (x, y) => [c + x * R, c + y * R];
        const gold = goldFill(g, R * .3), steel = steelFill(g, R * .3);
        // Tren de engranajes: ángulos encadenados según el radio para que "engranen".
        const centerR = .27, thirdR = .19, fourthR = .16, escR = .1, barrelR = .3;
        const aCenter = minA, aThird = -aCenter * centerR / thirdR * 2.6, aFourth = sec / 60 * TAU, aEsc = -tickEase / 15 * TAU / 2;
        const barrel = G(-.42, -.28); drawGear(g, ...barrel, R * barrelR, 90, -minA / 8, gold, { spokes: 0, depth: .05 });
        g.save(); g.translate(...barrel); g.strokeStyle = 'rgba(80,50,10,.7)'; g.lineWidth = 1.2; g.beginPath();
        for (let t = 0; t < 1; t += .01) { const rr = R * barrelR * (.15 + .7 * t), a = t * TAU * 6 - minA / 8; t === 0 ? g.moveTo(rr * Math.cos(a), rr * Math.sin(a)) : g.lineTo(rr * Math.cos(a), rr * Math.sin(a)) } g.stroke(); g.restore();
        drawGear(g, ...G(.33, -.3), R * thirdR, 56, aThird, gold, { spokes: 4 });
        drawGear(g, ...G(.42, .1), R * .11, 12, -aThird * 1.7, steel, { spokes: 0, depth: .2 });
        drawGear(g, ...G(0, 0), R * centerR, 80, aCenter, gold, { spokes: 5 });
        const fourth = G(.36, .38), escape = tourbillon ? null : G(.05, .5), bal = tourbillon ? null : G(-.4, .4);
        drawGear(g, ...fourth, R * fourthR, 60, aFourth, gold, { spokes: 4 });
        // Segundero pequeño sobre la cuarta rueda.
        g.strokeStyle = 'rgba(255,255,255,.35)'; g.lineWidth = 1; g.beginPath(); g.arc(...fourth, R * .19, 0, TAU); g.stroke();
        for (let i = 0; i < 12; i++) { const a = i / 12 * TAU, [fx, fy] = fourth; g.beginPath(); g.moveTo(fx + R * .17 * Math.sin(a), fy - R * .17 * Math.cos(a)); g.lineTo(fx + R * .19 * Math.sin(a), fy - R * .19 * Math.cos(a)); g.stroke() }
        if (tourbillon) {
          // Jaula que gira una vez por minuto con escape y volante dentro.
          const [tx, ty] = G(0, .5), cage = sec / 60 * TAU, cr = R * .27;
          g.save(); g.translate(tx, ty); g.rotate(cage);
          g.strokeStyle = steel; g.lineWidth = R * .03; g.beginPath(); g.arc(0, 0, cr, 0, TAU); g.stroke();
          for (let i = 0; i < 3; i++) { const a = i * TAU / 3; g.lineWidth = R * .035; g.beginPath(); g.moveTo(cr * .25 * Math.cos(a), cr * .25 * Math.sin(a)); g.lineTo(cr * Math.cos(a), cr * Math.sin(a)); g.stroke(); screw(g, cr * .95 * Math.cos(a), cr * .95 * Math.sin(a), R * .018, a) }
          g.restore();
          const ex = tx + cr * .55 * Math.cos(cage + 1), ey = ty + cr * .55 * Math.sin(cage + 1);
          drawGear(g, ex, ey, R * .075, 15, aEsc, steel, { spokes: 0, depth: .3 });
          anchor(g, tx + cr * .25 * Math.cos(cage + 1), ty + cr * .25 * Math.sin(cage + 1), R * .06, cage + 1 + anchorA);
          balance(g, tx, ty, R * .16, balA + cage, ctx);
        } else {
          drawGear(g, ...escape, R * escR, 15, aEsc, steel, { spokes: 3, depth: .3 });
          anchor(g, (escape[0] + bal[0]) / 2 + R * .04, escape[1] - R * .02, R * .08, -.6 + anchorA);
          balance(g, ...bal, R * .2, balA, ctx);
        }
        for (const [x, y] of [[-.15, -.55], [.6, -.05], [-.62, .1], [.15, .72], [-.15, .66], [.66, .4]]) screw(g, ...G(x, y), R * .025, x * 3);
        g.restore();
        // Anillo horario translúcido con números romanos y puntos de minutos.
        g.save(); g.translate(c, c);
        g.strokeStyle = 'rgba(255,255,255,.18)'; g.lineWidth = R * .14; g.beginPath(); g.arc(0, 0, R * .87, 0, TAU); g.stroke();
        g.fillStyle = tourbillon ? '#e8eef5' : '#fff7e6'; g.textAlign = 'center'; g.textBaseline = 'middle';
        g.font = `600 ${Math.round(R * .1)}px "Playfair Display", serif`;
        ROMAN.forEach((n, i) => { const a = i / 12 * TAU; g.save(); g.rotate(a); g.translate(0, -R * .87); g.fillText(n, 0, 0); g.restore() });
        for (let i = 0; i < 60; i++) { if (i % 5 === 0) continue; const a = i / 60 * TAU; g.fillStyle = 'rgba(255,240,200,.75)'; g.beginPath(); g.arc(R * .97 * Math.sin(a), -R * .97 * Math.cos(a), R * .008, 0, TAU); g.fill() }
        g.restore();
        // Manecillas Breguet en acero azulado.
        const blue = '#2a4fbf';
        breguetHand(g, c, c, R * .55, hourA, R * .045, blue);
        breguetHand(g, c, c, R * .78, minA, R * .035, blue);
        const [fx, fy] = fourth; g.strokeStyle = blue; g.lineWidth = 1.5; g.beginPath(); g.moveTo(fx, fy); g.lineTo(fx + R * .17 * Math.sin(aFourth), fy - R * .17 * Math.cos(aFourth)); g.stroke();
        jewel(g, c, c, R * .03);
        // Reflejo del cristal.
        const glare = g.createLinearGradient(c - R, c - R, c, c); glare.addColorStop(0, 'rgba(255,255,255,.22)'); glare.addColorStop(1, 'rgba(255,255,255,0)');
        g.fillStyle = glare; g.beginPath(); g.ellipse(c - R * .25, c - R * .3, R * .8, R * .45, -.7, 0, TAU); g.fill();
        if (ctx.reduced) return;
        void now;
      },
      unmount() { view?.ro.disconnect(); view?.c.remove(); }
    };
  }

  /* ── Astronómico 3D: carrusel que gira cada 10 minutos con esfera horaria, globo terráqueo y gemas ── */
  const GEMS = [['#d8ff7a', '#7dbb1c', '#2d4a05'], ['#ffe27a', '#e3a10b', '#6b3d00'], ['#c9a6ff', '#7b3fd1', '#2a0b5c'], ['#9ff0ff', '#1fa6d6', '#08394f']];
  function gemSphere(g, x, y, r, colors, t) {
    const gr = g.createRadialGradient(x - r * .35, y - r * .4, r * .05, x, y, r);
    gr.addColorStop(0, '#fff'); gr.addColorStop(.25, colors[0]); gr.addColorStop(.7, colors[1]); gr.addColorStop(1, colors[2]);
    g.fillStyle = gr; g.beginPath(); g.arc(x, y, r, 0, TAU); g.fill();
    g.save(); g.beginPath(); g.arc(x, y, r, 0, TAU); g.clip();
    g.strokeStyle = 'rgba(255,255,255,.28)'; g.lineWidth = .8;
    for (let i = 0; i < 7; i++) { const a = i / 7 * TAU + t * .3; g.beginPath(); g.moveTo(x + r * .15 * Math.cos(a), y + r * .15 * Math.sin(a)); g.lineTo(x + r * Math.cos(a + .4), y + r * Math.sin(a + .4)); g.lineTo(x + r * Math.cos(a + 1.1), y + r * Math.sin(a + 1.1)); g.stroke() }
    g.restore();
    const s = (Math.sin(t * 2.3 + x) + 1) / 2;
    if (s > .7) { g.fillStyle = `rgba(255,255,255,${(s - .7) * 3})`; const k = r * .5; g.beginPath(); g.moveTo(x - r * .3, y - r * .3 - k); g.lineTo(x - r * .26, y - r * .34); g.lineTo(x - r * .3 + k, y - r * .3); g.lineTo(x - r * .26, y - r * .26); g.lineTo(x - r * .3, y - r * .3 + k); g.lineTo(x - r * .34, y - r * .26); g.lineTo(x - r * .3 - k, y - r * .3); g.lineTo(x - r * .34, y - r * .34); g.closePath(); g.fill() }
  }
  function globe(g, x, y, r, spin) {
    const sea = g.createRadialGradient(x - r * .3, y - r * .35, r * .1, x, y, r); sea.addColorStop(0, '#6fb6ff'); sea.addColorStop(.6, '#1f4fb8'); sea.addColorStop(1, '#0a1c4d');
    g.fillStyle = sea; g.beginPath(); g.arc(x, y, r, 0, TAU); g.fill();
    g.save(); g.beginPath(); g.arc(x, y, r, 0, TAU); g.clip(); g.fillStyle = 'rgba(232,200,120,.9)';
    for (const [lon, lat, w, h] of [[0, -.3, .5, .35], [1.2, .1, .35, .55], [2.4, -.4, .7, .3], [3.6, .35, .3, .3], [4.6, -.1, .45, .5], [5.5, .5, .25, .2]]) {
      const a = lon + spin, cx = Math.sin(a); if (Math.cos(a) < -.1) continue;
      g.beginPath(); g.ellipse(x + cx * r * .85, y + lat * r, w * r * Math.max(.15, Math.cos(a)) * .7, h * r * .6, .3, 0, TAU); g.fill();
    }
    g.restore();
    g.strokeStyle = 'rgba(255,215,140,.8)'; g.lineWidth = r * .08; g.beginPath(); g.ellipse(x, y, r * 1.05, r * .2, -.25, Math.PI * 1.05, Math.PI * 1.95); g.stroke();
  }
  function astronomicalClock() {
    let view;
    return {
      mount(host) { view = makeCanvas(host, 1.2, 'Reloj astronómico 3D: carrusel giratorio con esfera horaria, globo terráqueo y planetas de gemas'); },
      render(p, ctx) {
        const g = view.g, W = view.w, H = view.h, t = performance.now() / 1000, sec = p.second + p.millis / 1000;
        const yaw = ctx.reduced ? 0 : Math.sin(t * .15) * .25;
        const cam = Mini3D.camera({ yaw, pitch: .9, dist: 9, fov: 9, cx: W / 2, cy: H * .46, scale: W * .165 });
        const sc = Mini3D.scene(cam);
        g.clearRect(0, 0, W, H);
        const R = 4.4, ring = (r, y, color, w, fill) => {
          const pts = Mini3D.ring(sc, 0, y, 0, r, color, w, 90);
          return pts;
        };
        // Cuerpo de la caja: costado (grosor) + bisel de oro rosa.
        const top = ring(R, 0), bottom = ring(R, -.7), base = ring(R * .93, -.02);
        g.fillStyle = '#5e2f18'; g.beginPath(); bottom.forEach((q, i) => i ? g.lineTo(q.x, q.y) : g.moveTo(q.x, q.y)); g.fill();
        const side = g.createLinearGradient(0, H * .3, 0, H * .9); side.addColorStop(0, '#f7c6a3'); side.addColorStop(.5, '#b36a43'); side.addColorStop(1, '#5e2f18');
        g.fillStyle = side; g.beginPath(); top.forEach((q, i) => i ? g.lineTo(q.x, q.y) : g.moveTo(q.x, q.y)); for (let i = bottom.length - 1; i >= 0; i--) g.lineTo(bottom[i].x, bottom[i].y); g.fill();
        const bez = g.createLinearGradient(0, 0, W, H); bez.addColorStop(0, '#ffe0c8'); bez.addColorStop(.5, '#c47c52'); bez.addColorStop(1, '#ffd2b0');
        g.fillStyle = bez; g.beginPath(); top.forEach((q, i) => i ? g.lineTo(q.x, q.y) : g.moveTo(q.x, q.y)); g.fill();
        // Platina con baguettes de diamante.
        g.fillStyle = '#0d1220'; g.beginPath(); base.forEach((q, i) => i ? g.lineTo(q.x, q.y) : g.moveTo(q.x, q.y)); g.fill();
        for (let i = 0; i < 48; i++) {
          const a = i / 48 * TAU, q = cam.project([Math.cos(a) * R * .82, 0, Math.sin(a) * R * .82]), s = .9 + .1 * Math.sin(t * 3 + i * 1.7);
          const w = q.f * .32, h = q.f * .16, gr = g.createLinearGradient(q.x - w, q.y - h, q.x + w, q.y + h);
          gr.addColorStop(0, `rgba(255,255,255,${s})`); gr.addColorStop(.5, 'rgba(160,200,255,.55)'); gr.addColorStop(1, `rgba(255,255,255,${s * .8})`);
          g.save(); g.translate(q.x, q.y); g.rotate(Math.atan2(Math.cos(a) * .5, -Math.sin(a))); g.fillStyle = gr; g.fillRect(-w / 2, -h / 2, w, h); g.restore();
        }
        // Signos del zodiaco en un anillo azul (decorativo).
        const zod = ring(R * .62, .02); g.strokeStyle = 'rgba(70,110,200,.5)'; g.lineWidth = 2; g.beginPath(); zod.forEach((q, i) => i ? g.lineTo(q.x, q.y) : g.moveTo(q.x, q.y)); g.stroke();
        // Carrusel: gira una vuelta cada 10 minutos.
        const car = ctx.reduced ? 0 : -((p.minute % 10) * 60 + sec) / 600 * TAU;
        const arm = a => [Math.cos(car + a) * R * .5, .6, Math.sin(car + a) * R * .5];
        const hub = [0, .55, 0];
        const hp = cam.project(hub); g.lineCap = 'round';
        for (const a of [0, Math.PI / 2, Math.PI, Math.PI * 1.5]) { const q = cam.project(arm(a)); g.strokeStyle = '#3a3a44'; g.lineWidth = hp.f * .16; g.beginPath(); g.moveTo(hp.x, hp.y); g.lineTo(q.x, q.y); g.stroke() }
        const hubG = g.createRadialGradient(hp.x - 3, hp.y - 3, 1, hp.x, hp.y, hp.f * .35); hubG.addColorStop(0, '#ffe0c8'); hubG.addColorStop(1, '#8a4a2a');
        g.fillStyle = hubG; g.beginPath(); g.ellipse(hp.x, hp.y, hp.f * .35, hp.f * .22, 0, 0, TAU); g.fill();
        // 1) Esfera horaria (siempre legible).
        const dialPos = arm(0), dp = cam.project([dialPos[0], dialPos[1] + .5, dialPos[2]]);
        sc.custom(dp.z - .3, gg => {
          const r = dp.f * 1.15;
          gg.fillStyle = '#16264f'; gg.strokeStyle = '#e6a57c'; gg.lineWidth = r * .08; gg.beginPath(); gg.arc(dp.x, dp.y, r, 0, TAU); gg.fill(); gg.stroke();
          gg.fillStyle = '#d9a86b'; gg.font = `600 ${Math.round(r * .26)}px "DM Mono",monospace`; gg.textAlign = 'center'; gg.textBaseline = 'middle';
          for (const [n, a] of [[12, 0], [3, Math.PI / 2], [6, Math.PI], [9, Math.PI * 1.5]]) gg.fillText(n, dp.x + r * .72 * Math.sin(a), dp.y - r * .72 * Math.cos(a));
          const hA = ((p.hour % 12) + p.minute / 60) / 12 * TAU, mA = (p.minute + sec / 60) / 60 * TAU;
          gg.strokeStyle = '#f0b78c'; gg.lineCap = 'round';
          gg.lineWidth = r * .1; gg.beginPath(); gg.moveTo(dp.x, dp.y); gg.lineTo(dp.x + r * .5 * Math.sin(hA), dp.y - r * .5 * Math.cos(hA)); gg.stroke();
          gg.lineWidth = r * .06; gg.beginPath(); gg.moveTo(dp.x, dp.y); gg.lineTo(dp.x + r * .78 * Math.sin(mA), dp.y - r * .78 * Math.cos(mA)); gg.stroke();
          gg.fillStyle = '#f0b78c'; gg.beginPath(); gg.arc(dp.x, dp.y, r * .07, 0, TAU); gg.fill();
        });
        // 2) Globo terráqueo que gira.
        const gp = cam.project(arm(Math.PI / 2).map((v, i) => i === 1 ? v + .9 : v));
        sc.custom(gp.z, gg => globe(gg, gp.x, gp.y, gp.f * .75, t * (ctx.reduced ? 0 : .6)));
        // 3) Tourbillon (jaula giratoria).
        const tp = cam.project(arm(Math.PI));
        sc.custom(tp.z, gg => {
          const r = tp.f * .8, a = sec / 60 * TAU * (ctx.reduced ? 0 : 1);
          gg.save(); gg.translate(tp.x, tp.y); gg.scale(1, .55);
          gg.strokeStyle = '#d18a62'; gg.lineWidth = r * .12; gg.beginPath(); gg.arc(0, 0, r, 0, TAU); gg.stroke();
          gg.rotate(a); gg.lineWidth = r * .1; for (let i = 0; i < 3; i++) { const b = i * TAU / 3; gg.beginPath(); gg.moveTo(0, 0); gg.lineTo(r * Math.cos(b), r * Math.sin(b)); gg.stroke() }
          gg.restore();
          gg.fillStyle = '#ff4a7a'; gg.beginPath(); gg.arc(tp.x, tp.y, r * .14, 0, TAU); gg.fill();
        });
        // 4) Gema facetada en el brazo restante.
        const gm = cam.project(arm(Math.PI * 1.5).map((v, i) => i === 1 ? v + .7 : v));
        sc.custom(gm.z, gg => gemSphere(gg, gm.x, gm.y, gm.f * .6, GEMS[2], t));
        // Planetas-gema orbitando a distintas velocidades.
        GEMS.forEach((col, i) => {
          if (i === 2) return;
          const a = (ctx.reduced ? i * 1.7 : t * (.12 + i * .05)) + i * 1.7, r = R * (.68 + (i % 2) * .08);
          const q = cam.project([Math.cos(a) * r, 1.3 + (i % 2) * .4, Math.sin(a) * r]);
          sc.custom(q.z, gg => gemSphere(gg, q.x, q.y, q.f * .42, col, t + i));
        });
        sc.render(g);
        // Leyenda digital legible.
        g.fillStyle = getComputedStyle(document.body).getPropertyValue('--text'); g.textAlign = 'center';
        g.font = `600 ${Math.round(W * .045)}px "DM Mono", monospace`;
        g.fillText(`${hourText(p, ctx)}:${pad(p.minute)}:${pad(p.second)}`, W / 2, H * .965);
      },
      unmount() { view?.ro.disconnect(); view?.c.remove(); }
    };
  }

  FunClocks.register('mechanical', [['esqueleto', 'Esqueleto dorado'], ['tourbillon', 'Tourbillon'], ['astronomico', 'Astronómico 3D']],
    style => style === 'astronomico' ? astronomicalClock() : skeletonClock(style));
})();
