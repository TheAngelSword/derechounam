/* Aura Crono · Mini3D: motor 3D mínimo para canvas 2D (proyección en perspectiva, cajas con sombreado
   plano, esferas con degradado y orden de pintor). Suficiente para relojes "3D" ligeros y sin dependencias. */
'use strict';
const Mini3D = (() => {
  const hexCache = new Map();
  function rgb(hex) {
    let v = hexCache.get(hex);
    if (!v) { const n = parseInt(hex.slice(1), 16); v = [n >> 16 & 255, n >> 8 & 255, n & 255]; hexCache.set(hex, v) }
    return v;
  }
  function shade(hex, k, alpha = 1) {
    const [r, g, b] = rgb(hex), f = c => Math.max(0, Math.min(255, Math.round(c * k)));
    return alpha >= 1 ? `rgb(${f(r)},${f(g)},${f(b)})` : `rgba(${f(r)},${f(g)},${f(b)},${alpha})`;
  }
  // Cámara: gira el mundo (yaw sobre Y, pitch sobre X) y proyecta con perspectiva.
  function camera({ yaw = 0, pitch = .5, dist = 12, fov = 9, cx = 0, cy = 0, scale = 40, target = [0, 0, 0] } = {}) {
    const cyw = Math.cos(yaw), syw = Math.sin(yaw), cp = Math.cos(pitch), sp = Math.sin(pitch);
    function view(p) {
      const x0 = p[0] - target[0], y0 = p[1] - target[1], z0 = p[2] - target[2];
      const x1 = x0 * cyw - z0 * syw, z1 = x0 * syw + z0 * cyw;
      const y2 = y0 * cp + z1 * sp, z2 = -y0 * sp + z1 * cp;
      return [x1, y2, z2];
    }
    function project(p) {
      const [x, y, z] = view(p), f = fov / Math.max(.1, fov + dist + z) * scale;
      return { x: cx + x * f, y: cy - y * f, z, f };
    }
    return { project, view, yaw, pitch };
  }
  const LIGHT = (() => { const l = [-.45, .8, -.4], m = Math.hypot(...l); return l.map(v => v / m) })();
  function rotY([x, y, z], a) { const c = Math.cos(a), s = Math.sin(a); return [x * c - z * s, y, x * s + z * c] }
  function rotX([x, y, z], a) { const c = Math.cos(a), s = Math.sin(a); return [x, y * c - z * s, y * s + z * c] }
  function rotZ([x, y, z], a) { const c = Math.cos(a), s = Math.sin(a); return [x * c - y * s, x * s + y * c, z] }

  // Escena: acumula polígonos/objetos y los dibuja de atrás hacia delante.
  function scene(cam) {
    const items = [];
    return {
      cam, items,
      poly(points3, color, { stroke = null, cull = true, light = true, alpha = 1, glow = 0, lw = 1 } = {}) {
        const pts = points3.map(cam.project);
        if (cull) {
          let area = 0;
          for (let i = 0; i < pts.length; i++) { const a = pts[i], b = pts[(i + 1) % pts.length]; area += a.x * b.y - b.x * a.y }
          if (area <= 0) return;
        }
        let k = 1;
        if (light) {
          const [a, b, c] = points3, u = [b[0] - a[0], b[1] - a[1], b[2] - a[2]], v = [c[0] - a[0], c[1] - a[1], c[2] - a[2]];
          const n = [u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0]], m = Math.hypot(...n) || 1;
          k = .55 + .6 * Math.max(0, (n[0] * LIGHT[0] + n[1] * LIGHT[1] + n[2] * LIGHT[2]) / m);
        }
        const z = pts.reduce((s, p) => s + p.z, 0) / pts.length;
        items.push({ z, draw(g) {
          g.beginPath(); pts.forEach((p, i) => i ? g.lineTo(p.x, p.y) : g.moveTo(p.x, p.y)); g.closePath();
          if (glow) { g.shadowColor = color; g.shadowBlur = glow }
          g.fillStyle = color.startsWith('#') ? shade(color, k, alpha) : color; g.fill();
          if (glow) g.shadowBlur = 0;
          if (stroke) { g.strokeStyle = stroke; g.lineWidth = lw; g.stroke() }
        } });
      },
      // Caja centrada en c, tamaño s=[w,h,d], rotaciones opcionales (yaw y "tilt" sobre X), pivote en c.
      box(c, s, color, { yaw = 0, tilt = 0, roll = 0, pivot = null, stroke = 'rgba(0,0,0,.25)', faceColors = null, glow = 0, map = null, skip = null } = {}) {
        const [w, h, d] = s.map(v => v / 2), pv = pivot || c;
        const corners = [[-w, -h, -d], [w, -h, -d], [w, h, -d], [-w, h, -d], [-w, -h, d], [w, -h, d], [w, h, d], [-w, h, d]].map(p => {
          if (map) return map([p[0] + c[0], p[1] + c[1], p[2] + c[2]]);
          let q = [p[0] + c[0] - pv[0], p[1] + c[1] - pv[1], p[2] + c[2] - pv[2]];
          if (roll) q = rotZ(q, roll); if (tilt) q = rotX(q, tilt); if (yaw) q = rotY(q, yaw);
          return [q[0] + pv[0], q[1] + pv[1], q[2] + pv[2]];
        });
        const F = [[0, 3, 2, 1], [4, 5, 6, 7], [0, 4, 7, 3], [1, 2, 6, 5], [3, 7, 6, 2], [0, 1, 5, 4]];
        F.forEach((f, i) => { if (!skip?.[i]) this.poly(f.map(k => corners[k]), faceColors?.[i] || color, { stroke, glow }) });
      },
      sphere(c, r, colors, { glow = 0, label = null, ring = null } = {}) {
        const p = cam.project(c), rr = r * p.f;
        items.push({ z: p.z, draw(g) {
          if (glow) { g.shadowColor = colors[0]; g.shadowBlur = glow }
          const gr = g.createRadialGradient(p.x - rr * .35, p.y - rr * .35, rr * .1, p.x, p.y, rr);
          gr.addColorStop(0, colors[0]); gr.addColorStop(.55, colors[1] || colors[0]); gr.addColorStop(1, colors[2] || '#000');
          g.fillStyle = gr; g.beginPath(); g.arc(p.x, p.y, Math.max(.5, rr), 0, Math.PI * 2); g.fill(); g.shadowBlur = 0;
          if (ring) { g.strokeStyle = ring; g.lineWidth = Math.max(1, rr * .18); g.beginPath(); g.ellipse(p.x, p.y, rr * 1.8, rr * .5, -.3, 0, Math.PI * 2); g.stroke() }
          if (label) { g.fillStyle = 'rgba(255,255,255,.8)'; g.font = '600 10px "DM Sans",sans-serif'; g.textAlign = 'center'; g.fillText(label, p.x, p.y - rr - 6) }
        } });
        return p;
      },
      custom(z, draw) { items.push({ z, draw }) },
      line(a, b, color, w = 1) {
        const p = cam.project(a), q = cam.project(b);
        items.push({ z: Math.max(p.z, q.z) + .01, draw(g) { g.strokeStyle = color; g.lineWidth = w; g.beginPath(); g.moveTo(p.x, p.y); g.lineTo(q.x, q.y); g.stroke() } });
      },
      render(g) { items.sort((a, b) => b.z - a.z); for (const it of items) it.draw(g); items.length = 0 }
    };
  }
  // Polígono en el plano XZ (y fija): útil para órbitas y pistas.
  function ring(sc, cx, y, cz, r, color, w = 1, steps = 72, tiltX = 0) {
    const pts = [];
    for (let i = 0; i <= steps; i++) { const a = i / steps * Math.PI * 2; let p = [r * Math.cos(a), 0, r * Math.sin(a)]; if (tiltX) p = rotX(p, tiltX); pts.push(sc.cam.project([p[0] + cx, p[1] + y, p[2] + cz])) }
    return pts;
  }
  return { camera, scene, shade, rgb, rotX, rotY, rotZ, ring };
})();
