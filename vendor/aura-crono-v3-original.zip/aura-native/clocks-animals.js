/* Aura Crono · Animales en acción: no tienen forma de reloj, ¡hacen cosas con él!
   Gato persiguiendo al ratón del segundero, hámster que mueve la rueda de los segundos y jardín de bichos. */
'use strict';
(() => {
  const { makeCanvas, pad, hourText, TAU } = FunClocks.util;
  const css = name => getComputedStyle(document.body).getPropertyValue(name);
  const polar = (cx, cy, r, a) => [cx + r * Math.sin(a), cy - r * Math.cos(a)];

  function hands(g, cx, cy, R, p, color = '#203040') {
    const sec = p.second + p.millis / 1000, hA = ((p.hour % 12) + p.minute / 60) / 12 * TAU, mA = (p.minute + sec / 60) / 60 * TAU;
    g.lineCap = 'round'; g.strokeStyle = color;
    g.lineWidth = R * .07; g.beginPath(); g.moveTo(cx, cy); g.lineTo(...polar(cx, cy, R * .48, hA)); g.stroke();
    g.lineWidth = R * .045; g.beginPath(); g.moveTo(cx, cy); g.lineTo(...polar(cx, cy, R * .74, mA)); g.stroke();
    g.fillStyle = color; g.beginPath(); g.arc(cx, cy, R * .06, 0, TAU); g.fill();
  }
  function numbers(g, cx, cy, R, color, font = 'Manrope') {
    g.fillStyle = color; g.textAlign = 'center'; g.textBaseline = 'middle'; g.font = `700 ${Math.round(R * .14)}px ${font}, sans-serif`;
    for (let i = 1; i <= 12; i++) g.fillText(i, ...polar(cx, cy, R * .8, i / 12 * TAU));
  }

  /* ── Sprites (todos miran hacia +x; s = tamaño) ── */
  function cat(g, s, ph, stretch = 1) {
    const leg = (x, y, a, back) => { g.save(); g.translate(x, y); g.rotate(a); g.strokeStyle = back ? '#c8782f' : '#e8954a'; g.lineWidth = s * .13; g.lineCap = 'round'; g.beginPath(); g.moveTo(0, 0); g.lineTo(0, s * .32); g.stroke(); g.restore() };
    const sw = Math.sin(ph) * .9;
    leg(-s * .3, s * .1, sw, true); leg(s * .25, s * .1, -sw, true);
    g.strokeStyle = '#e8954a'; g.lineWidth = s * .11; g.lineCap = 'round';
    g.beginPath(); g.moveTo(-s * .5, -s * .05); g.quadraticCurveTo(-s * .95, -s * (.25 + .2 * Math.sin(ph * .5)), -s * .85, -s * .6); g.stroke();
    g.fillStyle = '#f2a65a'; g.beginPath(); g.ellipse(0, 0, s * .55 * stretch, s * .24, 0, 0, TAU); g.fill();
    g.strokeStyle = '#c46f2a'; g.lineWidth = s * .06; for (const x of [-.25, -.05, .15]) { g.beginPath(); g.moveTo(s * x, -s * .22); g.lineTo(s * (x + .05), -s * .05); g.stroke() }
    leg(-s * .25, s * .12, -sw * .8, false); leg(s * .3, s * .12, sw * .8, false);
    g.fillStyle = '#f2a65a'; g.beginPath(); g.arc(s * .58, -s * .2, s * .24, 0, TAU); g.fill();
    g.beginPath(); g.moveTo(s * .42, -s * .36); g.lineTo(s * .45, -s * .62); g.lineTo(s * .6, -s * .42); g.fill();
    g.beginPath(); g.moveTo(s * .62, -s * .42); g.lineTo(s * .76, -s * .6); g.lineTo(s * .78, -s * .34); g.fill();
    g.fillStyle = '#1b1b1b'; g.beginPath(); g.ellipse(s * .68, -s * .24, s * .045, s * .07, 0, 0, TAU); g.fill();
    g.fillStyle = '#f59eb5'; g.beginPath(); g.arc(s * .81, -s * .15, s * .04, 0, TAU); g.fill();
    g.strokeStyle = '#3b2414'; g.lineWidth = 1; g.beginPath(); g.moveTo(s * .8, -s * .13); g.lineTo(s * 1.0, -s * .17); g.moveTo(s * .8, -s * .11); g.lineTo(s * 1.0, -s * .08); g.stroke();
  }
  function mouse(g, s, ph) {
    const sw = Math.sin(ph) * .8;
    g.strokeStyle = '#f2a0b0'; g.lineWidth = s * .05; g.beginPath(); g.moveTo(-s * .35, 0); g.quadraticCurveTo(-s * .8, -s * .3 * Math.sin(ph * .7), -s * 1.1, -s * .05); g.stroke();
    g.strokeStyle = '#8a8f99'; g.lineWidth = s * .08; g.lineCap = 'round';
    for (const [x, a] of [[-.15, sw], [.15, -sw]]) { g.beginPath(); g.moveTo(s * x, s * .1); g.lineTo(s * x + Math.sin(a) * s * .18, s * .28); g.stroke() }
    g.fillStyle = '#a7adb7'; g.beginPath(); g.ellipse(0, 0, s * .4, s * .2, 0, 0, TAU); g.fill();
    g.beginPath(); g.ellipse(s * .38, -s * .05, s * .2, s * .15, .3, 0, TAU); g.fill();
    g.fillStyle = '#f2b6c2'; g.beginPath(); g.arc(s * .3, -s * .24, s * .13, 0, TAU); g.fill();
    g.fillStyle = '#1b1b1b'; g.beginPath(); g.arc(s * .45, -s * .1, s * .035, 0, TAU); g.fill(); g.beginPath(); g.arc(s * .58, 0, s * .03, 0, TAU); g.fill();
  }
  function hamster(g, s, ph) {
    const sw = Math.sin(ph);
    g.strokeStyle = '#b7743f'; g.lineWidth = s * .1; g.lineCap = 'round';
    for (const [x, a] of [[-.25, sw], [.2, -sw], [-.1, -sw], [.3, sw]]) { g.beginPath(); g.moveTo(s * x, s * .2); g.lineTo(s * x + a * s * .2, s * .42); g.stroke() }
    g.fillStyle = '#d99a5b'; g.beginPath(); g.ellipse(0, 0, s * .5, s * .38, 0, 0, TAU); g.fill();
    g.fillStyle = '#fbe6c8'; g.beginPath(); g.ellipse(s * .12, s * .12, s * .3, s * .22, 0, 0, TAU); g.fill();
    g.fillStyle = '#d99a5b'; g.beginPath(); g.arc(s * .42, -s * .12, s * .26, 0, TAU); g.fill();
    g.fillStyle = '#f2b6c2'; g.beginPath(); g.arc(s * .3, -s * .4, s * .1, 0, TAU); g.fill();
    g.fillStyle = '#fbe6c8'; g.beginPath(); g.arc(s * .55, -s * .02, s * .13, 0, TAU); g.fill();
    g.fillStyle = '#1b1b1b'; g.beginPath(); g.arc(s * .5, -s * .18, s * .05, 0, TAU); g.fill();
    g.fillStyle = '#e88a9c'; g.beginPath(); g.arc(s * .68, -s * .08, s * .04, 0, TAU); g.fill();
  }
  function snail(g, s, ph) {
    const k = 1 + .06 * Math.sin(ph);
    g.fillStyle = '#c9d48a'; g.beginPath(); g.ellipse(0, s * .12, s * .55 * k, s * .12, 0, 0, TAU); g.fill();
    g.beginPath(); g.ellipse(s * .5 * k, -s * .02, s * .1, s * .2, .3, 0, TAU); g.fill();
    g.strokeStyle = '#a7b366'; g.lineWidth = s * .04; for (const d of [-.08, .08]) { g.beginPath(); g.moveTo(s * .52 * k, -s * .15); g.lineTo(s * (.6 + d), -s * .38); g.stroke() }
    g.fillStyle = '#1b1b1b'; g.beginPath(); g.arc(s * .54, -s * .4, s * .035, 0, TAU); g.arc(s * .7, -s * .38, s * .035, 0, TAU); g.fill();
    const shell = g.createRadialGradient(-s * .1, -s * .2, s * .05, 0, -s * .1, s * .35); shell.addColorStop(0, '#f6c27a'); shell.addColorStop(1, '#a5592c');
    g.fillStyle = shell; g.beginPath(); g.arc(0, -s * .12, s * .32, 0, TAU); g.fill();
    g.strokeStyle = '#7a3c18'; g.lineWidth = s * .04; g.beginPath();
    for (let t = 0; t < 1; t += .02) { const r = s * .3 * (1 - t), a = t * TAU * 2.4; const x = r * Math.cos(a), y = -s * .12 + r * Math.sin(a); t === 0 ? g.moveTo(x, y) : g.lineTo(x, y) } g.stroke();
  }
  function ladybug(g, s, ph) {
    g.strokeStyle = '#111'; g.lineWidth = s * .05;
    for (let i = 0; i < 3; i++) { const x = (-.2 + i * .2) * s, a = Math.sin(ph + i * 2) * .5; for (const side of [-1, 1]) { g.beginPath(); g.moveTo(x, 0); g.lineTo(x + Math.sin(a) * s * .15, side * s * .38); g.stroke() } }
    g.fillStyle = '#111'; g.beginPath(); g.arc(s * .32, 0, s * .16, 0, TAU); g.fill();
    g.fillStyle = '#e1262f'; g.beginPath(); g.ellipse(0, 0, s * .34, s * .3, 0, 0, TAU); g.fill();
    g.strokeStyle = '#111'; g.beginPath(); g.moveTo(-s * .34, 0); g.lineTo(s * .32, 0); g.stroke();
    g.fillStyle = '#111'; for (const [x, y] of [[-.15, -.15], [.1, -.13], [-.12, .14], [.12, .15], [-.25, 0]]) { g.beginPath(); g.arc(s * x, s * y, s * .055, 0, TAU); g.fill() }
  }
  function bee(g, s, ph) {
    g.fillStyle = 'rgba(220,240,255,.75)';
    const flap = Math.sin(ph * 6) * .6;
    for (const side of [-1, 1]) { g.save(); g.rotate(side * (.6 + flap)); g.beginPath(); g.ellipse(0, -side * s * .28, s * .14, s * .26, 0, 0, TAU); g.fill(); g.restore() }
    g.fillStyle = '#f6c21c'; g.beginPath(); g.ellipse(0, 0, s * .36, s * .22, 0, 0, TAU); g.fill();
    g.fillStyle = '#1b1b1b'; for (const x of [-.12, .05]) g.fillRect(s * x, -s * .21, s * .07, s * .42);
    g.beginPath(); g.moveTo(-s * .36, 0); g.lineTo(-s * .5, 0); g.lineWidth = s * .05; g.strokeStyle = '#1b1b1b'; g.stroke();
    g.beginPath(); g.arc(s * .35, 0, s * .13, 0, TAU); g.fill();
  }
  function onTrack(g, cx, cy, r, a, draw, lift = 0) {
    const [x, y] = polar(cx, cy, r + lift, a);
    g.save(); g.translate(x, y); g.rotate(a); draw(); g.restore();
  }

  /* ── 1. Gato persiguiendo al ratón del segundero: corren sobre el planeta-reloj ── */
  function catChase() {
    let view, dust = [];
    return {
      mount(host) { view = makeCanvas(host, 1, 'Un gato persigue al ratón que marca los segundos alrededor del reloj'); },
      render(p, ctx) {
        const g = view.g, S = view.w, c = S / 2, R = S * .32, t = performance.now() / 1000, sec = p.second + p.millis / 1000;
        g.clearRect(0, 0, S, S);
        const planet = g.createRadialGradient(c - R * .3, c - R * .3, R * .1, c, c, R);
        planet.addColorStop(0, '#fffaf0'); planet.addColorStop(1, '#e9dcc2');
        g.shadowColor = 'rgba(0,0,0,.35)'; g.shadowBlur = 30; g.fillStyle = planet; g.beginPath(); g.arc(c, c, R, 0, TAU); g.fill(); g.shadowBlur = 0;
        g.strokeStyle = '#6aa84f'; g.lineWidth = R * .06; g.beginPath(); g.arc(c, c, R * 1.01, 0, TAU); g.stroke();
        for (let i = 0; i < 90; i++) { const a = i / 90 * TAU, [x, y] = polar(c, c, R * 1.04, a); g.strokeStyle = '#7fbf5a'; g.lineWidth = 1.4; g.beginPath(); g.moveTo(x, y); g.lineTo(...polar(c, c, R * 1.08 + Math.sin(i * 7) * 2, a + .01)); g.stroke() }
        for (let i = 0; i < 60; i++) { const a = i / 60 * TAU; g.strokeStyle = 'rgba(60,40,20,.35)'; g.lineWidth = i % 5 ? 1 : 2.5; g.beginPath(); g.moveTo(...polar(c, c, R * .9, a)); g.lineTo(...polar(c, c, R * (i % 5 ? .94 : .96), a)); g.stroke() }
        numbers(g, c, c, R, '#5a3b22');
        hands(g, c, c, R, p, '#3b2414');
        const aMouse = sec / 60 * TAU, ph = ctx.reduced ? 0 : t * 18;
        // El gato va detrás; al empezar cada minuto da un salto (¡casi lo atrapa!).
        const gap = .42 + .12 * Math.sin(t * .8), aCat = aMouse - gap, jumpT = sec < 1.1 ? Math.sin(sec / 1.1 * Math.PI) : 0;
        g.strokeStyle = 'rgba(229,72,77,.6)'; g.lineWidth = 1.5; g.setLineDash([3, 4]); g.beginPath(); g.moveTo(c, c); g.lineTo(...polar(c, c, R * 1.08, aMouse)); g.stroke(); g.setLineDash([]);
        onTrack(g, c, c, R * 1.08, aMouse, () => mouse(g, S * .07, ph * 1.4), S * .02 + (jumpT ? S * .03 * jumpT : 0));
        onTrack(g, c, c, R * 1.08, aCat, () => cat(g, S * .1, ph, 1 + .1 * Math.sin(ph)), S * .03 + jumpT * S * .1);
        if (!ctx.reduced && Math.random() < .5) { const [x, y] = polar(c, c, R * 1.1, aCat - .12); dust.push({ x, y, life: 1, vx: (Math.random() - .5) * 1.5, vy: (Math.random() - .5) * 1.5 }) }
        dust = dust.filter(d => (d.life -= .03) > 0);
        for (const d of dust) { d.x += d.vx; d.y += d.vy; g.fillStyle = `rgba(200,180,150,${d.life * .5})`; g.beginPath(); g.arc(d.x, d.y, 3 * (1.5 - d.life), 0, TAU); g.fill() }
        if (jumpT > .2) {
          const [bx, by] = polar(c, c, R * 1.5, aCat);
          g.fillStyle = '#fff'; g.strokeStyle = '#3b2414'; g.lineWidth = 1.5; g.beginPath(); g.roundRect(bx - 34, by - 15, 68, 26, 10); g.fill(); g.stroke();
          g.fillStyle = '#3b2414'; g.font = '700 13px Manrope, sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('¡MIAU!', bx, by - 2);
        }
        g.fillStyle = css('--text'); g.textAlign = 'center'; g.font = `600 ${Math.round(S * .04)}px "DM Mono", monospace`;
        g.fillText(`${hourText(p, ctx)}:${pad(p.minute)}:${pad(p.second)}`, c, S * .97);
      },
      unmount() { view?.ro.disconnect(); view?.c.remove(); }
    };
  }

  /* ── 2. Hámster que hace girar la rueda de los segundos ── */
  function hamsterWheel() {
    let view;
    return {
      mount(host) { view = makeCanvas(host, 1, 'Un hámster corre en la rueda: el número marcado arriba son los segundos'); },
      render(p, ctx) {
        const g = view.g, S = view.w, c = S / 2, cy = S * .46, R = S * .38, t = performance.now() / 1000, sec = p.second + p.millis / 1000;
        g.clearRect(0, 0, S, S);
        g.strokeStyle = '#8a95a3'; g.lineWidth = S * .025; g.lineCap = 'round';
        g.beginPath(); g.moveTo(c, cy); g.lineTo(c - R * .7, S * .97); g.moveTo(c, cy); g.lineTo(c + R * .7, S * .97); g.stroke();
        // La rueda gira: el número que queda bajo el indicador superior son los segundos.
        const rot = -sec / 60 * TAU;
        g.save(); g.translate(c, cy); g.rotate(rot);
        g.strokeStyle = '#c7d0da'; g.lineWidth = S * .018; g.beginPath(); g.arc(0, 0, R, 0, TAU); g.stroke(); g.beginPath(); g.arc(0, 0, R * .9, 0, TAU); g.stroke();
        g.lineWidth = 2; g.strokeStyle = '#aab4bf';
        for (let i = 0; i < 60; i++) { const a = i / 60 * TAU; g.beginPath(); g.moveTo(R * .9 * Math.sin(a), -R * .9 * Math.cos(a)); g.lineTo(R * Math.sin(a), -R * Math.cos(a)); g.stroke() }
        g.fillStyle = '#ffd166'; g.font = `700 ${Math.round(S * .028)}px "DM Mono", monospace`; g.textAlign = 'center'; g.textBaseline = 'middle';
        for (let i = 0; i < 60; i += 5) { const a = i / 60 * TAU; g.save(); g.rotate(a); g.fillText(pad(i), 0, -R * 1.06); g.restore() }
        g.strokeStyle = 'rgba(200,210,220,.35)'; g.lineWidth = 2; for (let i = 0; i < 6; i++) { const a = i / 6 * TAU; g.beginPath(); g.moveTo(0, 0); g.lineTo(R * .9 * Math.sin(a), -R * .9 * Math.cos(a)); g.stroke() }
        g.restore();
        // Indicador fijo arriba.
        g.fillStyle = '#e5484d'; g.beginPath(); g.moveTo(c - 9, cy - R * 1.17); g.lineTo(c + 9, cy - R * 1.17); g.lineTo(c, cy - R * 1.1); g.fill();
        // Esfera central fija con horas y minutos.
        const r2 = R * .5; g.fillStyle = '#fffaf0'; g.shadowColor = 'rgba(0,0,0,.3)'; g.shadowBlur = 12; g.beginPath(); g.arc(c, cy, r2, 0, TAU); g.fill(); g.shadowBlur = 0;
        numbers(g, c, cy, r2, '#40506a'); hands(g, c, cy, r2, p, '#2a3550');
        // Hámster corriendo abajo, dentro de la rueda.
        const ph = ctx.reduced ? 0 : t * 22, bob = ctx.reduced ? 0 : Math.abs(Math.sin(ph)) * S * .008;
        g.save(); g.translate(c - R * .05, cy + R * .9 - S * .13 * .47 - bob); g.rotate(-.12); hamster(g, S * .13, ph); g.restore();
        // Plato de semillas.
        g.fillStyle = '#5e88b0'; g.beginPath(); g.ellipse(c + R * .95, S * .95, S * .07, S * .02, 0, 0, TAU); g.fill();
        g.fillStyle = '#e3c27a'; for (let i = 0; i < 7; i++) { g.beginPath(); g.ellipse(c + R * .95 + (i - 3) * 6, S * .938 - (i % 2) * 3, 3, 1.6, i, 0, TAU); g.fill() }
        g.fillStyle = css('--text'); g.textAlign = 'center'; g.font = `600 ${Math.round(S * .04)}px "DM Mono", monospace`;
        g.fillText(`${pad(p.second)} s`, c, S * .045);
      },
      unmount() { view?.ro.disconnect(); view?.c.remove(); }
    };
  }

  /* ── 3. Jardín: caracol = horas, catarina = minutos, abeja = segundos ── */
  function garden() {
    let view;
    return {
      mount(host) { view = makeCanvas(host, 1, 'Jardín: el caracol marca la hora, la catarina los minutos y la abeja los segundos'); },
      render(p, ctx) {
        const g = view.g, S = view.w, c = S / 2, R = S * .45, t = performance.now() / 1000, sec = p.second + p.millis / 1000;
        g.clearRect(0, 0, S, S);
        const grass = g.createRadialGradient(c, c, R * .2, c, c, R); grass.addColorStop(0, '#8fd16a'); grass.addColorStop(1, '#4f9a3c');
        g.fillStyle = grass; g.beginPath(); g.arc(c, c, R, 0, TAU); g.fill();
        g.strokeStyle = '#3f7d2f'; g.lineWidth = R * .03; g.stroke();
        for (let i = 0; i < 140; i++) { const a = i * 2.39996, r = R * Math.sqrt(i / 140) * .95; const [x, y] = polar(c, c, r, a); g.strokeStyle = 'rgba(40,100,30,.35)'; g.lineWidth = 1.2; g.beginPath(); g.moveTo(x, y); g.lineTo(x + 2, y - 6); g.stroke() }
        // Pistas de cada bicho.
        for (const [r, col] of [[.42, 'rgba(255,255,255,.25)'], [.66, 'rgba(255,255,255,.22)'], [.88, 'rgba(255,255,255,.18)']]) { g.setLineDash([2, 6]); g.strokeStyle = col; g.lineWidth = 2; g.beginPath(); g.arc(c, c, R * r, 0, TAU); g.stroke() }
        g.setLineDash([]);
        // Flores en las horas.
        const petals = ['#ff8fb1', '#ffd166', '#c9a6ff', '#ff9f5a'];
        for (let i = 1; i <= 12; i++) {
          const [x, y] = polar(c, c, R * .77, i / 12 * TAU), sway = ctx.reduced ? 0 : Math.sin(t * 1.5 + i) * .15, f = R * .055;
          g.save(); g.translate(x, y); g.rotate(sway); g.fillStyle = petals[i % 4];
          for (let k = 0; k < 5; k++) { const a = k / 5 * TAU; g.beginPath(); g.ellipse(Math.cos(a) * f, Math.sin(a) * f, f * .8, f * .5, a, 0, TAU); g.fill() }
          g.fillStyle = '#fff3c4'; g.beginPath(); g.arc(0, 0, f * .7, 0, TAU); g.fill();
          g.fillStyle = '#3b2a14'; g.font = `800 ${Math.round(f * 1.1)}px Manrope`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(i, 0, 1);
          g.restore();
        }
        const hA = ((p.hour % 12) + p.minute / 60 + sec / 3600) / 12 * TAU, mA = (p.minute + sec / 60) / 60 * TAU, sA = sec / 60 * TAU;
        // Rastro brillante del caracol desde las 12.
        g.strokeStyle = 'rgba(230,250,255,.55)'; g.lineWidth = R * .035; g.lineCap = 'round'; g.beginPath(); g.arc(c, c, R * .42, -Math.PI / 2, hA - Math.PI / 2 - .08); g.stroke();
        const ph = ctx.reduced ? 0 : t;
        onTrack(g, c, c, R * .42, hA, () => snail(g, R * .2, ph * 2));
        onTrack(g, c, c, R * .66, mA, () => ladybug(g, R * .14, ph * 12));
        const buzz = ctx.reduced ? 0 : Math.sin(t * 9) * R * .03;
        onTrack(g, c, c, R * .88, sA, () => bee(g, R * .14, ph * 4), buzz);
        g.fillStyle = 'rgba(255,255,255,.85)'; g.beginPath(); g.arc(c, c, R * .2, 0, TAU); g.fill();
        g.fillStyle = '#2e5e22'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.font = `800 ${Math.round(R * .12)}px Manrope, sans-serif`;
        g.fillText(`${hourText(p, ctx)}:${pad(p.minute)}`, c, c - R * .02);
        g.font = `600 ${Math.round(R * .06)}px "DM Mono", monospace`; g.fillText(`${pad(p.second)}s`, c, c + R * .1);
      },
      unmount() { view?.ro.disconnect(); view?.c.remove(); }
    };
  }

  FunClocks.register('animals', [['gato', 'Gato vs. ratón'], ['hamster', 'Hámster en la rueda'], ['jardin', 'Jardín de bichos']],
    style => style === 'hamster' ? hamsterWheel() : style === 'jardin' ? garden() : catChase());
})();
