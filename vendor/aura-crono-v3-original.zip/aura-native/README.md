# Aura Crono v3 — reloj web adaptable

Una página web en español, sin instalación de paquetes ni credenciales, con:

- Hora exacta del dispositivo convertida a la zona horaria elegida o detectada; fecha, día del año, días restantes y UTC.
- Reloj analógico (Atelier, Aviador, Zen, Estelar), digital (Cristal, LED, Flip, Editorial) y experimental (Órbita temporal).
- **Nuevo v3 · Mecánicos:** Esqueleto dorado (tren de engranajes que engrana de verdad, escape a 3 Hz, volante con espiral, rubíes y tornillos azulados), Tourbillon (jaula que gira una vez por minuto) y Astronómico 3D (carrusel que da una vuelta cada 10 minutos con esfera horaria, globo terráqueo, tourbillon y planetas de gemas).
- **Nuevo v3 · 3D y arcade:** Sistema solar 3D (los planetas son las manecillas), Lluvia de código (la hora brilla dentro de la lluvia), Mundo de bloques (dígitos de cubos que caen y personajes que caminan, saltan y saludan), Pasillo retro FPS (raycaster con la hora en los muros y un panel tipo arcade) y Pista de baile (la hora en las losetas y personajes que bailan al ritmo de la radio).
- **Nuevo v3 · Animales en acción:** un gato persigue al ratón que lleva el segundero, un hámster mueve la rueda de los segundos y un jardín donde el caracol marca la hora, la catarina los minutos y la abeja los segundos.
- **Nuevo · Tetris:** las piezas caen y arman la hora; al cambiar un dígito la "línea" parpadea y se rellena. Estilos Clásico, Turbo (con segundos) y Retro verde.
- **Nuevo · Creativos:** reloj de Palabras en español ("son las ocho y diez"), Reloj de arena que se voltea cada minuto y Paisaje con el Sol y la Luna en su posición real del cielo.
- **Nuevo · La Luna y el sistema solar:** fase lunar actual (iluminación, edad, distancia), próximas fases, calendario de 8 días, minimapa del sistema solar interior (Mercurio, Venus, Tierra + Luna, Marte) con estaciones, zoom Tierra–Luna, distancia y velocidad orbital, estación y próximo equinoccio/solsticio. Todo se calcula localmente (sin API) con precisión de minutos de arco; la Luna se invierte para el hemisferio sur.
- **Fondos:** 13 temas animados, incluidos 4 nuevos en canvas: **Visualizador musical** (reacciona a la radio), Hiperespacio, Lluvia de código y Luces bokeh. Además 9 temas CSS (Aurora, Galaxia, Océano, Atardecer, Bosque, Sakura, Synthwave, Desierto, Minimal), imagen propia, imagen por URL o degradado de dos colores, con controles para oscurecer y desenfocar.
- Botón de pantalla completa para el reloj.
- **Animaciones / Modo normal:** un botón en Preferencias activa o desactiva todas las animaciones (fondos, relojes 3D, minimapa). Respeta también la opción del sistema "reducir movimiento".
- **Minimapa solar en 4 modos:** Clásico (posición real de hoy), Órbitas 3D (cámara rápida con estelas), Vórtice (el Sol viaja y los planetas trazan espirales, como en los videos virales) y Desde la Tierra (bucles retrógrados). Incluye pausa, velocidad y botón "Hoy".
- **Audio reactivo:** cuando la emisora permite CORS se analiza el espectro real; si no, la música suena igual y las animaciones siguen un ritmo estimado.
- Formato de 12/24 horas y tema claro/oscuro/automático.
- Clima real y pronóstico de cinco días (Open-Meteo) con fondo reactivo a despejado, nubes, lluvia, tormenta, nieve y niebla.
- Ubicación GPS con permiso del usuario, o búsqueda manual de cualquier ciudad. Si se deniega, muestra **Ciudad de México (predeterminada)**; no afirma estar en esa ciudad.
- Celebraciones seleccionadas de calendario y efemérides diarias enlazadas a Wikipedia.
- Marquesina de **7** efemérides históricas de la fecha (Wikipedia; necesita conexión a internet).
- 44 emisoras agrupadas por género (Radio Paradise, SomaFM, FIP, KEXP, Radio Swiss…), botones anterior/siguiente, URL de respaldo automática y opción de **agregar tus propias emisoras** (stream MP3/AAC).
- Diseño responsive para teléfono, tableta y escritorio; controles accesibles y opción de reducir movimiento.

## Cómo probar

1. Extrae el ZIP.
2. Dentro de la carpeta, abre una terminal y ejecuta `python -m http.server 8000` (también `py -m http.server 8000` en Windows).
3. Abre **http://localhost:8000** en Chrome, Edge o Firefox.
4. Permite el acceso a ubicación, o selecciona una ciudad usando el botón de la esquina superior derecha.
5. Para publicar, sube el contenido de la carpeta directamente a Vercel, Netlify o cualquier hosting estático con HTTPS.

**Importante:** El GPS de los navegadores requiere una página HTTPS o `localhost` y consentimiento de la persona. Abrir `index.html` con `file://` puede impedir permisos, geolocalización o solicitudes de internet: utiliza el servidor local indicado. Radio, clima, festividades y efemérides necesitan conexión a internet. Algunos streams pueden dejar de estar disponibles por causas externas o restricciones regionales. La hora se deriva del reloj del dispositivo; no se sincroniza mediante un servidor horario NTP. El texto de la interfaz «Sincronizado con tu dispositivo» se refiere a ese reloj local. Las zonas horarias usan Intl del navegador y la zona geográfica provista por Open-Meteo. Para un uso público o comercial de las emisoras, confirma los permisos de retransmisión del proveedor.

## Archivos

- `index.html`: estructura de la página.
- `styles.css`: diseño, temas y responsividad.
- `app.js`: lógica principal: bucle de render, clima, calendario, historia, localización, fondos, astronomía y audio.
- `fun-clocks.js`: núcleo de relojes divertidos + Tetris y Creativos.
- `clocks-mechanical.js`, `clocks-animals.js`, `clocks-3d.js`: los nuevos relojes.
- `mini3d.js`: motor 3D mínimo para canvas (sin dependencias).
- `audio-fx.js`: reproducción de la radio y niveles de audio para animaciones.
- `solar-anim.js`: minimapa solar animado.
- `bg-fx.js`: fondos animados en canvas.
- `astro.js`: cálculos astronómicos (Sol, Luna, planetas, fases, estaciones).
- `favicon.svg`: icono del sitio.

## Servicios externos (sin contraseña)

- https://open-meteo.com/ — clima y geocodificación.
- https://www.openstreetmap.org/ y https://nominatim.openstreetmap.org/ — nombre del lugar a partir de coordenadas.
- https://www.wikipedia.org/ — acontecimientos históricos del día (API REST de Wikipedia en español).
- https://date.nager.at — días festivos públicos por país (si están disponibles).
- https://radioparadise.com/, https://somafm.com/, https://www.radiofrance.fr/fip, https://www.kexp.org/ y https://www.radioswiss.ch/ — estaciones de radio.

La ubicación GPS solo se usa en el navegador para consultar el clima y nombrar la zona; el código no conserva las coordenadas GPS en preferencias. Si se selecciona una ciudad manualmente, esta se guarda localmente para futuras visitas.

## Optimizaciones de la v2

- El reloj ya no usa un `setInterval` de 140 ms: usa `requestAnimationFrame` solo cuando el reloj visible necesita animación fluida, y un temporizador alineado al segundo para los relojes digitales/palabras. Con la pestaña oculta no se dibuja nada.
- El desfase de zona horaria se calcula con `Intl` cada 30 s y se cachea (antes se creaba un formateador en cada fotograma). Los elementos del DOM se cachean y los textos solo se reescriben cuando cambia el segundo.
- Solo se dibuja el reloj visible; los lienzos se ajustan a la densidad de píxeles y se redimensionan con `ResizeObserver`.
- Se corrigió la URL de la API de festivos (date.nager.at) y se cachea por país/año.
- Las preferencias se guardan con *debounce*, y los modales devuelven el foco al cerrarse.
