/* Aura Crono · Astro: posiciones aproximadas del Sol, la Luna y los planetas interiores.
   Basado en las fórmulas simplificadas de Paul Schlyter (precisión de ~1–2 arcmin para la Luna),
   más que suficiente para fases, mapas y estaciones. Sin dependencias ni llamadas de red. */
'use strict';
const Astro = (() => {
  const RAD = Math.PI / 180, DEG = 180 / Math.PI;
  const norm = a => ((a % 360) + 360) % 360;
  const S = x => Math.sin(x * RAD), C = x => Math.cos(x * RAD);
  const SYNODIC = 29.530588853;
  const julian = date => date.getTime() / 86400000 + 2440587.5;
  const dayNumber = date => julian(date) - 2451543.5; // días desde 2000-01-00 0h

  function kepler(M, e) {
    let E = M + e * DEG * S(M) * (1 + e * C(M));
    for (let i = 0; i < 8; i++) {
      const dE = (E - e * DEG * S(E) - M) / (1 - e * C(E));
      E -= dE;
      if (Math.abs(dE) < 1e-7) break;
    }
    return E;
  }

  function sun(date) {
    const d = dayNumber(date);
    const w = 282.9404 + 4.70935e-5 * d, e = 0.016709 - 1.151e-9 * d, M = norm(356.0470 + 0.9856002585 * d);
    const E = kepler(M, e), xv = C(E) - e, yv = Math.sqrt(1 - e * e) * S(E);
    return { lon: norm(Math.atan2(yv, xv) * DEG + w), r: Math.hypot(xv, yv), M, w, d };
  }

  function moon(date) {
    const d = dayNumber(date);
    const N = norm(125.1228 - 0.0529538083 * d), i = 5.1454, w = norm(318.0634 + 0.1643573223 * d);
    const a = 60.2666, e = 0.054900, M = norm(115.3654 + 13.0649929509 * d);
    const E = kepler(M, e), xv = a * (C(E) - e), yv = a * Math.sqrt(1 - e * e) * S(E);
    const v = Math.atan2(yv, xv) * DEG, r = Math.hypot(xv, yv);
    const xh = r * (C(N) * C(v + w) - S(N) * S(v + w) * C(i));
    const yh = r * (S(N) * C(v + w) + C(N) * S(v + w) * C(i));
    const zh = r * S(v + w) * S(i);
    let lon = Math.atan2(yh, xh) * DEG, lat = Math.atan2(zh, Math.hypot(xh, yh)) * DEG;
    const s = sun(date), Ms = s.M, Ls = norm(s.M + s.w), Lm = norm(N + w + M), D = norm(Lm - Ls), F = norm(Lm - N);
    lon += -1.274 * S(M - 2 * D) + 0.658 * S(2 * D) - 0.186 * S(Ms) - 0.059 * S(2 * M - 2 * D) - 0.057 * S(M - 2 * D + Ms)
      + 0.053 * S(M + 2 * D) + 0.046 * S(2 * D - Ms) + 0.041 * S(M - Ms) - 0.035 * S(D) - 0.031 * S(M + Ms)
      - 0.015 * S(2 * F - 2 * D) + 0.011 * S(M - 4 * D);
    lat += -0.173 * S(F - 2 * D) - 0.055 * S(M - F - 2 * D) - 0.046 * S(M + F - 2 * D) + 0.033 * S(F + 2 * D) + 0.017 * S(2 * M + F);
    const distER = r - 0.58 * C(M - 2 * D) - 0.46 * C(2 * D);
    return { lon: norm(lon), lat, distKm: distER * 6378.14 };
  }

  const PLANETS = {
    mercury: d => ({ N: 48.3313 + 3.24587e-5 * d, i: 7.0047 + 5.00e-8 * d, w: 29.1241 + 1.01444e-5 * d, a: 0.387098, e: 0.205635 + 5.59e-10 * d, M: 168.6562 + 4.0923344368 * d }),
    venus: d => ({ N: 76.6799 + 2.46590e-5 * d, i: 3.3946 + 2.75e-8 * d, w: 54.8910 + 1.38374e-5 * d, a: 0.723330, e: 0.006773 - 1.302e-9 * d, M: 48.0052 + 1.6021302244 * d }),
    mars: d => ({ N: 49.5574 + 2.11081e-5 * d, i: 1.8497 - 1.78e-8 * d, w: 286.5016 + 2.92961e-5 * d, a: 1.523688, e: 0.093405 + 2.516e-9 * d, M: 18.6021 + 0.5240207766 * d }),
    jupiter: d => ({ N: 100.4542 + 2.76854e-5 * d, i: 1.3030 - 1.557e-7 * d, w: 273.8777 + 1.64505e-5 * d, a: 5.20256, e: 0.048498 + 4.469e-9 * d, M: 19.8950 + 0.0830853001 * d }),
    saturn: d => ({ N: 113.6634 + 2.38980e-5 * d, i: 2.4886 - 1.081e-7 * d, w: 339.3939 + 2.97661e-5 * d, a: 9.55475, e: 0.055546 - 9.499e-9 * d, M: 316.9670 + 0.0334442282 * d })
  };
  function planet(name, date) {
    if (name === 'earth') { const s = sun(date); const lon = norm(s.lon + 180); return { lon, r: s.r, x: s.r * C(lon), y: s.r * S(lon), a: 1 }; }
    const el = PLANETS[name](dayNumber(date)), M = norm(el.M), E = kepler(M, el.e);
    const xv = el.a * (C(E) - el.e), yv = el.a * Math.sqrt(1 - el.e * el.e) * S(E);
    const v = Math.atan2(yv, xv) * DEG, r = Math.hypot(xv, yv);
    const x = r * (C(el.N) * C(v + el.w) - S(el.N) * S(v + el.w) * C(el.i));
    const y = r * (S(el.N) * C(v + el.w) + C(el.N) * S(v + el.w) * C(el.i));
    return { lon: norm(Math.atan2(y, x) * DEG), r, x, y, a: el.a };
  }

  const PHASES = [
    [12, 'Luna nueva', '🌑'], [80, 'Luna creciente', '🌒'], [100, 'Cuarto creciente', '🌓'], [168, 'Gibosa creciente', '🌔'],
    [192, 'Luna llena', '🌕'], [260, 'Gibosa menguante', '🌖'], [280, 'Cuarto menguante', '🌗'], [348, 'Luna menguante', '🌘'], [360, 'Luna nueva', '🌑']
  ];
  function elongation(date) { return norm(moon(date).lon - sun(date).lon); }
  function phase(date) {
    const s = sun(date), m = moon(date), el = norm(m.lon - s.lon);
    const [, name, emoji] = PHASES.find(([lim]) => el < lim);
    return { elongation: el, illumination: (1 - C(el)) / 2, waxing: el < 180, age: el / 360 * SYNODIC, name, emoji, moon: m, sun: s };
  }

  // Encuentra el próximo instante en que fn(date) (ángulo creciente) cruza target.
  function nextCrossing(fn, target, from, stepHours, maxDays) {
    const diff = t => norm(fn(new Date(t)) - target + 180) - 180;
    let t0 = from.getTime() + 60000, f0 = diff(t0);
    const step = stepHours * 3600000, end = t0 + maxDays * 86400000;
    for (let t = t0 + step; t <= end; t += step) {
      const f1 = diff(t);
      if (f0 < 0 && f1 >= 0 && f1 - f0 < 180) {
        let lo = t - step, hi = t;
        for (let k = 0; k < 30; k++) { const mid = (lo + hi) / 2; if (diff(mid) < 0) lo = mid; else hi = mid; }
        return new Date((lo + hi) / 2);
      }
      f0 = f1;
    }
    return null;
  }
  const nextPhase = (date, target) => nextCrossing(elongation, target, date, 6, 32);
  const sunLon = date => sun(date).lon;
  function upcomingPhases(date) {
    return [[0, 'Luna nueva', '🌑'], [90, 'Cuarto creciente', '🌓'], [180, 'Luna llena', '🌕'], [270, 'Cuarto menguante', '🌗']]
      .map(([t, name, emoji]) => ({ name, emoji, date: nextPhase(date, t) }))
      .filter(x => x.date).sort((a, b) => a.date - b.date);
  }
  function nextSeason(date, latitude = 0) {
    const north = latitude >= 0;
    const names = north ? { 0: 'Equinoccio de primavera', 90: 'Solsticio de verano', 180: 'Equinoccio de otoño', 270: 'Solsticio de invierno' }
      : { 0: 'Equinoccio de otoño', 90: 'Solsticio de invierno', 180: 'Equinoccio de primavera', 270: 'Solsticio de verano' };
    const L = sunLon(date), target = (Math.floor(L / 90) * 90 + 90) % 360;
    return { name: names[target], target, date: nextCrossing(sunLon, target, date, 24, 100) };
  }
  function currentSeason(date, latitude = 0) {
    const L = sunLon(date), q = Math.floor(L / 90);
    const north = ['Primavera', 'Verano', 'Otoño', 'Invierno'], south = ['Otoño', 'Invierno', 'Primavera', 'Verano'];
    return (latitude >= 0 ? north : south)[q];
  }
  function apsides(date) {
    const s = sun(date), rate = 0.9856002585;
    const toPeri = (360 - s.M) / rate, toAph = norm(180 - s.M) / rate;
    return { perihelion: new Date(date.getTime() + toPeri * 86400000), aphelion: new Date(date.getTime() + toAph * 86400000) };
  }
  function earthSpeed(r) { const GM = 1.32712440018e20, AU = 1.495978707e11; return Math.sqrt(GM * (2 / (r * AU) - 1 / AU)) / 1000; }

  // Altura y azimut de un cuerpo con longitud/latitud eclípticas, para un observador.
  function altAz(date, eclLon, eclLat, latDeg, lonDeg) {
    const d = dayNumber(date), ecl = 23.4393 - 3.563e-7 * d;
    const x = C(eclLon) * C(eclLat), y = S(eclLon) * C(eclLat), z = S(eclLat);
    const ye = y * C(ecl) - z * S(ecl), ze = y * S(ecl) + z * C(ecl);
    const ra = norm(Math.atan2(ye, x) * DEG), dec = Math.atan2(ze, Math.hypot(x, ye)) * DEG;
    const s = sun(date), gmst0 = norm(s.M + s.w + 180);
    const ut = (date.getUTCHours() + date.getUTCMinutes() / 60 + date.getUTCSeconds() / 3600) * 15;
    const ha = norm(gmst0 + ut + lonDeg - ra + 180) - 180;
    const sinAlt = S(latDeg) * S(dec) + C(latDeg) * C(dec) * C(ha);
    return { alt: Math.asin(sinAlt) * DEG, ha, dec, ra };
  }
  const sunAltAz = (date, lat, lon) => altAz(date, sun(date).lon, 0, lat, lon);
  const moonAltAz = (date, lat, lon) => { const m = moon(date); return altAz(date, m.lon, m.lat, lat, lon); };

  // Trayectoria SVG de la parte iluminada de la Luna (vista desde el hemisferio norte).
  function litPath(el, cx, cy, r) {
    el = norm(el);
    const k = Math.abs(C(el)) * r, top = `${cx} ${cy - r}`, bot = `${cx} ${cy + r}`;
    if (el < 0.5 || el > 359.5) return '';
    if (el < 180) {
      const sweep = el < 90 ? 0 : 1;
      return `M${top} A${r} ${r} 0 0 1 ${bot} A${k} ${r} 0 0 ${sweep} ${top}Z`;
    }
    const sweep = el < 270 ? 0 : 1;
    return `M${top} A${r} ${r} 0 0 0 ${bot} A${k} ${r} 0 0 ${sweep} ${top}Z`;
  }

  return { sun, moon, planet, phase, upcomingPhases, nextSeason, currentSeason, apsides, earthSpeed, sunAltAz, moonAltAz, litPath, norm, SYNODIC };
})();
